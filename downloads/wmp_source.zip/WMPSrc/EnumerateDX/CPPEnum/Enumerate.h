

//////////////////////////////////////////////////////////////////////
//	Code to enumerate DirectDraw/Direct3D drivers, devices, and modes.
//////////////////////////////////////////////////////////////////////


struct DEVICEINFO
{
	// Device Description
    CHAR			DeviceDesc[100];

    // D3D Device info
	GUID			DeviceGUID;
    D3DDEVICEDESC7	ddDeviceDesc;
    BOOL			bHardware;

	// Supported Modes
	DWORD			dwNumModes;
	DWORD			devModes[MAX_MODES];
};

struct DRIVERINFO
{
	// Driver Description
	CHAR			DriverDesc[100];

    // DDraw Driver info
    GUID			DriverGUID;
    DDCAPS			ddDriverCaps;
    DDCAPS			ddHELCaps;

    DWORD			dwNumModes;
    DDSURFACEDESC2	ddsdModes[MAX_MODES];

	// Devices
	DWORD			NumDevices;
	DEVICEINFO		Devices[MAX_DEVICES];
};


//-----------------------------------------------------------------------------
// Global data for the enumerator functions
//-----------------------------------------------------------------------------

DWORD			NumDrivers = 0L;		// The Number of Drivers
DRIVERINFO		Drivers[MAX_DRIVERS];	// The Drivers

DWORD			TotNumDevices=0L;		// The Total number of devices
										// on the system. Just used to
										// check if any drivers were
										// found at all.


//-----------------------------------------------------------------------------
// Local callback functions used during enumeration
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
// Name: ModeEnumCallback()
// Desc: Callback function for enumerating display modes.
//-----------------------------------------------------------------------------
static HRESULT WINAPI ModeEnumCallback( DDSURFACEDESC2* pddsd,
                                        VOID* pParentInfo )
{
    // Copy the mode into the driver's list of supported modes
    DRIVERINFO* pDriverInfo = (DRIVERINFO *)pParentInfo;
    pDriverInfo->ddsdModes[pDriverInfo->dwNumModes++] = (*pddsd);

    return DDENUMRET_OK;
}




//-----------------------------------------------------------------------------
// Name: DeviceEnumCallback()
// Desc: Callback function for enumerating devices
//-----------------------------------------------------------------------------
static HRESULT WINAPI DeviceEnumCallback(LPSTR strDesc,
                                  LPSTR strName, D3DDEVICEDESC7* pDesc,
                                  VOID* pParentInfo )
{
    // Set some pointers
	DRIVERINFO *pDriverInfo = (DRIVERINFO *)pParentInfo;
	DEVICEINFO *pDeviceInfo = &(pDriverInfo->Devices[pDriverInfo->NumDevices]);

	// Copy the Device's info
    memcpy( &(pDeviceInfo->ddDeviceDesc), pDesc, sizeof(D3DDEVICEDESC7) );
    pDeviceInfo->DeviceGUID		= pDesc->deviceGUID;
    pDeviceInfo->bHardware		= pDesc->dwDevCaps & D3DDEVCAPS_HWRASTERIZATION;
    pDeviceInfo->dwNumModes		= 0;

    // Copy the description for the device
	strncpy( pDeviceInfo->DeviceDesc, strDesc, 100 );
    

    // This is a good place to give the app a chance to accept or reject this
    // device via a callback function. This simple tutorial does not do this,
    // though.
	if(pDeviceInfo->DeviceGUID == IID_IDirect3DRefDevice)
		return D3DENUMRET_OK;


    // Build list of supported modes for the device
    for( DWORD i=0; i<pDriverInfo->dwNumModes; i++ )
    {
        DWORD dwModeDepth = pDriverInfo->ddsdModes[i].ddpfPixelFormat.dwRGBBitCount;
        DWORD dwBitDepth  = pDeviceInfo->ddDeviceDesc.dwDeviceRenderBitDepth;
        BOOL  bCompatible = FALSE;

        // Check mode for compatability with device. Skip 8-bit modes.
        if( (32==dwModeDepth) && (dwBitDepth&DDBD_32) ) bCompatible = TRUE;
        if( (24==dwModeDepth) && (dwBitDepth&DDBD_24) ) bCompatible = TRUE;
        if( (16==dwModeDepth) && (dwBitDepth&DDBD_16) ) bCompatible = TRUE;

        // Copy compatible modes to the list of device-supported modes
        if( bCompatible )
            pDeviceInfo->devModes[pDeviceInfo->dwNumModes++] = i;
    }

    // Make sure the device has supported modes
    if( 0 == pDeviceInfo->dwNumModes )
        return D3DENUMRET_OK;


    // Accept the device and return
	pDriverInfo->NumDevices++;
	TotNumDevices++;

	return D3DENUMRET_OK;
}




//-----------------------------------------------------------------------------
// Name: DriverEnumCallback()
// Desc: Callback function for enumerating drivers.
//-----------------------------------------------------------------------------
static BOOL WINAPI DriverEnumCallback( GUID* pGUID, LPSTR strDesc,
                                       LPSTR strName, VOID*, HMONITOR )
{
	DRIVERINFO	  *pDriverInfo;
    LPDIRECT3D7   pD3D;
    LPDIRECTDRAW7 pDD;
    HRESULT       hr;
    
    // Use the GUID to create the DirectDraw object
    hr = DirectDrawCreateEx( pGUID, (VOID**)&pDD, IID_IDirectDraw7, NULL );
    if( FAILED(hr) )
    {
        return D3DENUMRET_OK;
    }

    // Create a D3D object, to enumerate the d3d devices
    hr = pDD->QueryInterface( IID_IDirect3D7, (VOID**)&pD3D );
    if( FAILED(hr) )
    {
        pDD->Release();
        return D3DENUMRET_OK;
    }

	pDriverInfo = &Drivers[NumDrivers++];

	// Copy the Description of the Device
	strncpy( pDriverInfo->DriverDesc, strDesc, 100 );
	
	// Get the Driver's Caps
    pDriverInfo->ddDriverCaps.dwSize = sizeof(DDCAPS);
    pDriverInfo->ddHELCaps.dwSize    = sizeof(DDCAPS);
    pDD->GetCaps( &(pDriverInfo->ddDriverCaps),
				  &(pDriverInfo->ddHELCaps));

	// Get the GUID of the Driver
    if( pGUID )
		pDriverInfo->DriverGUID = (*pGUID);
    
    // Enumerate the fullscreen display modes.
    pDD->EnumDisplayModes( 0, NULL, pDriverInfo, ModeEnumCallback );

    // Now, enumerate all the 3D devices
    pD3D->EnumDevices( DeviceEnumCallback, pDriverInfo );

    // Clean up and return
    pD3D->Release();
    pDD->Release();

    return DDENUMRET_OK;
}



BOOLEAN GetSystemDeviceInfo(char *filename)
{
	FILE    *f;
	DWORD	i,j,k;
	DRIVERINFO *tDriverInfo;
	DEVICEINFO *tDeviceInfo;


	// Initialize the driver struct
	for(i=0;i<MAX_DRIVERS;i++)
	{
		Drivers[i].dwNumModes = 0L;
		Drivers[i].NumDevices = 0L;
	}
	

    // Enumerate drivers, devices, and modes
    DirectDrawEnumerateEx( DriverEnumCallback, NULL,
                           DDENUM_ATTACHEDSECONDARYDEVICES |
                           DDENUM_DETACHEDSECONDARYDEVICES |
                           DDENUM_NONDISPLAYDEVICES );


    // Make sure drivers were actually enumerated
    if( 0 == TotNumDevices )
        return FALSE;

	
	// Open file for outputting the system driver info
	if((f = fopen(filename,"w")) == (FILE *)NULL)
		return FALSE;

	
	fprintf(f,"%d\n",NumDrivers);
	for(i=0;i<NumDrivers;i++)
	{
		tDriverInfo = &(Drivers[i]);

		fprintf(f,"%s\n", tDriverInfo->DriverDesc);
		fprintf(f,"%d\n", tDriverInfo->NumDevices);

		for(j=0;j<tDriverInfo->NumDevices;j++)
		{
			tDeviceInfo = &(tDriverInfo->Devices[j]);

			fprintf(f,"%s\n", tDeviceInfo->DeviceDesc);
			fprintf(f,"%d\n", tDeviceInfo->dwNumModes);
			
			for(k=0;k<tDeviceInfo->dwNumModes;k++)
			{
				fprintf(f,"%dx%dx%d\n",
							tDriverInfo->ddsdModes[tDeviceInfo->devModes[k]].dwWidth,
							tDriverInfo->ddsdModes[tDeviceInfo->devModes[k]].dwHeight,
							tDriverInfo->ddsdModes[tDeviceInfo->devModes[k]].ddpfPixelFormat.dwRGBBitCount);
			}
		}
	}
	

	// Close the file
	fclose(f);

	// We were successfull
	return TRUE;
}

