// Test.cpp : Defines the entry point for the application.
//

#include "stdio.h"
#include "DefinesAndGlobals.h"
#include "Enumerate.h"



WORD __declspec(dllexport) CALLBACK EnumerateDX(BSTR bstrfilename)
{
	LPSTR lpstrfilename;
	lpstrfilename = (LPSTR)bstrfilename;

	if(!GetSystemDeviceInfo(lpstrfilename))
		return 0;	// Failure
	else
		return 1;	// Success
}

