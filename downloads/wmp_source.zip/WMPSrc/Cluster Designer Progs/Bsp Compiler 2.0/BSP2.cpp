
// This BSP compiler takes the polygon that splits other 
// polygons the least as the root polygon -- Xavier


#include "stdafx.h"
#include <conio.h>


#define PERPDIST(V,P) ((V.x - verts[P->ind[0]].x) * P->nx +		\
					   (V.y - verts[P->ind[0]].y) * P->ny +		\
					   (V.z - verts[P->ind[0]].z) * P->nz )

#define SQUAREDIST(V1,V2) ((V1.x - V2.x)*(V1.x - V2.x) +		\
						   (V1.y - V2.y)*(V1.y - V2.y) +		\
						   (V1.z - V2.z)*(V1.z - V2.z) )

#define APPROXEQUAL(A,B) (((A) > (B) - 0.05f) &&	\
						  ((A) < (B) + 0.05f))

#define SQUARE(Num) ((Num) * (Num))

#define PERPDISTPOLYVERT(I,N) ((verts[tPoly->ind[I]].x - verts[tPoly->ind[0]].x) * N.nx +	\
							   (verts[tPoly->ind[I]].y - verts[tPoly->ind[0]].y) * N.ny +	\
							   (verts[tPoly->ind[I]].z - verts[tPoly->ind[0]].z) * N.nz )


struct NORMAL
{
	float nx,ny,nz;
};

struct VERTEX
{
  float x,y,z;
  float tu,tv;
};

struct POLYGON
{
  float midx,midy,midz;
  float nx,ny,nz;
  NORMAL	LightMapNormal2;
  NORMAL	Normals[50];
  unsigned short numind;
  unsigned short ind[50];
  float			 Stu[50];
  float			 Stv[50];

  POLYGON *next,*front,*back;
  unsigned short Number;
  unsigned short TextureIndex;
};

struct LIGHT
{
	float x1,y1,z1;
	float x2,y2,z2;
	float Radius;
	float Brightness;
	float R,G,B;
	unsigned short LightType;
};

struct WATER
{
	float y;
	float R,G,B;
	unsigned short NumBoundingPolys;
	unsigned short BoundingPolyInds[50];
};


unsigned short	numverts;
VERTEX			verts[50000];


unsigned short	numpolys;
POLYGON	polys[50000];
unsigned short	BSPPolyNum=0;
unsigned short	BSPPolyNum0=0;

unsigned short	numlights;
LIGHT	lights[1000];

unsigned short	numwaters;
WATER	waters[1000];



FILE *infile,*outfile,*texfile;


unsigned short	NumTextures;
struct	TEXTUREPROPERTY
{
	char			TextureFileName[100];
	unsigned short	TexTableNum;
	char			HasAlpha,Glass;
	float			Reflective;
	char			NumAniFrames;
	float			AniT1,AniT2;
	char			Energy,HitChecked;
};
TEXTUREPROPERTY Textures[50];

unsigned short	NumTableTextures;
char			TableTextures[500][100];


unsigned short	UnsignedShortDummy;

char			OutputPath[100];
int				RoomNo;
float			Scale;
float			transX,transY,transZ;
float			Rx1,Ry1,Rz1,Rx2,Ry2,Rz2; // Room extents


// Function declarations

void CalcPolyMidPt(POLYGON *tpoly);
int CalcPolyNormal(POLYGON *tpoly);
void BuildBSPTree(POLYGON *polyhead, POLYGON **ParentsChildPointer);
void WritePolyDataBIN(POLYGON *tpoly);
void CountPolys(POLYGON *tpoly);
FILE *WriteTexAniFileNames(char *TexName, FILE *WFile);
char CountTexAniFiles(char *TexName);
void SetPolyShadowCoords(float BtuS,float BtvS,float tcoordInc,POLYGON *tPoly);
int CalcPolySideNormal(POLYGON *tpoly);
int CalcPolyLightMapNormal2(POLYGON *tpoly);


// The starting point
int main(int argc, char* argv[])
{	
	POLYGON *BSPHead;
	char tfilename[100];
	
	if(argc < 8)
	{
		printf("Insufficient arguments\n");
		printf("Syntax : BSP2 <RM-filename> <output-path> <room no.> <scale> <tX> <tY> <tZ>\n");
		getch();
		return 0;
	}

	strcpy(OutputPath,argv[2]);
	sscanf(argv[3],"%d",&RoomNo);
	sscanf(argv[4],"%f",&Scale);
	sscanf(argv[5],"%f",&transX);
	sscanf(argv[6],"%f",&transY);
	sscanf(argv[7],"%f",&transZ);



	strcpy(tfilename,argv[1]);

	if((infile = fopen(tfilename,"r")) == (FILE *)NULL)
	{
		printf("Fatal Error : Cannot open input-file\n");
		getch();
		return 0;
	}

	unsigned int dui;

	// Read the object data
	printf("Reading data... ");
	
	// Read the vertex data
	fscanf(infile,"%u",&dui);
	numverts = dui;
	for(int i=0;i<numverts;i++)
	{
		fscanf(infile,"%f,%f,%f",&verts[i].x, &verts[i].y, &verts[i].z);
		fscanf(infile,"%f,%f",&verts[i].tu, &verts[i].tv);
	}

	// Read the polygon data
	fscanf(infile,"%u",&dui);
	numpolys = dui;
	for(i=0;i<numpolys;i++)
	{
		fscanf(infile,"%u",&dui);
		polys[i].numind = dui;

		for(int j=0;j<polys[i].numind;j++)
		{
			fscanf(infile,"%u",&dui);
			polys[i].ind[j] = dui;
		}
		fscanf(infile,"%u",&dui);
		polys[i].TextureIndex = dui;
	}

	fscanf(infile,"%u\n",&dui);
	NumTextures = dui;
	unsigned int   dummy1,dummy2,dummy4,dummy7,dummy8;
	float dummy3,dummy5,dummy6;
	for(i=0;i<NumTextures;i++)
	{
		dummy1 = fgetc(infile);
		fgets(Textures[i].TextureFileName,100,infile);
		Textures[i].TextureFileName[strlen(Textures[i].TextureFileName)-2] = '\0';


		fscanf(infile,"%u,%u,%f,%u,%f,%f,%u,%u\n",
						&dummy1,&dummy2,&dummy3,&dummy4,
						&dummy5,&dummy6,&dummy7,&dummy8);

		Textures[i].HasAlpha	= (dummy1)?1:0;
		Textures[i].Glass		= (dummy2)?1:0;
		Textures[i].Reflective	= dummy3;
		Textures[i].NumAniFrames= (dummy4)?1:0;
		Textures[i].AniT1		= dummy5;
		Textures[i].AniT2		= dummy6;
		Textures[i].Energy		= dummy7;
		Textures[i].HitChecked	= dummy8;

		Textures[i].TexTableNum = i;
	}


	fscanf(infile,"%u",&dui);
	numlights = dui;
	for(i=0;i<numlights;i++)
	{
		fscanf(infile,"%f,%f,%f",&lights[i].x1, &lights[i].y1, &lights[i].z1);
		fscanf(infile,"%f,%f,%f",&lights[i].x2, &lights[i].y2, &lights[i].z2);
		fscanf(infile,"%f",&lights[i].Radius); // Read the dummy smaller radius
		fscanf(infile,"%f",&lights[i].Radius);
		fscanf(infile,"%f",&lights[i].Brightness);
		fscanf(infile,"%f,%f,%f",&lights[i].R, &lights[i].G, &lights[i].B);
		fscanf(infile,"%u",&dui);
		lights[i].LightType = dui;
	}
	
	fscanf(infile,"%u",&dui);
	numwaters = dui;
	for(i=0;i<numwaters;i++)
	{
		fscanf(infile,"%f",&waters[i].y);
		fscanf(infile,"%f,%f,%f",&waters[i].R, &waters[i].G, &waters[i].B);
		fscanf(infile,"%u",&dui);
		waters[i].NumBoundingPolys = dui;
		for(int j=0;j<waters[i].NumBoundingPolys;j++)
		{
			fscanf(infile,"%u",&dui);
			waters[i].BoundingPolyInds[j] = dui;
		}
	}


	fclose(infile);
	printf("Complete\n");


	// Calculate some necessary data
	printf("Calculating necessary data... ");

	// Find the mid-pt of all the vertices
	float cx,cy,cz;
	cx=cy=cz=0.0f;
	
	for(i=0;i<numverts;i++)
	{	cx += verts[i].x;
		cy += verts[i].y;
		cz += verts[i].z;
	}
	
	cx /= (float)numverts;
	cy /= (float)numverts;
	cz /= (float)numverts;

	// Set the initial values of the room extents
	Rx1=Rx2=cx;
	Ry1=Ry2=cy;
	Rz1=Rz2=cz;
	
	// Find the Room Extents
	for(i=0;i<numverts;i++)
	{
		if(verts[i].x < Rx1) Rx1 = verts[i].x;
		if(verts[i].y < Ry1) Ry1 = verts[i].y;
		if(verts[i].z < Rz1) Rz1 = verts[i].z;

		if(verts[i].x > Rx2) Rx2 = verts[i].x;
		if(verts[i].y > Ry2) Ry2 = verts[i].y;
		if(verts[i].z > Rz2) Rz2 = verts[i].z;
	}

	// Centerize and scale all the vertices
	for(i=0;i<numverts;i++)
	{
		verts[i].x = (verts[i].x - cx) * Scale;
		verts[i].y = (verts[i].y - cy) * Scale;
		verts[i].z = (verts[i].z - cz) * Scale;

		// Scale the Tex coords also
		verts[i].tu = verts[i].tu * Scale;
		verts[i].tv = verts[i].tv * Scale;
	}

	// Based on the final position for first vertex,
	// find the translation values for the remaining
	// vertices
	transX -= verts[0].x;
	transY -= verts[0].y;
	transZ -= verts[0].z;

	// Translate all the vertices
	for(i=0;i<numverts;i++)
	{
		verts[i].x += transX;
		verts[i].y += transY;
		verts[i].z += transZ;
	}

	// Centerize and scale the room extents
	Rx1 = (Rx1 - cx) * Scale + transX;
	Ry1 = (Ry1 - cy) * Scale + transY;
	Rz1 = (Rz1 - cz) * Scale + transZ;
	Rx2 = (Rx2 - cx) * Scale + transX;
	Ry2 = (Ry2 - cy) * Scale + transY;
	Rz2 = (Rz2 - cz) * Scale + transZ;


	// Centerize and scale all the lights
	for(i=0;i<numlights;i++)
	{
		lights[i].x1 = (lights[i].x1 - cx) * Scale + transX;
		lights[i].y1 = (lights[i].y1 - cy) * Scale + transY;
		lights[i].z1 = (lights[i].z1 - cz) * Scale + transZ;

		if(lights[i].x2 || lights[i].y2 || lights[i].z2)
		{
			lights[i].x2 = (lights[i].x2 - cx) * Scale + transX;
			lights[i].y2 = (lights[i].y2 - cy) * Scale + transY;
			lights[i].z2 = (lights[i].z2 - cz) * Scale + transZ;
		}

		lights[i].Radius *= Scale;
	}

	// Centerize and scale all the waters
	for(i=0;i<numwaters;i++)
		waters[i].y = (waters[i].y - cy) * Scale + transY;


	for(i=0;i<numpolys;i++)
	{	
		// Set the next pointer
		polys[i].next = &polys[i+1];

		// Calculate the mid point of the polygon
		CalcPolyMidPt(&polys[i]);
		
		// Calculate the normal of the polygon
		if(!CalcPolyNormal(&polys[i]))
		{	printf("Stopped\n");
			printf("Error : An invalid polygon was found at index %d\n",i);
		  	getch();
			return 0;
		}

		CalcPolySideNormal(&polys[i]);
		CalcPolyLightMapNormal2(&polys[i]);
	}
	// Set the next pointer
	polys[i-1].next = NULL;



	// Find the actual count of the animated texture's frames
	for(i=0;i<NumTextures;i++)
		if(Textures[i].NumAniFrames > 0)
			Textures[i].NumAniFrames = CountTexAniFiles(Textures[i].TextureFileName);



	// Decrement the poly's texture inds
	for(i=0;i<numpolys;i++)
	 (polys[i].TextureIndex)--;

	// Open the Texture Table file
	sprintf(tfilename,"%s\\Temp\\TexTable.txt",OutputPath);
	if((texfile = fopen(tfilename,"r")) == (FILE *)NULL)
	{
		// Create the Texture Table file
		if((texfile = fopen(tfilename,"w")) == (FILE *)NULL)
		{
			printf("Error : Unable to create Texture Table\n");
			getch();
			return 0;
		}

		// Count the actual no. of textures(including the animated frames)
		unsigned short NumTotTextures = NumTextures;

		for(i=0;i<NumTextures;i++)
			if(Textures[i].NumAniFrames > 0)
				NumTotTextures += Textures[i].NumAniFrames;


		// Write the no. of textures
		fprintf(texfile,"%u\n",NumTotTextures);

		// Just copy the texture file names to the file
		for(i=0;i<NumTextures;i++)
		{
			fprintf(texfile,"%s\n",Textures[i].TextureFileName);

			if(Textures[i].NumAniFrames > 0)
			{
				texfile = WriteTexAniFileNames(Textures[i].TextureFileName,texfile);

				for(int j=i+1;j<NumTextures;j++)
					Textures[j].TexTableNum += Textures[i].NumAniFrames;
			}
		}

		// Correct all the poly's texture inds
		for(int k=0;k<numpolys;k++)
			polys[k].TextureIndex = Textures[polys[k].TextureIndex].TexTableNum;

		
		// Close the texture table file
		fclose(texfile);
	}
	else
	{
		// Read the no. of textures
		fscanf(texfile,"%u\n",&NumTableTextures);
		
		// Read the Table Texture file names
		for(i=0;i<NumTableTextures;i++)
		{
			fgets(TableTextures[i],100,texfile);
			TableTextures[i][strlen(TableTextures[i])-1] = '\0';
		}
		
		// Close the tex table file
		fclose(texfile);

		// Go through the room's textures
		for(i=0;i<NumTextures;i++)
		{
			for(int j=0;j<NumTableTextures;j++)
			 if(strcmp(Textures[i].TextureFileName,TableTextures[j]) == 0)
				{
					Textures[i].TexTableNum = j;	
					break;
				}

			if(j == NumTableTextures)
			{
				strcpy(TableTextures[NumTableTextures],Textures[i].TextureFileName);

				Textures[i].TexTableNum = NumTableTextures;	
				
 				NumTableTextures++;
				
				// Now if the texture is animated, 
				// copy the tex file names of the
				// animated frames
				if(Textures[i].NumAniFrames > 0)
				{
					char TName[100],STName[100];

					strcpy(TName,Textures[i].TextureFileName);
					TName[strlen(TName)- 6] = '\0';

					for(j=1;j<=Textures[i].NumAniFrames;j++)
					{
						if(j<10)
							sprintf(STName,"%s0%d.bmp",TName,j);
						else
							sprintf(STName,"%s%d.bmp",TName,j);

						strcpy(TableTextures[NumTableTextures],STName);
		 				NumTableTextures++;
					}
				}

			}
		}

		
		// Correct all the poly's texture inds
		for(int k=0;k<numpolys;k++)
		 polys[k].TextureIndex = Textures[polys[k].TextureIndex].TexTableNum;


		// Open the Texture Table file
		if((texfile = fopen(tfilename,"w")) == (FILE *)NULL)
		{
			printf("Error : Unable to create Texture Table\n");
			getch();
			return 0;
		}

		// Write the no. of textures
		fprintf(texfile,"%u\n",NumTableTextures);

		// Just copy the texture file names to the file
		for(i=0;i<NumTableTextures;i++)
		 fprintf(texfile,"%s\n",TableTextures[i]);

		// Close the texture table file
		fclose(texfile);
	}
	
	printf("Complete\n");

	for(i=0;i<NumTextures;i++)
	{
		float BtuS,BtvS,tcoordInc;
		int NumCompPolys=0;

		for(int j=0;j<numpolys;j++)
		 if(polys[j].TextureIndex == Textures[i].TexTableNum)
			NumCompPolys++;

		BtuS = BtvS = 0.0f;

		if(NumCompPolys == 1)
			tcoordInc = 1.0f;
		else if(NumCompPolys <= SQUARE(2))
			tcoordInc = 0.5f;
		else if(NumCompPolys <= SQUARE(4))
			tcoordInc = 0.25f;
		else if(NumCompPolys <= SQUARE(8))
			tcoordInc = 0.125f;
		else if(NumCompPolys <= SQUARE(16))
			tcoordInc = 0.0625f;
		else if(NumCompPolys <= SQUARE(32))
			tcoordInc = 0.03125f;
		else if(NumCompPolys <= SQUARE(64))
			tcoordInc = 0.015625f;
		else if(NumCompPolys <= SQUARE(128))
			tcoordInc = 0.0078125f;
		else
			tcoordInc = 0.00390625f;

		for(int pi=0;pi<numpolys;pi++)
		 if(polys[pi].TextureIndex == Textures[i].TexTableNum)
		{
			SetPolyShadowCoords(BtuS,BtvS,tcoordInc,
				&polys[pi]);

			BtuS += tcoordInc;
			if(BtuS == 1.0f) { BtuS = 0.0f; BtvS += tcoordInc; }
		}
	}




	// Build the BSP Tree
	printf("Building BSP Tree... ");
	BuildBSPTree(polys,&BSPHead);
	printf("Complete\n");

	printf("\t\tStats :\n");
	printf("\t\t\tVertices : %5d, Polygons : %5d\n",numverts,numpolys);
	printf("\t\t\tTextures : %5d, Lights   : %5d\n",NumTextures,numlights);

	// Assign the Numbers to each Polygon
	CountPolys(BSPHead);
	
	//Correct the indices of the water polys
	for(i=0;i<numwaters;i++)
	 for(int j=0;j<waters[i].NumBoundingPolys;j++)
	  waters[i].BoundingPolyInds[j] = polys[waters[i].BoundingPolyInds[j]].Number;



	// Write the Binary Data

	sprintf(tfilename,"%s\\Temp\\Room%d.bin",OutputPath,RoomNo);

	if((outfile = fopen(tfilename,"wb")) == (FILE *)NULL)
	{
		printf("Fatal Error : Cannot create output-file : %s\n",tfilename);
		getch();
		return 0;
	}

	printf("Writing Binary Room data... ");

	// Write the no. of vertices
	fwrite(&numverts,sizeof(numverts),1,outfile);
	// Write the vertices
	for(i=0;i<numverts;i++)
	{
		fwrite(&(verts[i].x),sizeof(float),1,outfile);
		fwrite(&(verts[i].y),sizeof(float),1,outfile);
		fwrite(&(verts[i].z),sizeof(float),1,outfile);
	}
	for(i=0;i<numverts;i++)
	{
		fwrite(&(verts[i].tu),sizeof(float),1,outfile);
		fwrite(&(verts[i].tv),sizeof(float),1,outfile);
	}


	// Write the no. of BSP polygons
	fwrite(&numpolys,sizeof(numpolys),1,outfile);
	// Write the polygon data
	WritePolyDataBIN(BSPHead);
	// Write the no. of components
	fwrite(&NumTextures,sizeof(NumTextures),1,outfile);
	// Write the component Data
	for(i=0;i<NumTextures;i++)
	{
		fwrite(&(Textures[i].TexTableNum),sizeof(unsigned short),1,outfile);
		fwrite(&(Textures[i].HasAlpha  ),sizeof(char),1,outfile);
		fwrite(&(Textures[i].Glass     ),sizeof(char),1,outfile);
		fwrite(&(Textures[i].Reflective),sizeof(float),1,outfile);
		fwrite(&(Textures[i].NumAniFrames),sizeof(char),1,outfile);
		if(Textures[i].NumAniFrames > 0)
		{
			fwrite(&(Textures[i].AniT1),sizeof(float),1,outfile);
			fwrite(&(Textures[i].AniT2),sizeof(float),1,outfile);
		}
		fwrite(&(Textures[i].Energy),sizeof(char),1,outfile);
		fwrite(&(Textures[i].HitChecked),sizeof(char),1,outfile);
		

		UnsignedShortDummy = 0;
		for(int j=0;j<numpolys;j++)
		 if(polys[j].TextureIndex == Textures[i].TexTableNum)
			UnsignedShortDummy++;
		
		fwrite(&UnsignedShortDummy,sizeof(unsigned short),1,outfile);
		for(j=0;j<numpolys;j++)
		 if(polys[j].TextureIndex == Textures[i].TexTableNum)
			fwrite(&(polys[j].Number),sizeof(unsigned short),1,outfile);
	}

	// Count the no. of non-ambient lights
	unsigned short numnonambientlights=0;
	for(i=0;i<numlights;i++)
		if(lights[i].LightType == 2 ||
		   lights[i].LightType == 3 )
			numnonambientlights++;
	// Write the no. of non-ambient lights
	fwrite(&numnonambientlights,sizeof(unsigned short),1,outfile);
	// Write the non-ambient lights
	for(i=0;i<numlights;i++)
		if(lights[i].LightType == 2 ||
		   lights[i].LightType == 3 )
			fwrite(&lights[i],sizeof(float)*11,1,outfile);
	


	// Write the no. of waters
	fwrite(&numwaters,sizeof(unsigned short),1,outfile);
	// Write the waters
	for(i=0;i<numwaters;i++)
	{
		fwrite(&waters[i].y,sizeof(float),1,outfile);
		fwrite(&waters[i].R,sizeof(float),1,outfile);
		fwrite(&waters[i].G,sizeof(float),1,outfile);
		fwrite(&waters[i].B,sizeof(float),1,outfile);
		fwrite(&waters[i].NumBoundingPolys,sizeof(unsigned short),1,outfile);
		for(int j=0;j<waters[i].NumBoundingPolys;j++)
			fwrite(&waters[i].BoundingPolyInds[j],sizeof(unsigned short),1,outfile);
	}


	
	// Write the room extents
	fwrite(&Rx1,sizeof(float),1,outfile);
	fwrite(&Ry1,sizeof(float),1,outfile);
	fwrite(&Rz1,sizeof(float),1,outfile);
	fwrite(&Rx2,sizeof(float),1,outfile);
	fwrite(&Ry2,sizeof(float),1,outfile);
	fwrite(&Rz2,sizeof(float),1,outfile);

	fclose(outfile);
	printf("Complete\n");


	return 0;
}


void CalcPolyMidPt(POLYGON *tpoly)
{
	tpoly->midx = tpoly->midy = tpoly->midz = 0.0f;

	for(int i=0;i<tpoly->numind;i++)
	{
		tpoly->midx += verts[tpoly->ind[i]].x;
		tpoly->midy += verts[tpoly->ind[i]].y;
		tpoly->midz += verts[tpoly->ind[i]].z;
	}

	tpoly->midx /= i;
	tpoly->midy /= i;
	tpoly->midz /= i;
}


int CalcPolyNormal(POLYGON *tpoly)
{
	float tx1,ty1,tz1,tx2,ty2,tz2,Denom;

	tx1 = verts[tpoly->ind[0]].x - verts[tpoly->ind[1]].x;
	ty1 = verts[tpoly->ind[0]].y - verts[tpoly->ind[1]].y;
	tz1 = verts[tpoly->ind[0]].z - verts[tpoly->ind[1]].z;

	tx2 = verts[tpoly->ind[2]].x - verts[tpoly->ind[1]].x;
	ty2 = verts[tpoly->ind[2]].y - verts[tpoly->ind[1]].y;
	tz2 = verts[tpoly->ind[2]].z - verts[tpoly->ind[1]].z;

	
	tpoly->nx = ty2 * tz1 - ty1 * tz2;
	tpoly->ny = tx1 * tz2 - tx2 * tz1;
	tpoly->nz = tx2 * ty1 - tx1 * ty2;

	Denom = sqrtf(tpoly->nx * tpoly->nx + tpoly->ny * tpoly->ny + tpoly->nz * tpoly->nz);

	if(Denom == 0.0f)
		return 0;

	tpoly->nx /= Denom;
	tpoly->ny /= Denom;
	tpoly->nz /= Denom;

	return 1;
}


/////////////////////////////////////////////////////////////////////
// Function to Calculate a Poly's Side Normals
/////////////////////////////////////////////////////////////////////

int CalcPolySideNormal(POLYGON *tpoly)
{
	int i;
	float tx1,ty1,tz1,tx2,ty2,tz2,Denom;

	for(i=1;i<tpoly->numind;i++)
	{
		tx1 = verts[tpoly->ind[i]].x - verts[tpoly->ind[i-1]].x;
		ty1 = verts[tpoly->ind[i]].y - verts[tpoly->ind[i-1]].y;
		tz1 = verts[tpoly->ind[i]].z - verts[tpoly->ind[i-1]].z;

		tx2 = -10.0f * tpoly->nx;
		ty2 = -10.0f * tpoly->ny;
		tz2 = -10.0f * tpoly->nz;

		tpoly->Normals[i-1].nx = ty2 * tz1 - ty1 * tz2;
		tpoly->Normals[i-1].ny = tx1 * tz2 - tx2 * tz1;
		tpoly->Normals[i-1].nz = tx2 * ty1 - tx1 * ty2;

		Denom = sqrtf(tpoly->Normals[i-1].nx * tpoly->Normals[i-1].nx 
					+ tpoly->Normals[i-1].ny * tpoly->Normals[i-1].ny
					+ tpoly->Normals[i-1].nz * tpoly->Normals[i-1].nz);
		
		if(Denom == 0.0f)
			return 0;

		tpoly->Normals[i-1].nx /= Denom;
		tpoly->Normals[i-1].ny /= Denom;
		tpoly->Normals[i-1].nz /= Denom;
	}


	tx1 = verts[tpoly->ind[0]].x - verts[tpoly->ind[i-1]].x;
	ty1 = verts[tpoly->ind[0]].y - verts[tpoly->ind[i-1]].y;
	tz1 = verts[tpoly->ind[0]].z - verts[tpoly->ind[i-1]].z;

	tx2 = -10.0f * tpoly->nx;
	ty2 = -10.0f * tpoly->ny;
	tz2 = -10.0f * tpoly->nz;

	tpoly->Normals[i-1].nx = ty2 * tz1 - ty1 * tz2;
	tpoly->Normals[i-1].ny = tx1 * tz2 - tx2 * tz1;
	tpoly->Normals[i-1].nz = tx2 * ty1 - tx1 * ty2;

	Denom = sqrtf(tpoly->Normals[i-1].nx * tpoly->Normals[i-1].nx 
				+ tpoly->Normals[i-1].ny * tpoly->Normals[i-1].ny
				+ tpoly->Normals[i-1].nz * tpoly->Normals[i-1].nz);
		
	if(Denom == 0.0f)
		return 0;

	tpoly->Normals[i-1].nx /= Denom;
	tpoly->Normals[i-1].ny /= Denom;
	tpoly->Normals[i-1].nz /= Denom;
	
	return 1;
}



/////////////////////////////////////////////////////////////////////
// Function to Calculate a Poly's LightMap 2nd Normal
/////////////////////////////////////////////////////////////////////

int CalcPolyLightMapNormal2(POLYGON *tpoly)
{
	float Denom;

	tpoly->LightMapNormal2.nx = verts[tpoly->ind[1]].x - verts[tpoly->ind[0]].x;
	tpoly->LightMapNormal2.ny = verts[tpoly->ind[1]].y - verts[tpoly->ind[0]].y;
	tpoly->LightMapNormal2.nz = verts[tpoly->ind[1]].z - verts[tpoly->ind[0]].z;

	Denom = sqrtf(tpoly->LightMapNormal2.nx * tpoly->LightMapNormal2.nx 
				+ tpoly->LightMapNormal2.ny * tpoly->LightMapNormal2.ny
				+ tpoly->LightMapNormal2.nz * tpoly->LightMapNormal2.nz);

	if(Denom == 0.0f)
		return 0;

	tpoly->LightMapNormal2.nx /= Denom;
	tpoly->LightMapNormal2.ny /= Denom;
	tpoly->LightMapNormal2.nz /= Denom;

	return 1;
}




POLYGON *ppoly,*pnextpoly,*pspoly;
int i,j,count,frontpolythere,backpolythere;
float Rcx,Rcy,Rcz;
float tx,ty,tz,t,closestDist;
int numfrontind,numbackind;
int frontind[50],backind[50];
float prevdist,currdist;
int notfoundflag=1;


void BuildBSPTree(POLYGON *polyhead, POLYGON **ParentsChildPointer)
{
	POLYGON *pRootPoly,*pFrontPolys,*pBackPolys;


//////////////////////////////////////////////////////////////////
//		Code to take the polygon that splits other polygons		//
//		the least as the Root									//
//////////////////////////////////////////////////////////////////

	count = 0;
	pspoly = polyhead->next;
	while(pspoly)
	{
		frontpolythere = backpolythere = 0;
		for(j=0;j < pspoly->numind;j++)
		{
			t = PERPDIST(verts[pspoly->ind[j]],polyhead);

			if(t > 0.05f)
			{ frontpolythere = 1; if(backpolythere) { count++; break; }}
			else if(t < -0.05f)
			{ backpolythere = 1;  if(frontpolythere){ count++; break; }}
		}

		pspoly = pspoly->next;
	}
	pRootPoly = polyhead;

	ppoly = polyhead->next;
	while(ppoly)
	{
		i=0;
		pspoly = polyhead;
		while(pspoly)
		{
			if(pspoly != ppoly)
			{
				frontpolythere = backpolythere = 0;
				for(j=0;j < pspoly->numind;j++)
				{
					t = PERPDIST(verts[pspoly->ind[j]],ppoly);

					if(t > 0.05f)
					{ frontpolythere = 1; if(backpolythere) { i++; break; }}
					else if(t < -0.05f)
					{ backpolythere = 1;  if(frontpolythere){ i++; break; }}
				}
			}
			pspoly = pspoly->next;
		}

		if(i < count)
		{
			count = i; pRootPoly = ppoly;
		}
		ppoly = ppoly->next;
	}

////////////////////////////////////////////////////////////////


/*
//////////////////////////////////////////////////////////////
//		Code to take the middle-most polygon as the Root	//
//////////////////////////////////////////////////////////////

	// Find the center of all the polygons

	count=0;
	Rcx = Rcy = Rcz = 0.0f;

	ppoly = polyhead;
	while(ppoly)
	{
		Rcx += ppoly->midx;
		Rcy += ppoly->midy;
		Rcz += ppoly->midz;

		count++;
		ppoly = ppoly->next;
	}
	Rcx /= count; Rcy /= count; Rcz/=count;


	// Find which polygon is closest to the center
	
	tx = polyhead->midx - Rcx;
	ty = polyhead->midy - Rcy;
	tz = polyhead->midz - Rcz;
	closestDist = tx*tx + ty*ty + tz*tz;
	pRootPoly = polyhead;

	ppoly = polyhead->next;
	while(ppoly)
	{
		tx = ppoly->midx - Rcx;
		ty = ppoly->midy - Rcy;
		tz = ppoly->midz - Rcz;

		t = tx*tx + ty*ty + tz*tz;
		if(t < closestDist)
		{ closestDist = t; pRootPoly = ppoly; }
	
		ppoly = ppoly->next;
	}

///////////////////////////////////////////////////////////////
*/


	*ParentsChildPointer = pRootPoly;
	pFrontPolys = pBackPolys = NULL;


	// Find the polygons which are at the front/back
	// of 'pRootPoly' (split polygons if necessary)
	// and push them into 'pFrontPolys' & 'pBackPolys'

	ppoly = polyhead;
	while(ppoly)
	{
		if(ppoly == pRootPoly)
		{
			ppoly = ppoly->next; // Skip the root polygon
		}
		else
		{
			pnextpoly = ppoly->next;

			// See if there are polygons in front/back/front&back
			frontpolythere = backpolythere = 0;
			for(i=0;i < ppoly->numind;i++)
			{
				t = PERPDIST(verts[ppoly->ind[i]],pRootPoly);

				if(t > 0.05f)
				{ frontpolythere = 1; if(backpolythere) break; }
				else if(t < -0.05f)
				{ backpolythere = 1;  if(frontpolythere) break; }
			}

			if(frontpolythere && backpolythere)
			{
				// We'll need an extra polygon( a polygon got split)
				pspoly = &polys[numpolys++];

				// The normal remains the same
				pspoly->nx = ppoly->nx;
				pspoly->ny = ppoly->ny;
				pspoly->nz = ppoly->nz;
				pspoly->TextureIndex = ppoly->TextureIndex;
				float tStu[50],tStv[50];
				for(i=0;i < ppoly->numind;i++)
				{
					tStu[i] = ppoly->Stu[i];
					tStv[i] = ppoly->Stv[i];
				}

				prevdist = 0.0f; numfrontind = numbackind = 0;
				for(i=0;i < ppoly->numind;i++)
				{
					currdist = PERPDIST(verts[ppoly->ind[i]],pRootPoly);

					if(prevdist * currdist < 0.0f)
					{
						t = prevdist/(prevdist - currdist);
						tx = verts[ppoly->ind[i-1]].x + (verts[ppoly->ind[i]].x - verts[ppoly->ind[i-1]].x)*t;
						ty = verts[ppoly->ind[i-1]].y + (verts[ppoly->ind[i]].y - verts[ppoly->ind[i-1]].y)*t;
						tz = verts[ppoly->ind[i-1]].z + (verts[ppoly->ind[i]].z - verts[ppoly->ind[i-1]].z)*t;

						verts[numverts].x=tx;
						verts[numverts].y=ty;
						verts[numverts].z=tz;
							
						verts[numverts].tu = 
							verts[ppoly->ind[i-1]].tu + (verts[ppoly->ind[i]].tu - verts[ppoly->ind[i-1]].tu)*t;
						verts[numverts].tv = 
							verts[ppoly->ind[i-1]].tv + (verts[ppoly->ind[i]].tv - verts[ppoly->ind[i-1]].tv)*t;

						ppoly->Stu[numfrontind] = 
							tStu[i-1] + (tStu[i] - tStu[i-1])*t;
						ppoly->Stv[numfrontind] = 
							tStv[i-1] + (tStv[i] - tStv[i-1])*t;
						pspoly->Stu[numbackind] = ppoly->Stu[numfrontind];
						pspoly->Stv[numbackind] = ppoly->Stv[numfrontind];

						frontind[numfrontind++]	= numverts;
						backind[numbackind++]	= numverts;
						numverts++;
					}

					if(currdist > 0.0f)
					{
						ppoly->Stu[numfrontind] = tStu[i];
						ppoly->Stv[numfrontind] = tStv[i];

						frontind[numfrontind++] = ppoly->ind[i];
					}
					else if(currdist < 0.0f)
					{
						pspoly->Stu[numbackind] = tStu[i];
						pspoly->Stv[numbackind] = tStv[i];

						backind[numbackind++] = ppoly->ind[i];
					}
					else
					{
						ppoly->Stu[numfrontind] = tStu[i];
						ppoly->Stv[numfrontind] = tStv[i];

						frontind[numfrontind++] = ppoly->ind[i];

						pspoly->Stu[numbackind] = tStu[i];
						pspoly->Stv[numbackind] = tStv[i];

						backind[numbackind++] = ppoly->ind[i];
					}

					prevdist = currdist;
				}

		
				// Special case for the first and last vertices

				currdist = PERPDIST(verts[ppoly->ind[0]],pRootPoly);
				
				if(prevdist * currdist < 0.0f)
				{
					t = prevdist/(prevdist - currdist);
					tx = verts[ppoly->ind[i-1]].x + (verts[ppoly->ind[0]].x - verts[ppoly->ind[i-1]].x)*t;
					ty = verts[ppoly->ind[i-1]].y + (verts[ppoly->ind[0]].y - verts[ppoly->ind[i-1]].y)*t;
					tz = verts[ppoly->ind[i-1]].z + (verts[ppoly->ind[0]].z - verts[ppoly->ind[i-1]].z)*t;

					verts[numverts].x=tx;
					verts[numverts].y=ty;
					verts[numverts].z=tz;

					verts[numverts].tu = 
						verts[ppoly->ind[i-1]].tu + (verts[ppoly->ind[0]].tu - verts[ppoly->ind[i-1]].tu)*t;
					verts[numverts].tv = 
						verts[ppoly->ind[i-1]].tv + (verts[ppoly->ind[0]].tv - verts[ppoly->ind[i-1]].tv)*t;

					ppoly->Stu[numfrontind] = 
						tStu[i-1] + (tStu[0] - tStu[i-1])*t;
					ppoly->Stv[numfrontind] = 
						tStv[i-1] + (tStv[0] - tStv[i-1])*t;
					pspoly->Stu[numbackind] = ppoly->Stu[numfrontind];
					pspoly->Stv[numbackind] = ppoly->Stv[numfrontind];

					frontind[numfrontind++]	= numverts;
					backind[numbackind++]	= numverts;
					numverts++;
				}


				// Remove unnecessary vertices from 
				// the front polygon
				i=1;
				while(i<numfrontind)
				{
					if( APPROXEQUAL(verts[frontind[i]].x,verts[frontind[i-1]].x) &&
						APPROXEQUAL(verts[frontind[i]].y,verts[frontind[i-1]].y) &&
						APPROXEQUAL(verts[frontind[i]].z,verts[frontind[i-1]].z) )
					{
						// Remove this vertex
						numfrontind--;
						for(j=i;j<numfrontind;j++)
						{	ppoly->Stu[j] = ppoly->Stu[j+1];
							ppoly->Stv[j] = ppoly->Stv[j+1];
							frontind[j] = frontind[j+1];
						}
					}
					else
						i++;
				}
				if(numfrontind > 3)
				if( APPROXEQUAL(verts[frontind[numfrontind-1]].x,verts[frontind[0]].x) &&
					APPROXEQUAL(verts[frontind[numfrontind-1]].y,verts[frontind[0]].y) &&
					APPROXEQUAL(verts[frontind[numfrontind-1]].z,verts[frontind[0]].z) )
						numfrontind--;
				

				// Remove unnecessary vertices from 
				// the back polygon
				i=1;
				while(i<numbackind)
				{
					if( APPROXEQUAL(verts[backind[i]].x,verts[backind[i-1]].x) &&
						APPROXEQUAL(verts[backind[i]].y,verts[backind[i-1]].y) &&
						APPROXEQUAL(verts[backind[i]].z,verts[backind[i-1]].z) )
					{
						// Remove this vertex
						numbackind--;
						for(j=i;j<numbackind;j++)
						{	pspoly->Stu[j] = pspoly->Stu[j+1];
							pspoly->Stv[j] = pspoly->Stv[j+1];
							backind[j] = backind[j+1];
						}
					}
					else
						i++;
				}
				if(numbackind > 3)
				if( APPROXEQUAL(verts[backind[numbackind-1]].x,verts[backind[0]].x) &&
					APPROXEQUAL(verts[backind[numbackind-1]].y,verts[backind[0]].y) &&
					APPROXEQUAL(verts[backind[numbackind-1]].z,verts[backind[0]].z) )
						numbackind--;


				// Copy the front vertices into 'ppoly'
				if(numfrontind > 2)
				{
					ppoly->numind = numfrontind;
					for(i=0;i<numfrontind;i++)
						ppoly->ind[i] = frontind[i];
				
					CalcPolyMidPt(ppoly);

					// Push 'ppoly' into 'pFrontPolys'
					ppoly->next=pFrontPolys; pFrontPolys = ppoly;
				}

				// Copy the back vertices into 'pspoly'
				if(numbackind > 2)
				{
					pspoly->numind = numbackind;
					for(i=0;i<numbackind;i++)
						pspoly->ind[i] = backind[i];
				
					CalcPolyMidPt(pspoly);

					// Push 'pspoly' into 'pBackPolys'
					pspoly->next=pBackPolys; pBackPolys = pspoly;
				}
				else
					numpolys--;
			}
			else if(backpolythere)
			{
				// Push 'ppoly' into 'pBackPolys'
				ppoly->next=pBackPolys; pBackPolys = ppoly;
			}
			else
			{
				// Push 'ppoly' into 'pFrontPolys'
				ppoly->next=pFrontPolys; pFrontPolys = ppoly;
			}

			ppoly = pnextpoly;

		}
	}


	if(pFrontPolys == NULL)
		pRootPoly->front = NULL;
	else
		BuildBSPTree(pFrontPolys,&(pRootPoly->front));


	if(pBackPolys == NULL)
		pRootPoly->back = NULL;
	else
		BuildBSPTree(pBackPolys,&(pRootPoly->back));

}


void WritePolyDataBIN(POLYGON *tpoly)
{
	fwrite(&(tpoly->numind),sizeof(unsigned short),1,outfile);
	for(int j=0;j<tpoly->numind;j++)
		fwrite(&(tpoly->ind[j]),sizeof(unsigned short),1,outfile);
	for(j=0;j<tpoly->numind;j++)
	{
		fwrite(&(tpoly->Stu[j]),sizeof(float),1,outfile);
		fwrite(&(tpoly->Stv[j]),sizeof(float),1,outfile);
	}

	if(tpoly->front)
		fwrite(&((tpoly->front)->Number),sizeof(unsigned short),1,outfile);
	else
		fwrite(&BSPPolyNum0,sizeof(unsigned short),1,outfile);

	if(tpoly->back)
		fwrite(&((tpoly->back)->Number),sizeof(unsigned short),1,outfile);
	else
		fwrite(&BSPPolyNum0,sizeof(unsigned short),1,outfile);


	if(tpoly->front)
		WritePolyDataBIN(tpoly->front);
	if(tpoly->back)
		WritePolyDataBIN(tpoly->back);
}


void CountPolys(POLYGON *tpoly)
{
	tpoly->Number = BSPPolyNum++;

	if(tpoly->front)
		CountPolys(tpoly->front);
	if(tpoly->back)
		CountPolys(tpoly->back);
}	



char CountTexAniFiles(char *TexName)
{
	char TName[100],STName[100];
	char NumTexAniFiles = 1;
	unsigned short TNameLen;
	FILE *TFile;

	strcpy(TName,TexName);
	TNameLen = strlen(TName);
	TName[TNameLen - 6] = '\0';

	for(;;)
	{
		if(NumTexAniFiles < 10)
			sprintf(STName,"%s\\TexPool\\%s0%d.bmp",OutputPath,TName,NumTexAniFiles);
		else
			sprintf(STName,"%s\\TexPool\\%s%d.bmp",OutputPath,TName,NumTexAniFiles);

		if((TFile = fopen(STName,"r")) == (FILE *)NULL)
			break;

		fclose(TFile);

		NumTexAniFiles++;
	}

	return(NumTexAniFiles-1);
}


FILE *WriteTexAniFileNames(char *TexName, FILE *WFile)
{
	char TName[100],STName[100];
	char NumTexAniFiles = 1;
	unsigned short TNameLen;
	FILE *TFile;

	strcpy(TName,TexName);
	TNameLen = strlen(TName);
	TName[TNameLen - 6] = '\0';

	for(;;)
	{
		if(NumTexAniFiles < 10)
			sprintf(STName,"%s\\TexPool\\%s0%d.bmp",OutputPath,TName,NumTexAniFiles);
		else
			sprintf(STName,"%s\\TexPool\\%s%d.bmp",OutputPath,TName,NumTexAniFiles);

		if((TFile = fopen(STName,"r")) == (FILE *)NULL)
			break;

		fclose(TFile);

		if(NumTexAniFiles < 10)
			sprintf(STName,"%s0%d.bmp",TName,NumTexAniFiles);
		else
			sprintf(STName,"%s%d.bmp",TName,NumTexAniFiles);

		fprintf(WFile,"%s\n",STName);
		NumTexAniFiles++;
	}

	return WFile;
}



void SetPolyShadowCoords(float BtuS,float BtvS,float tcoordInc,
						 POLYGON *tPoly)
{
	float HDist[50],VDist[50];
	float MaxHDist=0.0f,MinHDist=0.0f,MaxVDist=0.0f;

	HDist[0] = 0.0f;

	for(int i=1;i<tPoly->numind;i++)
	{
		HDist[i] =	PERPDISTPOLYVERT(i,tPoly->LightMapNormal2);

		if(HDist[i] > MaxHDist)	MaxHDist = HDist[i];
		if(HDist[i] < MinHDist)	MinHDist = HDist[i];
	}

	for(i=2;i<tPoly->numind;i++)
	{
		VDist[i] = -(PERPDISTPOLYVERT(i,tPoly->Normals[0]));

		if(VDist[i] > MaxVDist) MaxVDist = VDist[i];
	}

	float mH = (tcoordInc - 2.0f*0.00390625f)/(MaxHDist - MinHDist);
	float mV = (tcoordInc - 2.0f*0.00390625f)/ MaxVDist;

	for(i=0;i<tPoly->numind;i++)
		tPoly->Stu[i] = (HDist[i] - MinHDist)*mH + BtuS + 0.00390625f;

	tPoly->Stv[0] = BtvS + 0.00390625f;
	tPoly->Stv[1] = BtvS + 0.00390625f;

	for(i=2;i<tPoly->numind;i++)
		tPoly->Stv[i] = VDist[i] * mV + BtvS + 0.00390625f;
}

