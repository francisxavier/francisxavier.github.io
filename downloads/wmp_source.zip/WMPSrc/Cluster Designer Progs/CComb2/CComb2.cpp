// CComb2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int main(int argc, char* argv[])
{
	FILE *f;
	int i,j,nr,nc,ci;
	char command[200];

	if(argc < 2)
	{
		printf("Insufficient arguments.\n");
		printf("Syntax : CComb <working-path>\n");
		getch();
		return 0;
	}

	sprintf(command,"%s\\Temp\\BasicClusterInfo.txt",argv[1]);
	f = fopen(command,"r");
	if(f == NULL)
	{
		printf("Error : Could not open file : \'BasicClusterInfo.txt\'\n");
		getch();
		return 0;
	}
	
	printf("\nTexture Encoder\n");
	printf("---------------\n\n");

	fscanf(f,"%d",&nr);
	for(i=0;i<nr;i++)
	{
		printf("Generating Textures for Room%d",i);

		fscanf(f,"%d",&nc);
		for(j=0;j<nc;j++)
		{
			fscanf(f,"%d",&ci);
			printf(".");
			sprintf(command,"DXTex %s\\Temp\\R%dC%d.bmp DXT1 %s\\Temp\\R%dC%d.dds",argv[1],i,ci,argv[1],i,ci);
			system(command);			
		}
		printf(" Done\n");
	}

	fclose(f);

	printf("\n\nPress any key to continue...");
	getch();
	return 0;
}

