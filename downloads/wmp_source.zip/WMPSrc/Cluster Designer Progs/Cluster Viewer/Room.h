

/////////////////////////////////////////////////////////////////////
//						Room.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
// Consists of all the necessary functions for handling rooms
/////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
//						Defines
/////////////////////////////////////////////////////////////////////

#define MAX_ROOMS	100		// The maximum no. of Rooms



/////////////////////////////////////////////////////////////////////
//						Var Declarations
/////////////////////////////////////////////////////////////////////

WORD	NumRooms=0;			// The no. of Rooms
ROOM	*Rooms[MAX_ROOMS];	// The array of Rooms
ROOM	*CurrRoom;			// The Current Room




/////////////////////////////////////////////////////////////////////
//					Function Prototypes
/////////////////////////////////////////////////////////////////////







/////////////////////////////////////////////////////////////////////
//					Function Definitions
/////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
//	Loads a Room, given the filename
/////////////////////////////////////////////////////////////////////

FILE *LoadClusterRoom(FILE *file, int RoomInd, ROOM **RoomPtr,
					  LPDIRECT3DDEVICE7 lpD, LPDIRECT3D7 lpD3D)
{
	TEXCOORD *pBtexcoord;
	POLYSTEXCOORD *pStexcoord;
	POLYSTEXCOORD *pStcS,*pStcE;


	// Allocate memory for a Room
	ROOM *pRoom = new ROOM;
	
	// Initialize the Room Structure
	pRoom->Components		= NULL;
	pRoom->RoomVertInds		= NULL;
	pRoom->BSPPolyHead		= NULL;
	pRoom->StackP			= NULL;
	pRoom->StackOB			= NULL;
	pRoom->StackNC			= NULL;
	pRoom->RoomVerts		= NULL;
	pRoom->RoomWaters		= NULL;
	pRoom->UntransformedRoomVB	= NULL;
	pRoom->TransformedRoomVB	= NULL;
	pRoom->NonAmbLights		=NULL;



	// Load the Room data
	WORD	Num;

	// Read the no. of connected Rooms
	fread(&(pRoom->NumConnectedRooms),sizeof(WORD),1,file);
	// Allocate memory for storing the connected room's indices
	pRoom->ConnectedRooms = new WORD[pRoom->NumConnectedRooms];
	// Read the connected room's indices
	fread(pRoom->ConnectedRooms,sizeof(WORD),pRoom->NumConnectedRooms,file);
	
	// Read the no. of viewable Rooms
	fread(&(pRoom->NumViewableRooms),sizeof(WORD),1,file);
	// Allocate memory for storing the connected room's indices
	pRoom->ViewableRooms = new WORD[pRoom->NumViewableRooms];
	// Read the connected room's indices
	fread(pRoom->ViewableRooms,sizeof(WORD),pRoom->NumViewableRooms,file);

	
	// Read the no. of Vertices
	fread(&(pRoom->NumVerts),sizeof(WORD),1,file);

	// Allocate memory for the Room's Vertices
	pRoom->RoomVerts = new VERTEX[pRoom->NumVerts];
	// Allocate memory for a temporary buffer to hold the
	// texture coordinates
	pBtexcoord = new TEXCOORD[pRoom->NumVerts];

	// Read the Room's Vertices
	fread(pRoom->RoomVerts,sizeof(VERTEX),pRoom->NumVerts,file);
	// Read the Room's Base Tex Coords
	fread(pBtexcoord,sizeof(TEXCOORD),pRoom->NumVerts,file);

	// Read the no. of polys
	fread(&(pRoom->NumBSPPolys),sizeof(WORD),1,file);
	// Allocate memory for the Room's BSP Polys
	pRoom->BSPPolyHead = new POLYGON[pRoom->NumBSPPolys];
	// Allocate memory for the Room's Stacks
	pRoom->StackP  = new POLYGON*	[pRoom->NumBSPPolys];
	pRoom->StackOB = new float	[pRoom->NumBSPPolys];
	pRoom->StackNC = new float	[pRoom->NumBSPPolys];

	// Allocate memory for the poly's temp shadow coords
	pStexcoord = new POLYSTEXCOORD[pRoom->NumBSPPolys];
	pStcS = pStexcoord;
	pStcE = pStexcoord + pRoom->NumBSPPolys;

	for(int i=0;i<pRoom->NumBSPPolys;i++)
	{
		// Read the no. of vertices(or indices) for this polygon
		fread(&(pRoom->BSPPolyHead[i].NumVertices),sizeof(WORD),1,file);
		
		// Allocate memory for this poly's drawing indices
		pRoom->BSPPolyHead[i].DIndices = new WORD[pRoom->BSPPolyHead[i].NumVertices];
		// Allocate memory for this poly's indices
		pRoom->BSPPolyHead[i].Indices = new WORD[pRoom->BSPPolyHead[i].NumVertices];
		// Allocate memory for this poly's normals
		pRoom->BSPPolyHead[i].Normals = new NORMAL[pRoom->BSPPolyHead[i].NumVertices];
		
		// Read the Indices
		fread(pRoom->BSPPolyHead[i].Indices,sizeof(WORD),pRoom->BSPPolyHead[i].NumVertices,file);
		
		// Read the shadow coords
		pStcS->ptexcoord = new TEXCOORD[pRoom->BSPPolyHead[i].NumVertices];
		fread((pStcS->ptexcoord),sizeof(TEXCOORD),pRoom->BSPPolyHead[i].NumVertices,file);
		pStcS++;


		// Read the index of this Poly's Front poly
		fread(&Num,sizeof(WORD),1,file);
		// Set the front poly's address of this poly
		if(Num)
			pRoom->BSPPolyHead[i].front = &(pRoom->BSPPolyHead[Num]);
		else
			pRoom->BSPPolyHead[i].front = NULL;
	
		// Read the index of this Poly's Back poly
		fread(&Num,sizeof(WORD),1,file);
		// Set the front poly's address of this poly
		if(Num)
			pRoom->BSPPolyHead[i].back = &(pRoom->BSPPolyHead[Num]);
		else
			pRoom->BSPPolyHead[i].back = NULL;

		// Set the Polygon's Color Changed Value
		pRoom->BSPPolyHead[i].ColorChanged = FALSE;
	}

	// Read the no. of components
	fread(&(pRoom->NumComponents),sizeof(WORD),1,file);
	// Allocate memory for the room's components
	pRoom->Components = new COMPONENT[pRoom->NumComponents];

	float fReflectiveBrightness,CAniT2;
	for(i=0;i<pRoom->NumComponents;i++)
	{
		// Read the Component's type & brightness
		fread(&(pRoom->Components[i].TexTableIndex),sizeof(WORD),1,file);
		fread(&(pRoom->Components[i].HasAlpha  ),sizeof(char),1,file);
		fread(&(pRoom->Components[i].IsGlass   ),sizeof(char),1,file);
		fread(&fReflectiveBrightness,sizeof(float),1,file);
		fread(&(pRoom->Components[i].NumAniFrames),sizeof(char),1,file);
		if(pRoom->Components[i].NumAniFrames > 0)
		{
			fread(&(pRoom->Components[i].AniTS),sizeof(float),1,file);
			fread(&CAniT2,sizeof(float),1,file);

			pRoom->Components[i].AniTDiff = CAniT2 - pRoom->Components[i].AniTS;
		}
		else
		{
			pRoom->Components[i].AniTS    =
			pRoom->Components[i].AniTDiff = 0.0f;
		}
		fread(&(pRoom->Components[i].Energy    ),sizeof(char),1,file);
		fread(&(pRoom->Components[i].HitChecked),sizeof(char),1,file);
		

		// Set the current animation frame to index 0
		pRoom->Components[i].CurrAniFrame   = 0;
		pRoom->Components[i].CurrentAniTime = 0.0f;
		pRoom->Components[i].NextAniTime    = 0.0f;


		// Set the color of reflection of this component
		if(fReflectiveBrightness > 0.0f)
		{
			pRoom->Components[i].IsReflective = TRUE;
			pRoom->Components[i].ReflectiveBrightness = D3DRGB(fReflectiveBrightness,
															   fReflectiveBrightness,
															   fReflectiveBrightness);
		}
		else
		{
			pRoom->Components[i].IsReflective = FALSE;
		}

		// Read the no. of polys for this component
		fread(&(pRoom->Components[i].NumPolyIndices),sizeof(WORD),
														1,file);

		// Allocate memory for the Component's poly indices
		pRoom->Components[i].PolyIndices = 
						new WORD[pRoom->Components[i].NumPolyIndices];
		
		// Read this component's poly indices
		fread(pRoom->Components[i].PolyIndices,sizeof(WORD),
							pRoom->Components[i].NumPolyIndices,file);

		// Load the component's shadow texture,
		// if the component is not ENERGY type
		pRoom->Components[i].ShadowMapTexture = NULL;
		if(!pRoom->Components[i].Energy)
		{
			char TextureFileName[100];
			sprintf(TextureFileName,"Temp\\R%dC%d.dds",RoomInd,i);
			if(FAILED(LoadDDSTexture(TextureFileName,&(pRoom->Components[i].ShadowMapTexture))))
			{
				*RoomPtr = NULL;
				g_ErrStr = "Unable to load Shadow Map";
				return (file);
			}
		}
	}

	// Allocate memory for storing the component drawing lists
	// Count the no. of solid components(Without Alpha)
	WORD NumNonTranspComps=0;
	for(i=0;i<pRoom->NumComponents;i++)
		if(!(pRoom->Components[i].HasAlpha))
			NumNonTranspComps++;
	// Allocate memory for the Solid Component Drawing List
	pRoom->SCompDrawingList = new COMPONENT *[NumNonTranspComps];

	WORD NumTranspPolys=0;
	for(i=0;i<pRoom->NumComponents;i++)
		if(pRoom->Components[i].HasAlpha)
			NumTranspPolys += pRoom->Components[i].NumPolyIndices;
	pRoom->TCompDrawingList = new TRANSPARENT_COMP_DRAWING_LIST_NODE[NumTranspPolys];


	// Read the no. of Non-Ambient Room Lights
	// and store them to the NonAmbLights Array
	// (after allocating memory for it)
	
	WORD	NumNonAmbLights;
	TLIGHT	TLight; // A Temp Light
	// Read the no. of Non-Amb Lights
	fread(&NumNonAmbLights,sizeof(WORD),1,file);

	if(NumNonAmbLights > 0)
	{
		// Allocate memory for the Non-Amb Lights Array
		pRoom->NonAmbLights = new NONAMBLIGHT[NumNonAmbLights];

		// Read the Non-Amb Lights
		for(i=0;i<NumNonAmbLights;i++)
		{
			// Read the light data into the tmp struct
			fread(&TLight,(sizeof(float) * 11),1,file);
		
			// Copy the contents of the temp struct to the
			// real non-amb light struct
			pRoom->NonAmbLights[i].x = TLight.x;
			pRoom->NonAmbLights[i].y = TLight.y;
			pRoom->NonAmbLights[i].z = TLight.z;
			pRoom->NonAmbLights[i].x2 = TLight.x2;
			pRoom->NonAmbLights[i].y2 = TLight.y2;
			pRoom->NonAmbLights[i].z2 = TLight.z2;
			pRoom->NonAmbLights[i].Radius = TLight.Radius;
			pRoom->NonAmbLights[i].Brightness = 0.0f;
			pRoom->NonAmbLights[i].R = TLight.R * TLight.Brightness;
			pRoom->NonAmbLights[i].G = TLight.G * TLight.Brightness;
			pRoom->NonAmbLights[i].B = TLight.B * TLight.Brightness;

			// Calc the nx,ny,nz vector for spotlights
			if(TLight.x2 || TLight.y2 || TLight.z2)
			{
				float fDum;

				fDum =sqrtf((TLight.x2 - TLight.x)*(TLight.x2 - TLight.x) +
							(TLight.y2 - TLight.y)*(TLight.y2 - TLight.y) +
							(TLight.z2 - TLight.z)*(TLight.z2 - TLight.z));

				if(fDum == 0.0f)
				{
					pRoom->NonAmbLights[i].nx =
					pRoom->NonAmbLights[i].ny =
					pRoom->NonAmbLights[i].nz = 0.0f;
				}
				else
				{
					pRoom->NonAmbLights[i].nx = (TLight.x2 - TLight.x) / fDum;
					pRoom->NonAmbLights[i].ny = (TLight.y2 - TLight.y) / fDum;
					pRoom->NonAmbLights[i].nz = (TLight.z2 - TLight.z) / fDum;
				}
			}
			else
			{
				pRoom->NonAmbLights[i].nx =
				pRoom->NonAmbLights[i].ny =
				pRoom->NonAmbLights[i].nz = 0.0f;
			}

			// Set the next pointer
			pRoom->NonAmbLights[i].next = &(pRoom->NonAmbLights[i+1]);
		}
		// Set the last light's next pointer to NULL
		pRoom->NonAmbLights[i-1].next = NULL;
	}


	// Read the Room's Waters
	fread(&(pRoom->NumWaters),sizeof(WORD),1,file);
	if(pRoom->NumWaters > 0)
	{
		pRoom->RoomWaters = new WATER[pRoom->NumWaters];
		for(i=0;i<pRoom->NumWaters;i++)
		{
			fread(&(pRoom->RoomWaters[i].y),sizeof(float)*4+sizeof(WORD),1,file);
			pRoom->RoomWaters[i].BoundingPolyInds = new WORD[pRoom->RoomWaters[i].NumBoundingPolys];
			fread((pRoom->RoomWaters[i].BoundingPolyInds),sizeof(WORD),pRoom->RoomWaters[i].NumBoundingPolys,file);
		}
	}


	// Read the Room's Extents
	fread(&(pRoom->Rx1),sizeof(float),1,file);
	fread(&(pRoom->Ry1),sizeof(float),1,file);
	fread(&(pRoom->Rz1),sizeof(float),1,file);
	fread(&(pRoom->Rx2),sizeof(float),1,file);
	fread(&(pRoom->Ry2),sizeof(float),1,file);
	fread(&(pRoom->Rz2),sizeof(float),1,file);


	// Calculate the Room's Poly's Normals
	for(i=0;i<pRoom->NumBSPPolys;i++)
	{
		// Calculate this poly's Normal
		CalcPolyNormal(&(pRoom->BSPPolyHead[i]),pRoom);

		// Calculate this poly's Side Normals
		CalcPolySideNormal(&(pRoom->BSPPolyHead[i]),pRoom);

		// Calculate this poly's 2nd LightMap Normal
		CalcPolyLightMapNormal2(&(pRoom->BSPPolyHead[i]),pRoom);
	}


	// Set the polygon's parent component
	// Also, allocate memory for the Component's
	// triangle vertex index buffer
	
	DWORD TotRoomTriInds=0;
	for(i=0;i<pRoom->NumComponents;i++)
	{
		DWORD TotCompTriInds=0;

		for(int j=0;j<pRoom->Components[i].NumPolyIndices;j++)
		{
			// Set the parent component
			pRoom->BSPPolyHead[pRoom->Components[i].PolyIndices[j]].ParentComponent = &(pRoom->Components[i]);
			
			// Add the poly's triangles to the total
			TotCompTriInds +=(pRoom->BSPPolyHead[pRoom->Components[i].PolyIndices[j]].NumVertices) +
						 (pRoom->BSPPolyHead[pRoom->Components[i].PolyIndices[j]].NumVertices - 3) * 2;
		}

		// Allocate memory for this component's triangle indices
		pRoom->Components[i].TriVertInds = new WORD[TotCompTriInds];
		pRoom->Components[i].eTriVertInds= pRoom->Components[i].TriVertInds + TotCompTriInds;

		// Add this component's tri-indices to the room's tri indices
		TotRoomTriInds += TotCompTriInds;
	}
	// Allocate memory for the Room's Tri-Inds
	pRoom->RoomVertInds = new WORD[TotRoomTriInds];

	
	// Calculate the size necessary for the room's VBs
	// and set the poly's drawing vertices
	pRoom->VBCapacity = 0;
	for(i=0;i<pRoom->NumBSPPolys;i++)
	for(int j=0;j<pRoom->BSPPolyHead[i].NumVertices;j++)
		pRoom->BSPPolyHead[i].DIndices[j] = pRoom->VBCapacity++;
				
	///////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////
	// Create and Fill all the Room's  Vertex Buffers	//
	//////////////////////////////////////////////////////

	// Give a description for the Room's VBs
	D3DVERTEXBUFFERDESC vbdesc;
	ZeroMemory( &vbdesc, sizeof(D3DVERTEXBUFFERDESC) );
	vbdesc.dwSize        = sizeof(D3DVERTEXBUFFERDESC);
	vbdesc.dwCaps        = D3DVBCAPS_SYSTEMMEMORY;
	vbdesc.dwFVF         = D3DFVF_XYZ;
	vbdesc.dwNumVertices = pRoom->VBCapacity;

	// Create the Untransformed VB
	if( FAILED( lpD3D->CreateVertexBuffer( &vbdesc, &(pRoom->UntransformedRoomVB), 0L ) ) )
	{
		*RoomPtr = NULL;
		g_ErrStr = "Unable to create vertex buffer(U-VB)";
		return (file);
	}

	// Set Caps & Vertex Format for the Transformed VB
	vbdesc.dwFVF         = D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX4;

	// Create the Transformed VB
	if( FAILED( lpD3D->CreateVertexBuffer( &vbdesc, &(pRoom->TransformedRoomVB), 0L ) ) )
    {
		*RoomPtr = NULL;
		g_ErrStr = "Unable to create vertex buffer(T-VB)";
		return (file);
	}
	
	// Lock & Fill the Untransformed VB with Vertex Coordinate Data
	UNTRANSFORMED_VERTEX *pUTVertices;
	if( SUCCEEDED( pRoom->UntransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pUTVertices,
                                          NULL ) ) )
    {
		for(i=0;i<pRoom->NumBSPPolys;i++)
		for(int j=0;j<pRoom->BSPPolyHead[i].NumVertices;j++)
		{
			pUTVertices->x = pRoom->RoomVerts[pRoom->BSPPolyHead[i].Indices[j]].x;
			pUTVertices->y = pRoom->RoomVerts[pRoom->BSPPolyHead[i].Indices[j]].y;
			pUTVertices->z = pRoom->RoomVerts[pRoom->BSPPolyHead[i].Indices[j]].z;

			pUTVertices++;
		}

        pRoom->UntransformedRoomVB->Unlock();
    }


	// Lock & Fill the Transformed VB with 
	// Color and Texture Data
	TRANSFORMED_VERTEX *pTVertices,*pTVerticesOri;
	if( SUCCEEDED( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
                                          NULL ) ) )
    {
		pTVerticesOri = pTVertices;
		pStcS = pStexcoord;

		// Fill the color and tex coord data
		for(i=0;i<pRoom->NumBSPPolys;i++)
		{
			for(int j=0;j<pRoom->BSPPolyHead[i].NumVertices;j++)
			{
				pTVertices->color	 = WHITE;

				pTVertices->tuB = pBtexcoord[pRoom->BSPPolyHead[i].Indices[j]].tu;
				pTVertices->tvB = pBtexcoord[pRoom->BSPPolyHead[i].Indices[j]].tv;
				pTVertices->tuS = pStcS->ptexcoord[j].tu;
				pTVertices->tvS = pStcS->ptexcoord[j].tv;

				pTVertices++;
			}

			pStcS++;
		}

		// Unlock the Transformed VB
        pRoom->TransformedRoomVB->Unlock();
    }


	// Optimize the Untransformed VB
	pRoom->UntransformedRoomVB->Optimize(lpD,0);


	// free the temp allocations
	delete(pBtexcoord);
	for(pStcS=pStexcoord;pStcS<pStcE;pStcS++)
		delete(pStcS->ptexcoord);
	delete(pStexcoord);


	*RoomPtr = pRoom;

	return(file);
}




/////////////////////////////////////////////////////////////////////
// Process Room Vertices
/////////////////////////////////////////////////////////////////////

inline void ProcessRoomVBVertices(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	// Process Vertices
	pRoom->TransformedRoomVB->ProcessVertices(D3DVOP_TRANSFORM | D3DVOP_CLIP,
										0,pRoom->VBCapacity,
										pRoom->UntransformedRoomVB,0,
										lpD,D3DPV_DONOTCOPYDATA);
}




/////////////////////////////////////////////////////////////////////
// Set Room Triangles that have to be Drawn
/////////////////////////////////////////////////////////////////////

void SetRoomDrawingTriangles(ROOM *pRoom, D3DVECTOR *ViewPos)
{

	// Vars used for bsp walking
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackDist;
	float			Dist;
	WORD			*ppoly_index,*ppoly_end_index;
	COMPONENT		**pSComp;
	COMPONENT		*pLastComponent=NULL;
	WORD			*ppoly_vert_index;
	float			nx,ny,nz,mulVal;


	// Lock the transformed vertex buffer to fill it with
	// the reflection coords
	TRANSFORMED_VERTEX *pTVertices;
	if( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices, NULL ) != D3D_OK)
		return;

	
	// Initialize the component's vars
	for(int i=0;i<pRoom->NumComponents;i++)
	 if(pRoom->Components[i].HasAlpha)
		 pRoom->Components[i].Triind = pRoom->Components[i].eTriVertInds;
	 else
		pRoom->Components[i].Triind = pRoom->Components[i].TriVertInds;
	
	 
	// Set the end ptrs to the beginning of the comp drawing lists
	pRoom->eSCompDrawingList = pRoom->SCompDrawingList;
	pRoom->eTCompDrawingList = pRoom->TCompDrawingList;


	ppoly = pRoom->BSPPolyHead;
	pStackP = pRoom->StackP;
	pStackDist = pRoom->StackOB;

	
	for(;;)
	{
		while(ppoly)
		{
			Dist = PERPDISTP(ViewPos,ppoly);
				
			*pStackP++ = ppoly; *pStackDist++ = Dist;

			if(Dist > 0.0f)
				ppoly = ppoly->front;
			else
				ppoly = ppoly->back;
		}

		if(pStackP > pRoom->StackP)
		{
			ppoly = *(--pStackP); Dist = *(--pStackDist);

			// Copy only polygons that face frontwards,
			if(Dist > 0.0f)
			{

				ppoly_end_index	= ppoly->DIndices + ppoly->NumVertices;


				// Set the poly's reflective coords
				/////////////////////////////////////////////////
				if(ppoly->ParentComponent->IsReflective)
				{
					ppoly_vert_index = ppoly->Indices;
					
					// The polygon is a wall type
					if(ppoly->ny < 0.57735f && ppoly->ny > -0.57735f)
					{						
						// The normal of the polygon is approx.
						// along the z axis.
						if(ppoly->nz < 0.57735f && ppoly->nz > -0.57735f)
						{
							for(ppoly_index = ppoly->DIndices;
								ppoly_index < ppoly_end_index;
								ppoly_index++,ppoly_vert_index++)
							{
								nx = pRoom->RoomVerts[*ppoly_vert_index].x - g_Face.x;
								ny = pRoom->RoomVerts[*ppoly_vert_index].y - g_Face.y;
								nz = pRoom->RoomVerts[*ppoly_vert_index].z - g_Face.z;
								mulVal = 0.5f / sqrtf(nx*nx + ny*ny + nz*nz);

								pTVertices[*ppoly_index].tuR = nz*mulVal + 0.5f;
								pTVertices[*ppoly_index].tvR = ny*mulVal + 0.5f;
							}
						}
						// The normal of the polygon is approx.
						// along the x axis.
						else
						{
							for(ppoly_index = ppoly->DIndices;
								ppoly_index < ppoly_end_index;
								ppoly_index++,ppoly_vert_index++)
							{
								nx = pRoom->RoomVerts[*ppoly_vert_index].x - g_Face.x;
								ny = pRoom->RoomVerts[*ppoly_vert_index].y - g_Face.y;
								nz = pRoom->RoomVerts[*ppoly_vert_index].z - g_Face.z;
								mulVal = 0.5f / sqrtf(nx*nx + ny*ny + nz*nz);

								pTVertices[*ppoly_index].tuR = nx*mulVal + 0.5f;
								pTVertices[*ppoly_index].tvR = ny*mulVal + 0.5f;
							}
						}
					}
					// The polygon is a floor or ceiling type
					else
					{
						for(ppoly_index = ppoly->DIndices;
							ppoly_index < ppoly_end_index;
							ppoly_index++,ppoly_vert_index++)
						{
							nx = pRoom->RoomVerts[*ppoly_vert_index].x - g_Face.x;
							ny = pRoom->RoomVerts[*ppoly_vert_index].y - g_Face.y;
							nz = pRoom->RoomVerts[*ppoly_vert_index].z - g_Face.z;
							mulVal = 0.5f / sqrtf(nx*nx + ny*ny + nz*nz);

							pTVertices[*ppoly_index].tuR = nx*mulVal + 0.5f;
							pTVertices[*ppoly_index].tvR = nz*mulVal + 0.5f;
						}
					}
				}

				/////////////////////////////////////////////////
				// continue with setting the drawing triangles...


				ppoly_index = ppoly->DIndices;

				if(ppoly->ParentComponent->HasAlpha) // Transp Comp
				{
					ppoly->ParentComponent->Triind -= (ppoly->NumVertices - 2)*3;

					// Copy the first triangle
					*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
					*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
					*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
				
					// Copy the remaining triangles
					for( ; ppoly_index < ppoly_end_index ; )
					{
						*(ppoly->ParentComponent->Triind)++ = *(ppoly->DIndices);
						*(ppoly->ParentComponent->Triind)++ = *(ppoly->ParentComponent->Triind - 2);
						*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
					}

					ppoly->ParentComponent->Triind -= (ppoly->NumVertices - 2)*3;


					// If the poly's parent component is the same as
					// the previous poly's parent component then just
					// update the starting pointer of the drawing
					// list's last batch.
					// Otherwise if not then add this component as a
					// new batch into the transp comp drawing list
					// and set it's starting pointer.
					if(ppoly->ParentComponent != pLastComponent)
					{
						pRoom->eTCompDrawingList->pTComp =
						pLastComponent = ppoly->ParentComponent;

						pRoom->eTCompDrawingList->pStartInd = ppoly->ParentComponent->Triind;
						pRoom->eTCompDrawingList->pEndInd	= ppoly->ParentComponent->Triind + (ppoly->NumVertices - 2)*3;
						pRoom->eTCompDrawingList++;
					}
					else
					{
						(pRoom->eTCompDrawingList - 1)->pStartInd = ppoly->ParentComponent->Triind;
					}
				}
				else
				{
					// Copy the first triangle
					*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
					*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
					*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
				
					// Copy the remaining triangles
					for( ; ppoly_index < ppoly_end_index ; )
					{
						*(ppoly->ParentComponent->Triind)++ = *(ppoly->DIndices);
						*(ppoly->ParentComponent->Triind)++ = *(ppoly->ParentComponent->Triind - 2);
						*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
					}

					// See if it is a new component and add it to
					// the S(solid) component drawing list

					for(pSComp = pRoom->SCompDrawingList;
						pSComp < pRoom->eSCompDrawingList;
						pSComp++)
					{
						if(ppoly->ParentComponent == *pSComp)
							break;
					}

					if(pSComp == pRoom->eSCompDrawingList)
						*(pRoom->eSCompDrawingList)++ = ppoly->ParentComponent;
				}
			}


			if(Dist > 0.0f)
				ppoly = ppoly->back;
			else
				ppoly = ppoly->front;
		}
		else
			break;
	}

	pRoom->TransformedRoomVB->Unlock();
}


/////////////////////////////////////////////////////////////////////
// Draw the Solid Room Components
/////////////////////////////////////////////////////////////////////

void DrawRoomSolidComponentsShadowMaps(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	COMPONENT **pComp;

	for(pComp = pRoom->SCompDrawingList;
		pComp < pRoom->eSCompDrawingList;
		pComp++)
	{
		// Don't draw an energy polygon(no shadowmap)
		if((*pComp)->Energy) continue;

  		// Set the component's shadow map texture
		lpD->SetTexture(0,(*pComp)->ShadowMapTexture);

		// Draw
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									(*pComp)->TriVertInds,
									((*pComp)->Triind - (*pComp)->TriVertInds),
									0);
	}
}

void DrawRoomSolidComponentsNormalPolys(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	COMPONENT **pComp;

	for(pComp = pRoom->SCompDrawingList;
		pComp < pRoom->eSCompDrawingList;
		pComp++)
	{
		// Don't draw an energy polygon
		if((*pComp)->Energy) continue;

		// Set the component's Base Texture on stage 0
		// Also add the current animation frame index
		lpD->SetTexture(0,g_Textures[((*pComp)->TexTableIndex + (*pComp)->CurrAniFrame)]);

		// Draw
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									(*pComp)->TriVertInds,
									((*pComp)->Triind - (*pComp)->TriVertInds),
									0);
	}
}

void DrawRoomSolidComponentsEnergyPolys(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	COMPONENT **pComp;

	for(pComp = pRoom->SCompDrawingList;
		pComp < pRoom->eSCompDrawingList;
		pComp++)
	if((*pComp)->Energy)
	{
		// Set the component's Base Texture on stage 0
		// Also add the current animation frame index
		lpD->SetTexture(0,g_Textures[((*pComp)->TexTableIndex + (*pComp)->CurrAniFrame)]);

		// Draw
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									(*pComp)->TriVertInds,
									((*pComp)->Triind - (*pComp)->TriVertInds),
									0);
	}
}

/////////////////////////////////////////////////////////////////////
// Draw the Solid Room Components Reflections
/////////////////////////////////////////////////////////////////////

void DrawRoomSolidComponentsReflections(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	COMPONENT **pComp;

	for(pComp = pRoom->SCompDrawingList;
		pComp < pRoom->eSCompDrawingList;
		pComp++)
	if((*pComp)->IsReflective)
	{
		// Draw
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									(*pComp)->TriVertInds,
									((*pComp)->Triind - (*pComp)->TriVertInds),
									0);
	}
}



/////////////////////////////////////////////////////////////////////
// Draw the Room Transparent Components
/////////////////////////////////////////////////////////////////////

void DrawRoomTranspComponents(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	TRANSPARENT_COMP_DRAWING_LIST_NODE *pComp;
	BOOLEAN   EnergyPolyStagesSet=FALSE;

	for(pComp = pRoom->eTCompDrawingList - 1;
		pComp >= pRoom->TCompDrawingList;
		pComp--)
	{
		if(pComp->pTComp->Energy)
		{
			if(!EnergyPolyStagesSet)
			{
				EnergyPolyStagesSet = TRUE;

				// Set the proper blending stage
				lpD->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_ONE);
				// Disable texture stage 1
				lpD->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
				// Set the texture on stage 1 to NULL to prevent a memory leak
				lpD->SetTexture(1,NULL);
			}
		}
		else
		{
			if(EnergyPolyStagesSet)
			{
				EnergyPolyStagesSet = FALSE;

				// Set the proper blending stage
				lpD->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_INVSRCALPHA);
				// Enable texture stage 1
				lpD->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE);
			}

			// Set the component's Shadow Texture on stage 1
			lpD->SetTexture(1,pComp->pTComp->ShadowMapTexture);
		}

		// Set the component's Base Texture on stage 0
		// Also add the current animation frame index
		lpD->SetTexture(0,g_Textures[(pComp->pTComp->TexTableIndex + pComp->pTComp->CurrAniFrame)]);

		// Draw
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									pComp->pStartInd,
									pComp->pEndInd - pComp->pStartInd,
									0);
	}


	// Restore the states before leaving
	if(EnergyPolyStagesSet)
	{
		// Set the proper blending stage
		lpD->SetRenderState(D3DRENDERSTATE_DESTBLEND,D3DBLEND_INVSRCALPHA);
		// Enable texture stage 1
		lpD->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE);
	}
}




/////////////////////////////////////////////////////////////////////
// Draw the Room Transparent Components Reflections
/////////////////////////////////////////////////////////////////////

void DrawRoomTranspComponentsReflections(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	TRANSPARENT_COMP_DRAWING_LIST_NODE *pComp;

	for(pComp = pRoom->eTCompDrawingList - 1;
		pComp >= pRoom->TCompDrawingList;
		pComp--)
	if(pComp->pTComp->IsReflective)
	{
		// Set the component's Shadow Texture on stage 1
		lpD->SetTexture(1,pComp->pTComp->ShadowMapTexture);

		// Draw
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									pComp->pStartInd,
									pComp->pEndInd - pComp->pStartInd,
									0);
	}
}



////////////////////////////////////////////////////////////////////
//	Draw the corona of the non-ambient lights of the Room
////////////////////////////////////////////////////////////////////

void DrawRoomNonAmbLightCoronas(ROOM *pRoom)
{
	NONAMBLIGHT		*pL;
	D3DMATRIX		tMat;
	float			Dist,CoronaPower;
	BOOLEAN			CoronaVisible;

	// Draw this Room's Coronas
	for(pL = pRoom->NonAmbLights; pL ; pL = pL->next)
	{
		if((pL->x - g_Face.x)*g_ViewDir.x +
		   (pL->y - g_Face.y)*g_ViewDir.y +
		   (pL->z - g_Face.z)*g_ViewDir.z < 0.0f)
		    CoronaVisible = FALSE;
		// See if the corona is obstructed by the Room Geometry
		else if(IsLightCoronaVisible(pL,pRoom))
		{
			CoronaVisible = TRUE;

			// See if the corona is obstructed by
			// any other viewable Room's Geometry
			for(WORD k=0;k<pRoom->NumViewableRooms;k++)
				if(!IsLightCoronaVisible(pL,Rooms[pRoom->ViewableRooms[k]]))
				{	CoronaVisible = FALSE; break; }
		}
		else
			CoronaVisible = FALSE;
		
		if(CoronaVisible)
		{
			// If not full(1.0f) brightness then increase it
			if(pL->Brightness < 1.0f)
			{
				pL->Brightness += g_Elapsed * 4.0f;
				// Make sure we don't go beyond full(1.0f)
				if(pL->Brightness > 1.0f)
					pL->Brightness = 1.0f;
			}
		}
		else
		{
			// Avoid drawing Coronas with less than a certain brightness
			if(pL->Brightness < 0.01f)
				continue;
			
			// The Corona is not visible any more, so decrease its
			// brightness
			pL->Brightness -= g_Elapsed * 2.0f;	
			// Make sure we don't get -ve brightness
			if(pL->Brightness < 0.0f)
				pL->Brightness = 0.0f;
		}
	
		// Find the Dist b/w the Light and our eyes
		Dist =	(pL->x - g_Face.x)*(pL->x - g_Face.x) + 
				(pL->y - g_Face.y)*(pL->y - g_Face.y) + 
				(pL->z - g_Face.z)*(pL->z - g_Face.z);


		// Set the Translation according to the light's position
		g_BillboardMatrix._41 = pL->x -g_Face.x;
		g_BillboardMatrix._42 = pL->y -g_Face.y;
		g_BillboardMatrix._43 = pL->z -g_Face.z;

		// Rotate the Billboard Matrix
		D3DUtil_MatrixMultiply(tMat,g_RotationMatrix,g_BillboardMatrix);

		// Set the Scale
		if(Dist > pL->Radius * 250.0f)
			tMat._11 = tMat._22 = pL->Radius * 0.25f;
		else
			tMat._11 = tMat._22 = pL->Radius * 0.125f + Dist * 0.0005f;

		
		// This is the place where the spot light's MOHAA effect
		// is implemented (ie. As you look more directly at a
		// spot light, the corona becomes more powerful).

		// Calc the Corona power for spotlights
		if(pL->x2 || pL->y2 || pL->z2)
		{
			CoronaPower = pL->nx * (g_Face.x - pL->x) +
						  pL->ny * (g_Face.y - pL->y) +
						  pL->nz * (g_Face.z - pL->z);

			if(Dist == 0.0f)
				CoronaPower = 0.0f;
			else
				CoronaPower /= sqrtf(Dist);

			// We must not get -ve CoronaPower
			if(CoronaPower < 0.0f)
				CoronaPower = 0.0f;
		}
		else  // For pointlights corona power remains 1.0f
			CoronaPower = 1.0f;

		// Adjust the size of the corona according
		// to the CoronaPower
		tMat._11 *= CoronaPower;
		tMat._22 *= CoronaPower;


		// Set the World Matrix
		g_lpDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, &tMat);
 
		// Set the color of the Light(based on Brightness and CoronaPower)
		DWORD tColor = D3DRGB(	pL->R * pL->Brightness * CoronaPower,
								pL->G * pL->Brightness * CoronaPower,
								pL->B * pL->Brightness * CoronaPower
							 );
		g_BillboardVerts[0].color = tColor;
		g_BillboardVerts[1].color = tColor;
		g_BillboardVerts[2].color = tColor;
		g_BillboardVerts[3].color = tColor;

		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,g_BillboardVerts,4,0);
	}



	// Draw this Room's Viewable Room's Coronas
	for(WORD j=0;j<pRoom->NumViewableRooms;j++)
	for(pL = Rooms[pRoom->ViewableRooms[j]]->NonAmbLights;
		pL;
		pL = pL->next)
	{
		if((pL->x - g_Face.x)*g_ViewDir.x +
		   (pL->y - g_Face.y)*g_ViewDir.y +
		   (pL->z - g_Face.z)*g_ViewDir.z < 0.0f)
		    CoronaVisible = FALSE;
		// See if the corona is obstructed by this Room's Geometry
		else if(IsLightCoronaVisible(pL,pRoom))
		{
			CoronaVisible = TRUE;

			// See if the corona is obstructed by
			// any other viewable Room's Geometry
			for(WORD k=0;k<pRoom->NumViewableRooms;k++)
				if(!IsLightCoronaVisible(pL,Rooms[pRoom->ViewableRooms[k]]))
				{	CoronaVisible = FALSE; break; }
		}
		else
			CoronaVisible = FALSE;

		if(CoronaVisible)
		{
			// If not full(1.0f) brightness then increase it
			if(pL->Brightness < 1.0f)
			{
				pL->Brightness += g_Elapsed * 4.0f;
				// Make sure we don't go beyond full(1.0f)
				if(pL->Brightness > 1.0f)
					pL->Brightness = 1.0f;
			}
		}
		else
		{
			// Avoid drawing Coronas with less than a certain brightness
			if(pL->Brightness < 0.01f)
				continue;
			
			// The Corona is not visible any more, so decrease its
			// brightness
			pL->Brightness -= g_Elapsed * 2.0f;
			// Make sure we don't get -ve brightness
			if(pL->Brightness < 0.0f)
				pL->Brightness = 0.0f;
		}

		// Find the Dist b/w the Light and our eyes
		Dist =	(pL->x - g_Face.x)*(pL->x - g_Face.x) + 
				(pL->y - g_Face.y)*(pL->y - g_Face.y) + 
				(pL->z - g_Face.z)*(pL->z - g_Face.z);

		// Set the Translation according to the light's position
		g_BillboardMatrix._41 = pL->x -g_Face.x;
		g_BillboardMatrix._42 = pL->y -g_Face.y;
		g_BillboardMatrix._43 = pL->z -g_Face.z;

		// Rotate the Billboard Matrix
		D3DUtil_MatrixMultiply(tMat,g_RotationMatrix,g_BillboardMatrix);

		// Set the Scale
		if(Dist > pL->Radius * 250.0f)
			tMat._11 = tMat._22 = pL->Radius * 0.25f;
		else
			tMat._11 = tMat._22 = pL->Radius * 0.125f + Dist * 0.0005f;

		
		// This is the place where the spot light's MOHAA effect
		// is implemented (ie. As you look more directly at a
		// spot light, the corona becomes more powerful).

		// Calc the Corona power for spotlights
		if(pL->x2 || pL->y2 || pL->z2)
		{
			CoronaPower = pL->nx * (g_Face.x - pL->x) +
						  pL->ny * (g_Face.y - pL->y) +
						  pL->nz * (g_Face.z - pL->z);

			if(Dist == 0.0f)
				CoronaPower = 0.0f;
			else
				CoronaPower /= sqrtf(Dist);

			// We must not get -ve CoronaPower
			if(CoronaPower < 0.0f)
				CoronaPower = 0.0f;
		}
		else  // For pointlights corona power remains 1.0f
			CoronaPower = 1.0f;

		// Adjust the size of the corona according
		// to the CoronaPower
		tMat._11 *= CoronaPower;
		tMat._22 *= CoronaPower;


		// Set the World Matrix
		g_lpDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, &tMat);
 
		// Set the color of the Light(based on Brightness and CoronaPower)
		DWORD tColor = D3DRGB(	pL->R * pL->Brightness * CoronaPower,
								pL->G * pL->Brightness * CoronaPower,
								pL->B * pL->Brightness * CoronaPower
							 );
		g_BillboardVerts[0].color = tColor;
		g_BillboardVerts[1].color = tColor;
		g_BillboardVerts[2].color = tColor;
		g_BillboardVerts[3].color = tColor;

		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,g_BillboardVerts,4,0);
	}

}



/////////////////////////////////////////////////////////////////////
//	Cleans up a Room
/////////////////////////////////////////////////////////////////////

void CleanupRoom(ROOM *pRoom)
{
	// Delete the Room's NonAmbLights Array
	SafeDelete(pRoom->NonAmbLights);

	//////////////////////////////////////////////////////////////
	//	Delete the Room's Connected,Viewable index storage buffers
	//////////////////////////////////////////////////////////////
	SafeDelete(pRoom->ConnectedRooms);
	SafeDelete(pRoom->ViewableRooms);
	
	/////////////////////////////////////////////
	//		Release the Room's Index Buffer		
	/////////////////////////////////////////////
	
	// Delete the Room's Index Buffer
	SafeDelete(pRoom->RoomVertInds);
	
	//////////////////////////////////////
	//		Release the Room's Vertices
	//////////////////////////////////////

	// Delete the Room's Vertices
	SafeDelete(pRoom->RoomVerts);


	//////////////////////////////////////
	//		Release the Room's Waters
	//////////////////////////////////////

	// Delete the Room's Waters
	for(int i=0;i<pRoom->NumWaters;i++)
		SafeDelete(pRoom->RoomWaters[i].BoundingPolyInds);
	SafeDelete(pRoom->RoomWaters);


	//////////////////////////////////
	// Release the Room's Stacks
	//////////////////////////////////

	// Delete the Room's Stacks
	SafeDelete(pRoom->StackP);
	SafeDelete(pRoom->StackOB);
	SafeDelete(pRoom->StackNC);


	//////////////////////////////////
	//	Release the Room's Polys
	//////////////////////////////////

	for(i=0;i<pRoom->NumBSPPolys;i++)
	{
		// Delete the Room's Poly's drawing Indices
		SafeDelete(pRoom->BSPPolyHead[i].DIndices);
	
		// Delete the Room's Poly's Indices
		SafeDelete(pRoom->BSPPolyHead[i].Indices);
	
		// Delete the Room's Poly's Normals
		SafeDelete(pRoom->BSPPolyHead[i].Normals);
	}


	// Delete the Room's BSP Polys
	SafeDelete(pRoom->BSPPolyHead);
	

	//////////////////////////////////////
	//	Release the Room's Components
	//////////////////////////////////////

	for(i=0;i<pRoom->NumComponents;i++)
	{
		// Release the component's shadow map texture
		SafeRelease(pRoom->Components[i].ShadowMapTexture);

		// Delete the component's Vertex indices
		SafeDelete(pRoom->Components[i].PolyIndices);
		SafeDelete(pRoom->Components[i].TriVertInds);
	}

	// Delete the Room's Components
	SafeDelete(pRoom->Components);

	// Delete the component drawing lists
	SafeDelete(pRoom->SCompDrawingList);
	SafeDelete(pRoom->TCompDrawingList);
	
	//////////////////////////////////////
	// Release the Room's Vertex Buffers
	//////////////////////////////////////

	SafeRelease(pRoom->UntransformedRoomVB);
	SafeRelease(pRoom->TransformedRoomVB);


	//////////////////////////////////////
	// Release the Room itself
	//////////////////////////////////////

	SafeDelete(pRoom);

}



#define SET_CHANGED_POLYS_ONLY			0
#define SET_REFLECTIVE_POLYS_ONLY		1
#define	SET_ALL_POLYS_UNDERWATER		2

inline void SetRoomPolysColors(ROOM *pRoom,
							   WORD  Flags)
{
	POLYGON *pPoly  = pRoom->BSPPolyHead;
	POLYGON *epPoly = pPoly + pRoom->NumBSPPolys;
	WORD	*i,*ei;
	DWORD	PColor;

	TRANSFORMED_VERTEX *pTVertices;
	if( SUCCEEDED( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
				                                  NULL ) ) )
	{
		// check the flags
		if(Flags == SET_CHANGED_POLYS_ONLY)
		{
			if(g_bFaceIsUnderWater)
			{
				// Go thru the polys and only if the
				// color changed set it to UnderWaterColor
				for( ; pPoly < epPoly ; pPoly++)
				if(pPoly->ColorChanged)
				{
					// Set back the color changed flag
					pPoly->ColorChanged = FALSE;

					i = pPoly->DIndices;
					ei = i + pPoly->NumVertices;

					for(; i < ei ; i++)
						pTVertices[*i].color = g_UnderWaterColor;
				}
			}
			else
			{
				// Go thru the polys and only if the
				// color changed set it to WHITE
				for( ; pPoly < epPoly ; pPoly++)
				if(pPoly->ColorChanged)
				{
					// Set back the color changed flag
					pPoly->ColorChanged = FALSE;

					i = pPoly->DIndices;
					ei = i + pPoly->NumVertices;

					for(; i < ei ; i++)
						pTVertices[*i].color = WHITE;
				}
			}
		}
		else if(Flags == SET_REFLECTIVE_POLYS_ONLY)
		{
			// Go thru the polys and only if the
			// poly is reflective, set it to its
			// Component's Reflective Brightness Color
			for( ; pPoly < epPoly ; pPoly++)
			if(pPoly->ParentComponent->IsReflective)
			{
				// Set the color changed flag
				pPoly->ColorChanged = TRUE;

				i = pPoly->DIndices;
				ei = i + pPoly->NumVertices;

				PColor = pPoly->ParentComponent->ReflectiveBrightness;
				for(; i < ei ; i++)
					pTVertices[*i].color = PColor;
			}
		}
		else if(Flags == SET_ALL_POLYS_UNDERWATER)
		{
			// Set all polys to UnderWaterColor
			for( ; pPoly < epPoly ; pPoly++)
			{
				// Set the color changed flag
				pPoly->ColorChanged = FALSE;

				i = pPoly->DIndices;
				ei = i + pPoly->NumVertices;

				for(; i < ei ; i++)
					pTVertices[*i].color = g_UnderWaterColor;
			}
		}
			

		pRoom->TransformedRoomVB->Unlock();
	}
}

