

/////////////////////////////////////////////////////////////////////
//
//
//			This File Handles Input for the Application
//
//
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//					Some Defines
/////////////////////////////////////////////////////////////////////

// Some custom mouse button defines
#define		DIK_LEFTMOUSEBUTTON		256
#define		DIK_RIGHTMOUSEBUTTON	257
#define		DIK_MIDDLEMOUSEBUTTON	258




/////////////////////////////////////////////////////////////////////
//
//					Global Vars
//
/////////////////////////////////////////////////////////////////////


// Global User-Definable Key Vars,
WORD		g_KI_WalkForward	= DIK_UP;	
WORD		g_KI_WalkBackward	= DIK_DOWN;
WORD		g_KI_StepLeft		= DIK_LEFT;
WORD		g_KI_StepRight		= DIK_RIGHT;
WORD		g_KI_Crouch			= DIK_NUMPAD0;
WORD		g_KI_Jump			= DIK_RIGHTMOUSEBUTTON;
WORD		g_KI_TurnLeft		= DIK_NUMPAD4;
WORD		g_KI_TurnRight		= DIK_NUMPAD6;
WORD		g_KI_ZoomIn			= DIK_ADD;
WORD		g_KI_ZoomOut		= DIK_SUBTRACT;


// The corresponding boolean flags of the Global User-
// Definable Key Vars.

// These flags indicate wether the keys are 'Hit' or not
BOOLEAN		g_bKI_HWalkForward	= FALSE;
BOOLEAN		g_bKI_HWalkBackward	= FALSE;
BOOLEAN		g_bKI_HStepLeft		= FALSE;
BOOLEAN		g_bKI_HStepRight	= FALSE;
BOOLEAN		g_bKI_HCrouch		= FALSE;
BOOLEAN		g_bKI_HJump			= FALSE;
BOOLEAN		g_bKI_HTurnLeft		= FALSE;
BOOLEAN		g_bKI_HTurnRight	= FALSE;
BOOLEAN		g_bKI_HZoomIn		= FALSE;
BOOLEAN		g_bKI_HZoomOut		= FALSE;

// These flags indicate wether the keys are Pressed or not
BOOLEAN		g_bKI_PWalkForward	= FALSE;
BOOLEAN		g_bKI_PWalkBackward	= FALSE;
BOOLEAN		g_bKI_PStepLeft		= FALSE;
BOOLEAN		g_bKI_PStepRight	= FALSE;
BOOLEAN		g_bKI_PCrouch		= FALSE;
BOOLEAN		g_bKI_PJump			= FALSE;
BOOLEAN		g_bKI_PTurnLeft		= FALSE;
BOOLEAN		g_bKI_PTurnRight	= FALSE;
BOOLEAN		g_bKI_PZoomIn		= FALSE;
BOOLEAN		g_bKI_PZoomOut		= FALSE;




// Global Mouse Input vars
//-------------------------
// The time elapsed since the last mouse input
float		g_TimeElapsedSinceLastMouseInput = 0.0f;

// The time between each mouse input. The default
// mouse input rate(0.02) is approx. 50 times a second,
// but it is user customizable.
float		g_TimeBetweenEachMouseInput = 0.02f;

// The sensitivity of the mouse. This is also user customizable.
// The values range from 0.0 to 1.0 (default is 0.1)
float		g_MouseSensitivity = 0.1f;


// Global Keyboard Input vars
//----------------------------
// The time elapsed since the last keyboard input
float		g_TimeElapsedSinceLastKeyboardInput = 0.0f;

// The time between each keyboard input. The default
// keyboard input rate(0.02) is approx. 50 times a second,
// but it is user customizable.
float		g_TimeBetweenEachKeyboardInput = 0.02f;




/////////////////////////////////////////////////////////////////////
//
//					Function Declarations
//
/////////////////////////////////////////////////////////////////////


void ActUponInputDataBuffer();	// Acts upon the input data buffer



/////////////////////////////////////////////////////////////////////
//
//					Function Definitions
//
/////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
//	Name : HandleMouseInput
//	Desc : Gets input from the mouse if there is one available
//		   If there is valid input data, it returns TRUE,
//		   otherwise it returns FALSE.
/////////////////////////////////////////////////////////////////////
BOOLEAN HandleMouseInput()
{

	// If there is no mouse then return
	if(! g_lpMouse )
		return FALSE;

	// Update the time elapsed since the last mouse input
	g_TimeElapsedSinceLastMouseInput += g_Elapsed;

	// If it is not yet time for the next mouse input
	// then return
	if(g_TimeElapsedSinceLastMouseInput < g_TimeBetweenEachMouseInput)
		return FALSE;

	// Reset the time elapsed since the last mouse input
	g_TimeElapsedSinceLastMouseInput = 0.0f;

	// Get the input from the mouse
	if( g_lpMouse->GetDeviceState( sizeof(DIMOUSESTATE), &g_DIms )
												!= DI_OK)
	{
		// If the device is lost then try to
		// acquire the mouse again, and return
		// without doing anything. If the acquire
		// has succeeded, then we'll get our data
		// the next time we come here.
		g_lpMouse->Acquire();

		return FALSE;
	}

	// Copy the mouse button data to the end of the InputDataBuffer
	g_InputDataBuffer[256] = g_DIms.rgbButtons[0];
	g_InputDataBuffer[257] = g_DIms.rgbButtons[1];
	g_InputDataBuffer[258] = g_DIms.rgbButtons[2];
	g_InputDataBuffer[259] = g_DIms.rgbButtons[3];


	// We've got some valid input data
	// so return TRUE
	return TRUE;
}




/////////////////////////////////////////////////////////////////////
//	Name : HandleKeyboardInput
//	Desc : Gets input from the keyboard if there is one available
//		   If there is valid input data, it returns TRUE,
//		   otherwise it returns FALSE.
/////////////////////////////////////////////////////////////////////
BOOLEAN HandleKeyboardInput()
{

	// If there is no keyboard then return failure
	if(! g_lpKeyboard )
		return FALSE;

	// Update the time elapsed since the last keyboard input
	g_TimeElapsedSinceLastKeyboardInput += g_Elapsed;

	// If it is not yet time for the next keyboard input
	// then return failure
	if(g_TimeElapsedSinceLastKeyboardInput < g_TimeBetweenEachKeyboardInput)
		return FALSE;

	// Reset the time elapsed since the last keyboard input
	g_TimeElapsedSinceLastKeyboardInput = 0.0f;

	// Get the input from the keyboard
	if( g_lpKeyboard->GetDeviceState( 256, g_InputDataBuffer )
													!= DI_OK)
	{
		// If the device is lost then try to
		// acquire the keyboard again, and return
		// without doing anything. If the acquire
		// has succeeded, then we'll get our data
		// the next time we come here.
		g_lpKeyboard->Acquire();

		return FALSE;
	}

	// We've got some valid input data
	// so return TRUE
	return TRUE;
}



/////////////////////////////////////////////////////////////////////
//	Name : HandleInput
//	Desc : Handles the input from the user
/////////////////////////////////////////////////////////////////////
BOOLEAN HandleInput()
{
	
	/////////////////////////////////////////////////////////////////	
	//-------------------------------------------------------
	// Only if all input devices have failed in giving input,
	// then return failure; because we cannot act in such a 
	// situation. If at least one device's input is retrieved
	// then act upon all the devices input.
	//-------------------------------------------------------

	BOOLEAN	bGotValidKI,bGotValidMI;

	bGotValidKI = HandleKeyboardInput();
	bGotValidMI = HandleMouseInput();

	if(!(bGotValidKI || bGotValidMI))
		return FALSE;
	
	/////////////////////////////////////////////////////////////////

	
	/////////////////////////////////////////////////////////////////
	//-------------------------------------------------------
	// Set the Flags for all the keys
	//-------------------------------------------------------
	
	// Set the flag vars for the g_KI_WalkForward key
	if(KEYDOWN(g_KI_WalkForward))
	{
		if(!g_bKI_PWalkForward)
		{
			g_bKI_HWalkForward = TRUE;
			g_bKI_PWalkForward = TRUE;
		}
	}
	else if(g_bKI_PWalkForward)
		g_bKI_PWalkForward = FALSE;

	
	// Set the flag vars for the g_KI_WalkBackward key
	if(KEYDOWN(g_KI_WalkBackward))
	{
		if(!g_bKI_PWalkBackward)
		{
			g_bKI_HWalkBackward = TRUE;
			g_bKI_PWalkBackward = TRUE;
		}
	}
	else if(g_bKI_PWalkBackward)
		g_bKI_PWalkBackward = FALSE;

	
	// Set the flag vars for the g_KI_StepLeft key
	if(KEYDOWN(g_KI_StepLeft))
	{
		if(!g_bKI_PStepLeft)
		{
			g_bKI_HStepLeft = TRUE;
			g_bKI_PStepLeft = TRUE;
		}
	}
	else if(g_bKI_PStepLeft)
		g_bKI_PStepLeft = FALSE;

	
	// Set the flag vars for the g_KI_StepRight key
	if(KEYDOWN(g_KI_StepRight))
	{
		if(!g_bKI_PStepRight)
		{
			g_bKI_HStepRight = TRUE;
			g_bKI_PStepRight = TRUE;
		}
	}
	else if(g_bKI_PStepRight)
		g_bKI_PStepRight = FALSE;

	
	// Set the flag vars for the g_KI_Crouch key
	if(KEYDOWN(g_KI_Crouch))
	{
		if(!g_bKI_PCrouch)
		{
			g_bKI_HCrouch = TRUE;
			g_bKI_PCrouch = TRUE;
		}
	}
	else if(g_bKI_PCrouch)
		g_bKI_PCrouch = FALSE;

	
	// Set the flag vars for the g_KI_Jump key
	if(KEYDOWN(g_KI_Jump))
	{
		if(!g_bKI_PJump)
		{
			g_bKI_HJump = TRUE;
			g_bKI_PJump = TRUE;
		}
	}
	else if(g_bKI_PJump)
		g_bKI_PJump = FALSE;

	
	// Set the flag vars for the g_KI_TurnLeft key
	if(KEYDOWN(g_KI_TurnLeft))
	{
		if(!g_bKI_PTurnLeft)
		{
			g_bKI_HTurnLeft = TRUE;
			g_bKI_PTurnLeft = TRUE;
		}
	}
	else if(g_bKI_PTurnLeft)
		g_bKI_PTurnLeft = FALSE;

	
	// Set the flag vars for the g_KI_TurnRight key
	if(KEYDOWN(g_KI_TurnRight))
	{
		if(!g_bKI_PTurnRight)
		{
			g_bKI_HTurnRight = TRUE;
			g_bKI_PTurnRight = TRUE;
		}
	}
	else if(g_bKI_PTurnRight)
		g_bKI_PTurnRight = FALSE;

	
	// Set the flag vars for the g_KI_ZoomIn key
	if(KEYDOWN(g_KI_ZoomIn))
	{
		if(!g_bKI_PZoomIn)
		{
			g_bKI_HZoomIn = TRUE;
			g_bKI_PZoomIn = TRUE;
		}
	}
	else if(g_bKI_PZoomIn)
		g_bKI_PZoomIn = FALSE;

	
	// Set the flag vars for the g_KI_ZoomOut key
	if(KEYDOWN(g_KI_ZoomOut))
	{
		if(!g_bKI_PZoomOut)
		{
			g_bKI_HZoomOut = TRUE;
			g_bKI_PZoomOut = TRUE;
		}
	}
	else if(g_bKI_PZoomOut)
		g_bKI_PZoomOut = FALSE;

	/////////////////////////////////////////////////////////////////


	/////////////////////////////////////////////////////////////////
	//-----------------------------------------------
	// Act upon the input from the Input Data Buffer
	//-----------------------------------------------
	
	ActUponInputDataBuffer();

	/////////////////////////////////////////////////////////////////
	

	return TRUE;
}


/////////////////////////////////////////////////////////////////////
//	Name : ActUponInput
//	Desc : Acts upon the input in the input data buffer
/////////////////////////////////////////////////////////////////////
void ActUponInputDataBuffer()
{
	// Storage of the last key pressed to
	// eliminate keyboard repeat of keys
	static BYTE LastKeyPressed = 0;


	// If the user pressed escape then
	if(KEYDOWN(DIK_ESCAPE))
	{
		g_AppRunning = FALSE;
		DestroyWindow(g_ApphWnd);
		return;
	}

	
	// Calc the vel of the 'free look'
	g_rotVel	=  g_DIms.lX * g_MouseSensitivity;
	g_lookupVel = -g_DIms.lY * g_MouseSensitivity;



	if(g_bKI_PJump)	// If the jump key was Pressed(not Released)
	{
		
		// Do the jump stuff here
		/////////////////////////

		if(g_bIsUnderWater)
		{
			g_Force.y += STANDMOVEVEL * g_Elapsed * 0.25f;
		}
		else if(g_bKI_HJump)	// Jump
		{	
			// Set the flag back to inactive
			g_bKI_HJump = FALSE;

			// Do the jump
			if(g_bCanDoJump)
			{
				g_Force.y += JUMPVEL;

				g_Force.x += g_frontPtx * g_MoveVel * 4.0f * g_Elapsed;
				g_Force.z += g_frontPtz * g_MoveVel * 4.0f * g_Elapsed;

				g_Force.x += -g_frontPtz * g_StrafeVel * 4.0f * g_Elapsed;
				g_Force.z +=  g_frontPtx * g_StrafeVel * 4.0f * g_Elapsed;
			}
		}
	}



	if(KEYDOWN(g_KI_WalkForward))
	{
		if(g_ManHeight == STANDUPHEIGHT || g_bIsUnderWater)
			g_MoveVel=STANDMOVEVEL;
		else
			g_MoveVel=CROUCHMOVEVEL;
	}
	else if(KEYDOWN(g_KI_WalkBackward))
	{
		if(g_ManHeight == STANDUPHEIGHT || g_bIsUnderWater)
			g_MoveVel=-STANDMOVEVEL;
		else
			g_MoveVel=-CROUCHMOVEVEL;
	}
	else
	{
		g_MoveVel=0.0f;
	}



	if(KEYDOWN(g_KI_StepRight))
	{
		if(g_ManHeight == STANDUPHEIGHT || g_bIsUnderWater)
			g_StrafeVel=-STANDMOVEVEL;
		else
			g_StrafeVel=-CROUCHMOVEVEL;
	}
	else if(KEYDOWN(g_KI_StepLeft))
	{
		if(g_ManHeight == STANDUPHEIGHT || g_bIsUnderWater)
			g_StrafeVel=STANDMOVEVEL;
		else
			g_StrafeVel=CROUCHMOVEVEL;
	}
	else
	{
		g_StrafeVel=0.0f;
	}



	if(KEYDOWN(DIK_Z))
	{
		if(g_ZoomValue > 0.5f)
		{
			g_ZoomValue = 0.5f;
			D3DUtil_SetProjectionMatrix(g_ProjMatrix, g_ZoomValue, 0.75f, FRONT_CULL_PLANE_DIST, BACK_CULL_PLANE_DIST);
			g_lpDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&g_ProjMatrix);
		}
	}
	else
	{
		if(g_ZoomValue < 1.57f)
		{
			g_ZoomValue = 1.57f;
			D3DUtil_SetProjectionMatrix(g_ProjMatrix, g_ZoomValue, 0.75f, FRONT_CULL_PLANE_DIST, BACK_CULL_PLANE_DIST);
			g_lpDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&g_ProjMatrix);
		}
	}


	if(KEYDOWN(DIK_1))
	{
		if(LastKeyPressed != DIK_1)
		{
			g_bDrawDynamicLights = !g_bDrawDynamicLights;
			LastKeyPressed = DIK_1;
		}
	}
	else if(LastKeyPressed == DIK_1)
		LastKeyPressed = 0;


	if(KEYDOWN(DIK_2))
	{
		if(LastKeyPressed != DIK_2)
		{
			g_bDrawUserSpotLight = !g_bDrawUserSpotLight;

			if(g_bDrawUserSpotLight)
			{
				// Allocate a Spot Light for the user
				UserSpotLight = GetNewGLptr();
				UserSpotLight->Brightness	= 1.0f;
				UserSpotLight->Radius		= 300.0f;
				UserSpotLight->R			= 1.0f;
				UserSpotLight->G			= 1.0f;
				UserSpotLight->B			= 0.9f;
				UserSpotLight->Brightness_by_Radius =// Not necessary for spot lights
							UserSpotLight->Brightness / UserSpotLight->Radius;
				UserSpotLight->one_by_2Radius = // Is necessary for both, point and spot lights
							1.0f / (2.0f * UserSpotLight->Radius);
			}
			else
			{
				ReturnUsedGLptr(UserSpotLight);
			}

			LastKeyPressed = DIK_2;
		}
	}
	else if(LastKeyPressed == DIK_2)
		LastKeyPressed = 0;


	if(KEYDOWN(DIK_3))
	{
		if(LastKeyPressed != DIK_3)
		{
			g_bDrawUserPointLight = !g_bDrawUserPointLight;

			if(g_bDrawUserPointLight)
			{
				// Allocate a Point Light for the user
				UserPointLight = GetNewGLptr();
				UserPointLight->Brightness	= 1.0f;
				UserPointLight->Radius		= 300.0f;
				UserPointLight->R			= 1.0f;
				UserPointLight->G			= 1.0f;
				UserPointLight->B			= 0.9f;
				UserPointLight->Brightness_by_Radius =// Not necessary for spot lights
							UserPointLight->Brightness / UserPointLight->Radius;
				UserPointLight->one_by_2Radius = // Is necessary for both, point and spot lights
							1.0f / (2.0f * UserPointLight->Radius);
				UserPointLight->x2			=
				UserPointLight->y2			=
				UserPointLight->z2			= 0.0f;
			}
			else
			{
				ReturnUsedGLptr(UserPointLight);
			}

			LastKeyPressed = DIK_3;
		}
	}
	else if(LastKeyPressed == DIK_3)
		LastKeyPressed = 0;


	if(KEYDOWN(DIK_H))
	{
		if(LastKeyPressed != DIK_H)
		{
			g_bHitChecking = !g_bHitChecking;
			LastKeyPressed = DIK_H;
		}
	}
	else if(LastKeyPressed == DIK_H)
		LastKeyPressed = 0;

	
	if(KEYDOWN(DIK_G))
	{
		if(LastKeyPressed != DIK_G)
		{
			g_bGravityEnabled = !g_bGravityEnabled; g_tGravity = 0.0f;
			LastKeyPressed = DIK_G;
		}
	}
	else if(LastKeyPressed == DIK_G)
		LastKeyPressed = 0;
	
	if(KEYDOWN(DIK_S))
	{
		if(LastKeyPressed != DIK_S)
		{
			g_bStatusEnabled = !g_bStatusEnabled;
			LastKeyPressed = DIK_S;
		}
	}
	else if(LastKeyPressed == DIK_S)
		LastKeyPressed = 0;

}