
//------ Include Files ------//

#define D3D_OVERLOADS
#define INITGUID
#include <windows.h>
#include <mmsystem.h>
#include <ddraw.h>
#include <d3d.h>
#include <d3dtypes.h>
#include <dinput.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "d3dutil.h"
#include "resource.h"


#include "EngineD&G.h"
#include "TimeHandler.h"
#include "DirectXEnumerate.h"
#include "DirectXHandler.h"
#include "DDSTexHandler.h"
#include "LightMap.h"
#include "HitChecking.h"
#include "Room.h"
#include "InputHandler.h"
#include "InitEngine.h"


#include "AppD&G.h"
#include "InitApp.h"

#include "Cleanup.h"




// ----- Function Definitions -----//

void OutputText( DWORD x, DWORD y, TCHAR* str )
{
    HDC hDC;

    // Get a DC for the surface. Then, write out the buffer
    if( g_lpDDSBack )
    {
        if( SUCCEEDED( g_lpDDSBack->GetDC(&hDC) ) )
        {
            SetBkMode( hDC, TRANSPARENT );
            
			SetTextColor( hDC, RGB(0,0,0) );
            ExtTextOut( hDC, x+1, y+1, 0, NULL, str, lstrlen(str), NULL );
			SetTextColor( hDC, RGB(255,255,255) );
            ExtTextOut( hDC, x, y, 0, NULL, str, lstrlen(str), NULL );
			
            g_lpDDSBack->ReleaseDC(hDC);
        }
    }
}


LRESULT CALLBACK 
WindowProc(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {	   	
		case WM_DESTROY:		// The window is being destroyed

			Cleanup();			// Do Cleanup
            PostQuitMessage(0);	// Post a quit message
            break;

	    case WM_SETCURSOR:		// The mouse was moved and it's input was not captured

			SetCursor(NULL);	// Set the cursor to NULL(remove it)
	        break;


        default:
            return DefWindowProc(hWnd, uMsg, wParam, lParam);
    }
	
	return 0L;
}


void RenderFrame()
{

	// Restore the surfaces if they are lost
	RestoreLostSurfaces();


	// increment viewer position
	
	g_rotAngle+=g_rotVel*g_Elapsed;
	// correct the angle of rotation
	if(g_rotAngle > 6.283185f) g_rotAngle -= 6.283185f;
	if(g_rotAngle < 0.0f) g_rotAngle += 6.283185f;


	g_lookupAngle+=g_lookupVel*g_Elapsed;
	// Restrict the angle of elevation
	if(g_lookupAngle > 1.570796f) g_lookupAngle = 1.570796f;
	else if(g_lookupAngle < -1.570796f) g_lookupAngle = -1.570796f;



	
	g_bFeetIsUnderWater = FALSE;
	for(int i=0;i<CurrRoom->NumWaters;i++)
	{
		if(g_Face.y - STANDUPHEIGHT < CurrRoom->RoomWaters[i].y)
		{
			for(int j=0;j<CurrRoom->RoomWaters[i].NumBoundingPolys;j++)
				if(CURRPERPDISTV(g_Face,(CurrRoom->BSPPolyHead + CurrRoom->RoomWaters[i].BoundingPolyInds[j])) < 0.0f)
					break;

			if(j == CurrRoom->RoomWaters[i].NumBoundingPolys)
				g_bFeetIsUnderWater = TRUE;

			if(j == CurrRoom->RoomWaters[i].NumBoundingPolys &&
			   g_Face.y - MINDIST * 1.5f < CurrRoom->RoomWaters[i].y)
			{
				if(!g_bIsUnderWater)
				{
					g_bIsUnderWater = TRUE;
					g_tGravity = 0.0f;
				}

				if(g_Face.y - MINDIST < CurrRoom->RoomWaters[i].y)
				{
					if(g_Face.y > CurrRoom->RoomWaters[i].y)
					{
						float MulVal = (g_Face.y - CurrRoom->RoomWaters[i].y) * ONE_BY_MINDIST;
						float One_Minus_MulVal = 1.0f - MulVal;

						g_UnderWaterColor = D3DRGB(CurrRoom->RoomWaters[i].R * One_Minus_MulVal + MulVal,
												 CurrRoom->RoomWaters[i].G * One_Minus_MulVal + MulVal,
												 CurrRoom->RoomWaters[i].B * One_Minus_MulVal + MulVal);

						// Set the Water Color for all Polys
						SetRoomPolysColors(CurrRoom, SET_ALL_POLYS_UNDERWATER);
						for(j=0;j<CurrRoom->NumViewableRooms;j++)
							SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
													SET_ALL_POLYS_UNDERWATER);

						if(g_bFaceIsUnderWater)
						{
							g_bFaceIsUnderWater = FALSE;
							g_bSetNonWaterColor = TRUE;
						}
					}
					else if(!g_bFaceIsUnderWater)
					{
						g_bFaceIsUnderWater = TRUE;

						g_UnderWaterColor = D3DRGB(CurrRoom->RoomWaters[i].R,
												 CurrRoom->RoomWaters[i].G,
												 CurrRoom->RoomWaters[i].B);

						// Set the Water Color for all Polys
						SetRoomPolysColors(CurrRoom, SET_ALL_POLYS_UNDERWATER);
						for(j=0;j<CurrRoom->NumViewableRooms;j++)
							SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
													SET_ALL_POLYS_UNDERWATER);
					}
				}
				else if(g_bFaceIsUnderWater)
				{
					g_bFaceIsUnderWater = FALSE;
					g_bSetNonWaterColor = TRUE;
				}


				break;
			}
		}
	}

	if(g_bIsUnderWater && (i == CurrRoom->NumWaters))
	{
		// We're not under water anymore
		g_bIsUnderWater = FALSE;
	}

	if((g_bFaceIsUnderWater || g_bSetNonWaterColor) && (i == CurrRoom->NumWaters))
	{
		g_bSetNonWaterColor = FALSE;
		g_bFaceIsUnderWater = FALSE;
		g_UnderWaterColor = WHITE;
		// Set the Water Color for all Polys
		SetRoomPolysColors(CurrRoom, SET_ALL_POLYS_UNDERWATER);
		for(int j=0;j<CurrRoom->NumViewableRooms;j++)
			SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
									SET_ALL_POLYS_UNDERWATER);
	}

	if(g_bFaceIsUnderWater)
	{
		g_UnderWaterDistortion += g_UnderWaterDistortionInc * g_Elapsed;

		if(g_UnderWaterDistortion > 0.77f)
		{
			g_UnderWaterDistortion = 0.77f;
			g_UnderWaterDistortionInc = -0.025f;
		}
		else if(g_UnderWaterDistortion < 0.73f)
		{
			g_UnderWaterDistortion = 0.73f;
			g_UnderWaterDistortionInc = 0.025f;
		}
		
		// Set projection matrix. 
		D3DUtil_SetProjectionMatrix(g_ProjMatrix, g_ZoomValue, g_UnderWaterDistortion, FRONT_CULL_PLANE_DIST, BACK_CULL_PLANE_DIST );
		g_lpDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&g_ProjMatrix);

	}
	else if(g_UnderWaterDistortion != 0.75f)
	{
		if(g_UnderWaterDistortion > 0.75f)
		{
			g_UnderWaterDistortion -= 0.025f * g_Elapsed;
			if(g_UnderWaterDistortion < 0.75f)
				g_UnderWaterDistortion = 0.75f;
		}
		else if(g_UnderWaterDistortion < 0.75f)
		{
			g_UnderWaterDistortion += 0.025f * g_Elapsed;
			if(g_UnderWaterDistortion > 0.75f)
				g_UnderWaterDistortion = 0.75f;
		}

		// Set projection matrix. 
		D3DUtil_SetProjectionMatrix(g_ProjMatrix, g_ZoomValue, g_UnderWaterDistortion, FRONT_CULL_PLANE_DIST, BACK_CULL_PLANE_DIST );
		g_lpDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&g_ProjMatrix);
	}
	


	if(g_bGravityEnabled)
	{
		// Calc lean Angle (view blob)
		if((g_MoveVel || g_StrafeVel) && g_bIsOnGround)
		{
			if(g_walkleanDir)
			{
				g_leanAngle += 0.1f * g_Elapsed;
				if(g_leanAngle > 0.01745329f)
				{	
					g_leanAngle = 0.01745329f;
					g_walkleanDir = 0;
				}
			}
			else
			{
				g_leanAngle -= 0.1f * g_Elapsed;
				if(g_leanAngle < -0.01745329f)
				{	
					g_leanAngle = -0.01745329f;
					g_walkleanDir = 1;
				}
			}
		}
		else if(g_leanAngle)
		{
			if(g_leanAngle > 0.0f)
			{
				g_leanAngle -= 0.05f * g_Elapsed;
				if(g_leanAngle < 0.0f) g_leanAngle = 0.0f;
			}
			else
			{	
				g_leanAngle += 0.1f * g_Elapsed;
				if(g_leanAngle > 0.0f) g_leanAngle = 0.0f;
			}
		}

	}

	//////////////////////////////////////////////
	//		Calculate the Rotation Matrix		//
	//////////////////////////////////////////////

    D3DUtil_SetIdentityMatrix(g_RotationMatrix);
	// Produce and combine the rotation matrices.
	D3DMATRIX	TempMat;	// A temp matrix
    D3DUtil_SetRotateZMatrix(TempMat, g_leanAngle);	// roll
    D3DUtil_MatrixMultiply(g_RotationMatrix,g_RotationMatrix,TempMat);
	D3DUtil_SetRotateXMatrix(TempMat, g_lookupAngle);	// pitch
	D3DUtil_MatrixMultiply(g_RotationMatrix,g_RotationMatrix,TempMat);
	D3DUtil_SetRotateYMatrix(TempMat,-g_rotAngle);	// yaw
	D3DUtil_MatrixMultiply(g_RotationMatrix,g_RotationMatrix,TempMat);

	//////////////////////////////////////////////
	//		Calculate the Billboard Matrix		//
	//////////////////////////////////////////////

    D3DUtil_SetIdentityMatrix(g_BillboardMatrix);
	// Produce and combine the rotation matrices.
	D3DUtil_SetRotateYMatrix(TempMat,  g_rotAngle);	// yaw
	D3DUtil_MatrixMultiply(g_BillboardMatrix,g_BillboardMatrix,TempMat);
	D3DUtil_SetRotateXMatrix(TempMat, -g_lookupAngle);	// pitch
	D3DUtil_MatrixMultiply(g_BillboardMatrix,g_BillboardMatrix,TempMat);
	D3DUtil_SetRotateZMatrix(TempMat, -g_leanAngle);	// roll
    D3DUtil_MatrixMultiply(g_BillboardMatrix,g_BillboardMatrix,TempMat);
	
	///////////////////////////////////////////////

	

	// calculate the next position
	g_frontPtz = cosf(g_rotAngle);
	g_frontPtx = sinf(g_rotAngle);

	// calculate the looking at direction and the normal to it
	g_ViewDir.y = sinf(g_lookupAngle);
	g_ViewNorm.y = cosf(g_lookupAngle);
	g_ViewDir.z = g_frontPtz * g_ViewNorm.y;
	g_ViewDir.x = g_frontPtx * g_ViewNorm.y;
	g_ViewNorm.z = -g_frontPtz * g_ViewDir.y;
	g_ViewNorm.x = -g_frontPtx * g_ViewDir.y;

	// Decrease the force
	if(g_bGravityEnabled)
	{
		if(g_bIsUnderWater)
			g_Force -= g_Force * g_Elapsed * 2.0f;
		else
		{
			if(g_bIsOnGround || g_bFeetIsUnderWater)
				g_Force = g_Force * powf(0.9f,g_Elapsed*50.0f);
			else
			{
//				g_Force.y = g_Force.y * g_Elapsed * 5.0f;
				g_Force.x = g_Force.x * powf(0.999f,g_Elapsed*50.0f);
				g_Force.z = g_Force.z * powf(0.999f,g_Elapsed*50.0f);
			}
		}
	}
	else
	{
		g_Force = g_Force * powf(0.9f,g_Elapsed*50.0f);
	}

	if(g_bGravityEnabled)
	{
		if(g_bIsUnderWater)
		{
			g_Force += g_ViewDir * g_MoveVel * 0.2f * g_Elapsed;

			g_Force.x += -g_frontPtz * g_StrafeVel * 0.2f * g_Elapsed;
			g_Force.z +=  g_frontPtx * g_StrafeVel * 0.2f * g_Elapsed;

			g_Force.y -= WATERGRAVITY * g_Elapsed;

			g_O = g_Face;
			g_N = g_Face + g_Force * g_Elapsed;
		}
		else
		{
			if(g_bFeetIsUnderWater)
			{
				g_Force.x += g_frontPtx * g_MoveVel * 0.2f * g_Elapsed;
				g_Force.z += g_frontPtz * g_MoveVel * 0.2f * g_Elapsed;

				g_Force.x += -g_frontPtz * g_StrafeVel * 0.2f * g_Elapsed;
				g_Force.z +=  g_frontPtx * g_StrafeVel * 0.2f * g_Elapsed;
			}
			else
			{
				if(g_bIsOnGround)
				{
					g_Force.x += g_frontPtx * g_MoveVel * g_Elapsed;
					g_Force.z += g_frontPtz * g_MoveVel * g_Elapsed;

					g_Force.x += -g_frontPtz * g_StrafeVel * g_Elapsed;
					g_Force.z +=  g_frontPtx * g_StrafeVel * g_Elapsed;
				}
				else
				{
					g_Force.x += g_frontPtx * g_MoveVel * 0.2f * g_Elapsed;
					g_Force.z += g_frontPtz * g_MoveVel * 0.2f * g_Elapsed;

					g_Force.x += -g_frontPtz * g_StrafeVel * 0.2f * g_Elapsed;
					g_Force.z +=  g_frontPtx * g_StrafeVel * 0.2f * g_Elapsed;
				}
			}

			g_Force.y -= LANDGRAVITY * g_Elapsed * g_tGravity;
			g_tGravity = 1.0f;

			g_Feet.x = g_Face.x; g_Feet.z = g_Face.z;
			g_Feet.y = g_Face.y - g_ManHeight - 0.1f;

			g_O = g_Face; g_N = g_Feet;
			g_StandUpForce = 0.0f;
			g_bCanDoJump = FALSE;
			g_bIsOnGround = FALSE;

			if(g_bHitChecking)
			{
				if(!DoFeetHitChecking(CurrRoom,&g_O,&g_N))
				{
					for(WORD i=0;i<CurrRoom->NumConnectedRooms;i++)
					if(DoFeetHitChecking(Rooms[CurrRoom->ConnectedRooms[i]],&g_O,&g_N))
					 break;
				}
			}

			g_O = g_Face;
			g_N = g_Face + g_Force * g_Elapsed;
			g_N.y += g_StandUpForce;
		}
	}
	else
	{
		g_Force += g_ViewDir * g_MoveVel * 2.0f * g_Elapsed;

		g_Force.x += -g_frontPtz * g_StrafeVel * 2.0f * g_Elapsed;
		g_Force.z +=  g_frontPtx * g_StrafeVel * 2.0f * g_Elapsed;

		g_O = g_Face;
		g_N = g_Face + g_Force * g_Elapsed;
	}


	// Do some simple hit checking
	if(g_N.y <		-MAX_MOVEABLE_DIST) { g_N.y = -MAX_MOVEABLE_DIST; g_tGravity = 0.0f; }
	else if(g_N.y >	 MAX_MOVEABLE_DIST)	  g_N.y =  MAX_MOVEABLE_DIST;
	if(g_N.x <		-MAX_MOVEABLE_DIST)	  g_N.x = -MAX_MOVEABLE_DIST;
	else if(g_N.x >	 MAX_MOVEABLE_DIST)	  g_N.x =  MAX_MOVEABLE_DIST;
	if(g_N.z <		-MAX_MOVEABLE_DIST)	  g_N.z = -MAX_MOVEABLE_DIST;
	else if(g_N.z >	 MAX_MOVEABLE_DIST)	  g_N.z =  MAX_MOVEABLE_DIST;

	// Set the man's height depending on the crouch status
	if(g_bKI_PCrouch == FALSE)  // Crouch Released
		g_ManHeight = STANDUPHEIGHT;
	else						// Crouch Pressed
	{
		if(g_bCanDoJump && g_ManHeight == STANDUPHEIGHT)
			g_Force.y -= STANDUPFORCE;

		g_ManHeight = CROUCHHEIGHT;
	}


	// Do the Hit-Checking with the Face
	ROOM *NextCurrRoom=NULL;
	if(g_bHitChecking)
	{
		DoFaceHitChecking(CurrRoom,&g_O,&g_N);

		for(WORD i=0;i<CurrRoom->NumConnectedRooms;i++)
		{
			DoFaceHitChecking(Rooms[CurrRoom->ConnectedRooms[i]],&g_O,&g_N);
			
			if(!NextCurrRoom)
			if(VEC_IN_ROOM(g_N,Rooms[CurrRoom->ConnectedRooms[i]]))
				NextCurrRoom = Rooms[CurrRoom->ConnectedRooms[i]];
		}
		if(	NextCurrRoom &&
		   !VEC_IN_ROOM(g_N,CurrRoom))
				CurrRoom = NextCurrRoom;
	}

	
	g_Face = g_N; 	// Update the position of the face

	// Set the man's move vel depending on his height
	if(g_ManHeight == CROUCHHEIGHT && !g_bIsUnderWater)
	{	if(g_MoveVel > 0.0f) g_MoveVel = CROUCHMOVEVEL;
		else if(g_MoveVel < 0.0f) g_MoveVel = -CROUCHMOVEVEL;
		if(g_StrafeVel > 0.0f) g_StrafeVel = CROUCHMOVEVEL;
		else if(g_StrafeVel < 0.0f) g_StrafeVel = -CROUCHMOVEVEL;
	}
	else
	{	if(g_MoveVel > 0.0f) g_MoveVel = STANDMOVEVEL;
		else if(g_MoveVel < 0.0f) g_MoveVel = -STANDMOVEVEL;
		if(g_StrafeVel > 0.0f) g_StrafeVel = STANDMOVEVEL;
		else if(g_StrafeVel < 0.0f) g_StrafeVel = -STANDMOVEVEL;
	}






	// Animate the textures of the current room
	for(i=0;i<CurrRoom->NumComponents;i++)
		if(CurrRoom->Components[i].NumAniFrames)
		{
			CurrRoom->Components[i].CurrentAniTime += g_Elapsed;

			if(CurrRoom->Components[i].CurrentAniTime >
				CurrRoom->Components[i].NextAniTime)
			{
				CurrRoom->Components[i].CurrAniFrame++;
				if(CurrRoom->Components[i].CurrAniFrame >
					CurrRoom->Components[i].NumAniFrames)
					 CurrRoom->Components[i].CurrAniFrame=0;

				CurrRoom->Components[i].CurrentAniTime = 0.0f;

				if(CurrRoom->Components[i].AniTDiff > 0.0f)
				{
					CurrRoom->Components[i].NextAniTime =
						CurrRoom->Components[i].AniTS +
						CurrRoom->Components[i].AniTDiff * rand()/RAND_MAX;
				}
				else
				{
					CurrRoom->Components[i].NextAniTime =
						CurrRoom->Components[i].AniTS;
				}										
			}
		}

	// Animate the textures of the current room's viewable rooms
	ROOM *pRoom;
	for(int j=0;j<CurrRoom->NumViewableRooms;j++)
	{
		pRoom = Rooms[CurrRoom->ViewableRooms[j]];
		
		for(int i=0;i<pRoom->NumComponents;i++)
			if(pRoom->Components[i].NumAniFrames)
			{
				pRoom->Components[i].CurrentAniTime += g_Elapsed;

				if(pRoom->Components[i].CurrentAniTime >
					pRoom->Components[i].NextAniTime)
				{
					pRoom->Components[i].CurrAniFrame++;
					if(pRoom->Components[i].CurrAniFrame >
						pRoom->Components[i].NumAniFrames)
						 pRoom->Components[i].CurrAniFrame=0;

					pRoom->Components[i].CurrentAniTime = 0.0f;

					if(pRoom->Components[i].AniTDiff > 0.0f)
					{
						pRoom->Components[i].NextAniTime =
							pRoom->Components[i].AniTS +
							pRoom->Components[i].AniTDiff * rand()/RAND_MAX;
					}
					else
					{
						pRoom->Components[i].NextAniTime =
							pRoom->Components[i].AniTS;
					}										
				}
			}
	}
	


	// Update the properties of a user spot light(debug only)
	//--------------------------------------------------------
	if(	g_bDrawDynamicLights)
	{
		if(g_bDrawUserSpotLight)
		{
			UserSpotLight->x  = g_Face.x;
			UserSpotLight->y  = g_Face.y;
			UserSpotLight->z  = g_Face.z;
			UserSpotLight->x2 = g_Face.x + g_ViewDir.x * 500.0f;
			UserSpotLight->y2 = g_Face.y + g_ViewDir.y * 500.0f;
			UserSpotLight->z2 = g_Face.z + g_ViewDir.z * 500.0f;
			UserSpotLight->nx = -g_ViewDir.x;
			UserSpotLight->ny = -g_ViewDir.y;
			UserSpotLight->nz = -g_ViewDir.z;
		}

		if(g_bDrawUserPointLight)
		{
			UserPointLight->x  = g_Face.x;
			UserPointLight->y  = g_Face.y;
			UserPointLight->z  = g_Face.z;
		}
	}


	// Clear the z-buffer
    g_lpDevice->Clear(0,NULL,D3DCLEAR_ZBUFFER,0,1.0f,0);


	// Start the scene render
	if( SUCCEEDED( g_lpDevice->BeginScene() ) ) 
	{


///////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////
		//			Draw the Static Stuff			//
		//////////////////////////////////////////////

///////////////////////////////////////////////////////////////////


	    // Set the World Matrix Transformation
		// First set the Translation
		D3DUtil_SetTranslateMatrix(g_WorldMatrix, -g_Face);
		// Then set the Rotation
		D3DUtil_MatrixMultiply(g_WorldMatrix,g_RotationMatrix,g_WorldMatrix);
		// Set the World Matrix
		g_lpDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, &g_WorldMatrix);



		//////////////////////////////////////
		//	Process Room VB Vertices
		//////////////////////////////////////


		// Process the room verts
		ProcessRoomVBVertices(CurrRoom,g_lpDevice);
		// Process the Viewable room's vertices
		for(int j=0;j<CurrRoom->NumViewableRooms;j++)
		 ProcessRoomVBVertices(Rooms[CurrRoom->ViewableRooms[j]],g_lpDevice);
			
		
		// Set the Drawing triangles
		SetRoomDrawingTriangles(CurrRoom,&g_Face);
		// Set the Viewable room's Drawing Triangles
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
		 SetRoomDrawingTriangles(Rooms[CurrRoom->ViewableRooms[j]],&g_Face);


		
		//===========================================================
////////// Draw the sky here
//////////
		//===========================================================

		// Turn off the Z-buffer
		// (because nothing goes behind the sky)
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZENABLE, FALSE);
		// Set the 'clamp' addressing mode to ensure that the 
		// edges of the sky-box are properly drawn
		g_lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS, D3DTADDRESS_CLAMP );

		// Enable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
		{
			if(g_bDoTriLinearMipMapFiltering)
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
			else
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_POINT);
		}

		// Draw the Bottom of the Skybox
		g_lpDevice->SetTexture(0,g_SkyBoxBottomTexture);
		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_LVERTEX,g_SkyBoxBottomVerts,4,0);

		// Draw the Top of the Skybox
		g_lpDevice->SetTexture(0,g_SkyBoxTopTexture);
		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_LVERTEX,g_SkyBoxTopVerts,4,0);
		
		// Draw the Left of the Skybox
		g_lpDevice->SetTexture(0,g_SkyBoxLeftTexture);
		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_LVERTEX,g_SkyBoxLeftVerts,4,0);

		// Draw the Right of the Skybox
		g_lpDevice->SetTexture(0,g_SkyBoxRightTexture);
		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_LVERTEX,g_SkyBoxRightVerts,4,0);

		// Draw the Front of the Skybox
		g_lpDevice->SetTexture(0,g_SkyBoxFrontTexture);
		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_LVERTEX,g_SkyBoxFrontVerts,4,0);

		// Draw the Back of the Skybox
		g_lpDevice->SetTexture(0,g_SkyBoxBackTexture);
		g_lpDevice->DrawPrimitive(D3DPT_TRIANGLEFAN,D3DFVF_LVERTEX,g_SkyBoxBackVerts,4,0);

		// Disable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_NONE);

		// Set back the wrap addressing mode
		g_lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS, D3DTADDRESS_WRAP );
		// Turn on Z-buffer
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZENABLE, TRUE);

		//----------------------------------------------------------


		
		//////////////////////////////////////
		//	Draw the room's triangles
		//////////////////////////////////////

		
		
		//========================================================
////////// Normal Polygons(Solid components - Shadow maps)
////////// (We're drawing the shadow maps first)
		//========================================================

		//----------------------------------------------------------
		// Set the Proper Color
		//----------------------------------------------------------

		// Set the CurRoom's changed poly's colors to WHITE
		SetRoomPolysColors(CurrRoom, SET_CHANGED_POLYS_ONLY);
		// Set the CurRoom's Viewable Room's changed poly's
		// colors to WHITE
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
			SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
											SET_CHANGED_POLYS_ONLY);

		//----------------------------------------------------------
		// Set some stages for rendering
		//----------------------------------------------------------

		// Enable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
		{
			if(g_bDoTriLinearMipMapFiltering)
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
			else
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_POINT);
		}

		// Set the Texcoords for the proper stages
		g_lpDevice->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 1);
		
		//----------------------------------------------------------
		// Render stuff
		//----------------------------------------------------------

		// Draw the Room's Solid Components Shadow Maps
		DrawRoomSolidComponentsShadowMaps(CurrRoom,g_lpDevice);
		// Draw the Viewable Room's Solid Components Shadow Maps
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
		 DrawRoomSolidComponentsShadowMaps(Rooms[CurrRoom->ViewableRooms[j]],g_lpDevice);

		//----------------------------------------------------------
		// Set back the stages after rendering
		//----------------------------------------------------------

		// Disable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_NONE);

		// Set the Texcoords for the proper stages
		g_lpDevice->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);

		//----------------------------------------------------------


		
		//========================================================
////////// Dynamic Lights for Solid components
////////// (Next, we add the dynamic light maps)
		//========================================================

		if(g_bDrawDynamicLights) // Switch to turn dynamic lights on/off
		{

		//----------------------------------------------------------
		// Set some stages for rendering
		//----------------------------------------------------------

			// Set the LightMap Texture
			g_lpDevice->SetTexture(0,g_lpLightMapTexture);


			// No mip-map filtering is applied because the
			// light-map texture does not have mip map levels


			// Apply the appropriate states(or state block)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,		2);
			g_lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,			D3DTADDRESS_CLAMP );
			g_lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
			g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
			g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_ONE);
			g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_INVSRCCOLOR);

		//----------------------------------------------------------
		// Render stuff
		//----------------------------------------------------------

			// Draw the current Room's Global Lights for solid comps
			DrawSolidComponentsGlobalLights(CurrRoom,&g_Face,g_lpDevice);
			// Draw the Viewable Room's Global Lights for solid comps
			for(j=0;j<CurrRoom->NumViewableRooms;j++)
			 DrawSolidComponentsGlobalLights(Rooms[CurrRoom->ViewableRooms[j]],&g_Face,g_lpDevice);

		//----------------------------------------------------------
		// Set back the stages after rendering
		//----------------------------------------------------------

			g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,	0);
			g_lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,		D3DTADDRESS_WRAP );
			g_lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
			g_lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);

		//----------------------------------------------------------

		}

		

		//========================================================
////////// Normal Polygons(Solid components - Base textures)
////////// (Finally, we add the base textures)
		//========================================================

		//----------------------------------------------------------
		// Set the Proper Color
		//----------------------------------------------------------
		
		// Set the CurRoom's changed poly's colors to WHITE
		SetRoomPolysColors(CurrRoom, SET_CHANGED_POLYS_ONLY);
		// Set the CurRoom's Viewable Room's changed poly's
		// colors to WHITE
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
			SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
											SET_CHANGED_POLYS_ONLY);
		
		//----------------------------------------------------------
		// Set some stages for rendering
		//----------------------------------------------------------

		// Enable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
		{
			if(g_bDoTriLinearMipMapFiltering)
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
			else
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_POINT);
		}

		//----------------------------------------------------------
		// Render stuff
		//----------------------------------------------------------

		// Draw the Room's Solid Energy Components
		DrawRoomSolidComponentsEnergyPolys(CurrRoom,g_lpDevice);
		// Draw the Viewable Room's Solid Energy Components
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
		 DrawRoomSolidComponentsEnergyPolys(Rooms[CurrRoom->ViewableRooms[j]],g_lpDevice);

		//----------------------------------------------------------
		// Set some stages for rendering
		//----------------------------------------------------------

		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_DESTCOLOR);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_SRCCOLOR);

		//----------------------------------------------------------
		// Render stuff
		//----------------------------------------------------------

		// Draw the Room's Solid Components
		DrawRoomSolidComponentsNormalPolys(CurrRoom,g_lpDevice);
		// Draw the Viewable Room's Solid Components
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
		 DrawRoomSolidComponentsNormalPolys(Rooms[CurrRoom->ViewableRooms[j]],g_lpDevice);

		//----------------------------------------------------------
		// Set back the stages after rendering
		//----------------------------------------------------------

		// Disable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_NONE);

		g_lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
		g_lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);

		//----------------------------------------------------------



		//========================================================
////////// Normal Polygons(Reflections)
////////// (We're drawing the reflections for the normal polys)
		//========================================================

		//----------------------------------------------------------
		// Set the Proper Color for Normal Poly's Reflections
		//----------------------------------------------------------

		// Set the CurRoom's changed poly's colors to WHITE
		SetRoomPolysColors(CurrRoom, SET_REFLECTIVE_POLYS_ONLY);
		// Set the CurRoom's Viewable Room's changed poly's
		// colors to WHITE
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
			SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
											SET_REFLECTIVE_POLYS_ONLY);

		//----------------------------------------------------------
		// Set some stages for rendering
		//----------------------------------------------------------

		// Set the SphereMap Texture
		g_lpDevice->SetTexture(0,g_lpSphereMapTexture);

		// Enable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
		{
			if(g_bDoTriLinearMipMapFiltering)
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
			else
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_POINT);
		}

		// Apply the appropriate states(or state block)
		g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,		3);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_ONE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_ONE);

		//----------------------------------------------------------
		// Render stuff
		//----------------------------------------------------------

		// Draw the Room's Solid Components Reflections
		DrawRoomSolidComponentsReflections(CurrRoom,g_lpDevice);
		// Draw the Viewable Room's Solid Components Reflections
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
		 DrawRoomSolidComponentsReflections(Rooms[CurrRoom->ViewableRooms[j]],g_lpDevice);

		//----------------------------------------------------------
		// Set back the stages after rendering
		//----------------------------------------------------------

		// Disable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_NONE);

		// Set back the appropriate states(or state block)
		g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,	0);
		g_lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
		g_lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);

		//----------------------------------------------------------

		

		//========================================================
////////// Transparent Polygons (With ShadowMaps)
////////// 
		//========================================================

		//----------------------------------------------------------
		// Set the Proper Color for Transparent Polys
		//----------------------------------------------------------

		// Set the CurRoom's changed poly's colors to WHITE
		SetRoomPolysColors(CurrRoom, SET_CHANGED_POLYS_ONLY);
		// Set the CurRoom's Viewable Room's changed poly's
		// colors to WHITE
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
			SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
											SET_CHANGED_POLYS_ONLY);

		
		//----------------------------------------------------------
		// Set some stages for rendering
		//----------------------------------------------------------
		
		// Enable texture stage 1
		g_lpDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE);

		// Enable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
		{
			if(g_bDoTriLinearMipMapFiltering)
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
			else
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_POINT);
		}

		// Apply the appropriate states(or state block)
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_SRCALPHA);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_INVSRCALPHA);

		//----------------------------------------------------------
		// Render stuff
		//----------------------------------------------------------

		// Draw the Viewable Room's Transparent Components
		for(j=(CurrRoom->NumViewableRooms)-1 ; j>=0 ; j--)
		 DrawRoomTranspComponents(Rooms[CurrRoom->ViewableRooms[j]],g_lpDevice);
		// Draw the Room's Transparent Components
		DrawRoomTranspComponents(CurrRoom,g_lpDevice);
		
		//----------------------------------------------------------
		// Set back the stages after rendering
		//----------------------------------------------------------
		
		// Disable texture stage 1
		g_lpDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
		// Set the texture on stage 1 to NULL to prevent a memory leak
		g_lpDevice->SetTexture(1,NULL);
		
		// Disable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_NONE);
		
		// Set back the appropriate states(or state block)
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);

		//----------------------------------------------------------




/*		
		// Set the Proper Color for Transparent Poly's Reflections
		//----------------------
		// Set the CurRoom's changed poly's colors to WHITE
		SetRoomPolysColors(CurrRoom, SET_REFLECTIVE_POLYS_ONLY);
		// Set the CurRoom's Viewable Room's changed poly's
		// colors to WHITE
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
			SetRoomPolysColors(Rooms[CurrRoom->ViewableRooms[j]],
											SET_REFLECTIVE_POLYS_ONLY);


		// Reflections for the Transparent Polys
		//---------------------------------------

		// Set the SphereMap Texture
		g_lpDevice->SetTexture(0,g_lpSphereMapTexture);

		// Enable texture stage 1
		g_lpDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE);
		
		// Apply the appropriate states(or state block)
		g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,	3);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_ONE );
		g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_ONE);

		// Draw the Room's Transparent Components Reflections
		DrawRoomTranspComponentsReflections(CurrRoom,g_lpDevice);
		// Draw the Viewable Room's Transparent Components Reflections
		for(j=0;j<CurrRoom->NumViewableRooms;j++)
		 DrawRoomTranspComponentsReflections(Rooms[CurrRoom->ViewableRooms[j]],g_lpDevice);

		// Disable texture stage 1
		g_lpDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
		// Set the texture on stage 1 to NULL to prevent a memory leak
		g_lpDevice->SetTexture(1,NULL);

		// Set back the appropriate states(or state block)
		g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,	0);
		g_lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
		g_lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);
*/
		


/*
		//////////////////////////////////////
		//		Draw the Dynamic Lights		//
		//////////////////////////////////////


		if(g_bDrawDynamicLights)
		{
			// Set the LightMap Texture
			g_lpDevice->SetTexture(0,g_lpLightMapTexture);

			// Enable Trilinear Mip Map filtering
			if(g_bSupportsMipmaps)
			{
				if(g_bDoTriLinearMipMapFiltering)
					g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
				else
					g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_POINT);
			}
			
			// Apply the appropriate states(or state block)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,			D3DTADDRESS_CLAMP );
			g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,		2);
			g_lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
			g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
			g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_ONE);
			g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_INVSRCCOLOR);

			// Draw the current Room's Global Lights
			DrawAlphaComponentsGlobalLights(CurrRoom,&g_Face,g_lpDevice);
			// Draw the Viewable Room's Global Lights
			for(j=0;j<CurrRoom->NumViewableRooms;j++)
			 DrawAlphaComponentsGlobalLights(Rooms[CurrRoom->ViewableRooms[j]],&g_Face,g_lpDevice);

			// Disable Trilinear Mip Map filtering
			if(g_bSupportsMipmaps)
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_NONE);
			
			// Set back the appropriate states(or state block)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,			D3DTADDRESS_WRAP );
			g_lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,	0);
			g_lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
			g_lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);

		}

		//////////////////////////////////////
*/




/* 
======================================================================
  This section has a bug and is temporarily disabled
======================================================================

		/////////////////////////////////////
		//		Draw the Light Coronas
		/////////////////////////////////////

		// Set the Corona Texture
		g_lpDevice->SetTexture(0,g_lpCoronaTexture);

		// Enable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
		{
			if(g_bDoTriLinearMipMapFiltering)
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
			else
				g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_POINT);
		}

		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZENABLE,				FALSE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_SRCCOLOR);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_ONE);

		// Draw the room's light coronas
		DrawRoomNonAmbLightCoronas(CurrRoom);

		// Disable Trilinear Mip Map filtering
		if(g_bSupportsMipmaps)
			g_lpDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER, D3DTFP_NONE);

		g_lpDevice->SetRenderState( D3DRENDERSTATE_ZENABLE,		TRUE);
		g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);

		// Set back the World Matrix
		// This is because the world matrix is changed
		// by the 'DrawRoomNonAmbLightCoronas' function
		g_lpDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, &g_WorldMatrix);

		//////////////////////////////////////
*/


////////////////////////////////////////////////////////////////////
//					(end of drawing static stuff)				  //
////////////////////////////////////////////////////////////////////


		
		
		
		// Draw the movable objects here





/////////////////////////////////////////////////////////////////////

		if(g_bStatusEnabled)
		{
			// Draw the Cross Hair 
			// Set the render states
			g_lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,   TRUE );
			g_lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,  D3DBLEND_SRCALPHA );
			g_lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND, D3DBLEND_INVSRCALPHA );
		
			g_lpDevice->SetTexture(0,g_lpCrossHairTexture);
			g_lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_TLVERTEX,g_CrossHairVerts,4,0);

			g_lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,FALSE);
		}

/////////////////////////////////////////////////////////////////////

		// end the scene
		g_lpDevice->EndScene();
	}


	if(g_bStatusEnabled)
	{
		char mess[100];
	
		sprintf(mess,"Status :");
		OutputText(10,g_ScreenCenterY-90,mess);

		sprintf(mess,"Position : (%.2f, %.2f, %.2f)",g_Face.x,g_Face.y,g_Face.z);
		OutputText(20,g_ScreenCenterY-75,mess);

		sprintf(mess,"Direction Angle : (%.2f)",g_rotAngle * 180.0f/3.14159f);
		OutputText(20,g_ScreenCenterY-60,mess);

		if(g_bGravityEnabled)
			sprintf(mess,"Gravity : ON");
		else
			sprintf(mess,"Gravity : OFF");
		OutputText(20,g_ScreenCenterY-45,mess);
	
		if(g_bHitChecking)
			sprintf(mess,"HitChecking : ON");
		else
			sprintf(mess,"HitChecking : OFF");
		OutputText(20,g_ScreenCenterY-30,mess);

		if(g_bDrawDynamicLights)
			sprintf(mess,"Dynamic Lights : ON");
		else
			sprintf(mess,"Dynamic Lights : OFF");
		OutputText(20,g_ScreenCenterY-15,mess);

		if(g_bDrawUserSpotLight)
			sprintf(mess,"User Spot Light : ON");
		else
			sprintf(mess,"User Spot Light : OFF");
		OutputText(20,g_ScreenCenterY,mess);

		if(g_bDrawUserPointLight)
			sprintf(mess,"User Point Light : ON");
		else
			sprintf(mess,"User Point Light : OFF");
		OutputText(20,g_ScreenCenterY + 15,mess);
	

		Time_To_Update_FrameRate += g_Elapsed;
		if(Time_To_Update_FrameRate > 0.5f)
		{	Time_To_Update_FrameRate -= 0.5f;
			FrameRate = 1.0f/g_Elapsed;
		}
		sprintf(mess,"Frame Rate : %.2f",FrameRate);
		OutputText(10,10,mess);

		
		sprintf(mess,"Dummy Output Var1 : %.2f",fDummyOutputVar1);
		OutputText(g_ScreenCenterX-80,10,mess);
		sprintf(mess,"Dummy Output Var2 : %.2f",fDummyOutputVar2);
		OutputText(g_ScreenCenterX-80,22,mess);
		sprintf(mess,"Dummy Output Var3 : %.2f",fDummyOutputVar3);
		OutputText(g_ScreenCenterX-80,34,mess);

		
		sprintf(mess,"Help :");
		OutputText(10,g_ScreenCenterY+40,mess);
		sprintf(mess,"G toggles gravity");
		OutputText(20,g_ScreenCenterY+55,mess);
		sprintf(mess,"H toggles hit-testing");
		OutputText(20,g_ScreenCenterY+70,mess);
		sprintf(mess,"1 toggles dynamic lighting");
		OutputText(20,g_ScreenCenterY+85,mess);
		sprintf(mess,"2 toggles the user spot light");
		OutputText(20,g_ScreenCenterY+100,mess);
		sprintf(mess,"3 toggles the user point light");
		OutputText(20,g_ScreenCenterY+115,mess);
	}
	
	
	// flip to the primary surface

	g_lpDDSPrimary->Flip(0,DDFLIP_WAIT);
}





//------ Entry Point of the Engine ------//

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE ,
                     LPSTR     lpCmdLine,
                     int       )
{

/////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////
	//			Create the App's Window
	///////////////////////////////////////////////////////////
	    
	WNDCLASS                    wc;

    // Set up and register window class
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = (WNDPROC) WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = sizeof(DWORD);
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL,MAKEINTRESOURCE(RM_ICORES));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH) GetStockObject(BLACK_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = "CTF-Engine";//szClass;
    
	// Register the window Class
	if (!RegisterClass(&wc))
	{
		g_ErrStr="Error Registering Window Class";
		MessageBox(NULL, g_ErrStr, "CTF-Engine", MB_OK);
        return FALSE;
	}

    // Get dimensions of display
    int ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
    int ScreenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Create a window and display it
    g_ApphWnd = CreateWindow(	"CTF-Engine",			// class
								"CTF-Engine",			// caption
								WS_VISIBLE|WS_POPUP,	// style 
								0,						// left
								0,						// top
								ScreenWidth,			// width
								ScreenHeight,			// height
								NULL,					// parent window
								NULL,					// menu 
								hInstance,				// instance
								NULL);					// parms
    if (!g_ApphWnd) {
		g_ErrStr="Error Creating Window";
		MessageBox(NULL, g_ErrStr, "CTF-Engine", MB_OK);
        return FALSE;
	}

	// Show, Update the window
    ShowWindow(g_ApphWnd, SW_SHOWNORMAL);
    UpdateWindow(g_ApphWnd);

	// Set the cursor position to the end of the screen
	SetCursorPos(ScreenWidth,ScreenHeight);

/////////////////////////////////////////////////////////////////////


	///////////////////////////////////////////////////////////
	//			Read Initialization File
	///////////////////////////////////////////////////////////

	if(!ReadInitFile("RV.ini"))
	{
		Cleanup();
        return FALSE;
	}


	///////////////////////////////////////////////////////////
	//			Initialize DirectX
	///////////////////////////////////////////////////////////

	// Enumerate DirectX Drivers/Devices
	if(!EnumerateDXDevices())
	{
		Cleanup();
        return FALSE;
	}

	// Initialize DirectDraw/Direct3D
	if(!Init_Direct3D())
	{
		Cleanup();
        return FALSE;
	}

	// Initialize Direct Input
	if(!Init_DirectInput(hInstance))
	{
		Cleanup();
        return FALSE;
	}

	
	///////////////////////////////////////////////////////////
	//	Initialize the Time Handler
	///////////////////////////////////////////////////////////
	
	InitTimeHandler();
	
	
	///////////////////////////////////////////////////////////
	//	Initialize the Engine, exit on failure
	///////////////////////////////////////////////////////////

	if (!InitEngine())
	{
		if(!g_ErrStr)
			g_ErrStr="Error Initializing Engine";

		Cleanup();
        return FALSE;
	}

	///////////////////////////////////////////////////////////
	//	Initialize the Application, exit on failure
	///////////////////////////////////////////////////////////

    if (!InitApp())
	{
		if(!g_ErrStr)
			g_ErrStr="Error Initializing Application";

		Cleanup();
        return FALSE;
	}


	///////////////////////////////////////////////////////////
	// Set the Global flag for the application to run
	///////////////////////////////////////////////////////////
	g_AppRunning = TRUE;


/////////////////////////////////////////////////////////////////////


	// Now we're ready to recieve and process Windows messages.

    BOOL bGotMsg;
    MSG  Msg;
    PeekMessage( &Msg, NULL, 0U, 0U, PM_NOREMOVE );
	
    while( WM_QUIT != Msg.message  )
    {
        bGotMsg = PeekMessage( &Msg, NULL, 0U, 0U, PM_REMOVE );

        if( bGotMsg )
        {
			TranslateMessage( &Msg );
            DispatchMessage( &Msg );
        } 
		else 
		{
			// Handle the Time Stuff
			HandleTime();

			// Handle the Input
			HandleInput();

			// Run the App
			if(g_AppRunning)
			{
				RenderFrame();
			}
		}
	}

	// return final message
    return Msg.wParam;
}
