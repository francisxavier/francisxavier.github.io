

/////////////////////////////////////////////////////////////////////
//
//
//			This File Handles Direct X (Initialization & Cleanup)
//
//
/////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
//
//				Global Direct X Variables
//
/////////////////////////////////////////////////////////////////////


// The vars for DX Graphics Initialization
DWORD	g_DriverInd=0;
DWORD	g_DeviceInd=0;
DWORD	g_DeviceModeInd=0;


// Vars for Gamma Correction
LPDIRECTDRAWGAMMACONTROL	g_lpDDGammaControl = NULL;	// The Gamma control
DDGAMMARAMP					g_DDGammaRamp;	// The structure for holding the Gamma vals
DWORD						g_GammaCorrectionVal=256;	// The GammaCorrection Value (range : 0 - 256)



//	Some Device Capabilities
BOOLEAN			g_bIsHardware = FALSE;

BOOLEAN			g_bSupportsMipmaps = FALSE;
BOOLEAN			g_bDoTriLinearMipMapFiltering=FALSE;



//------ Global Direct Draw/3D Interface Pointers ------//
LPDIRECTDRAW7			g_lpDD			=NULL;
LPDIRECTDRAWSURFACE7	g_lpDDSPrimary	=NULL;
LPDIRECTDRAWSURFACE7	g_lpDDSBack		=NULL;
LPDIRECTDRAWSURFACE7	g_lpDDSZBuf		=NULL;
LPDIRECT3D7				g_lpD3D			=NULL;
LPDIRECT3DDEVICE7		g_lpDevice		=NULL;


//----- Global Direct Input Interface Pointers --------//
LPDIRECTINPUT			g_lpDI			=NULL;

// The Mouse Interface
LPDIRECTINPUTDEVICE		g_lpMouse		=NULL;
// The structure for holding the mouse data
DIMOUSESTATE			g_DIms;

// The Keyboard Interface
LPDIRECTINPUTDEVICE		g_lpKeyboard	=NULL;
// The array for holding the keyboard data(and mouse data).
// Note that even though the array size need only be 256 bytes
// we declared it to be extra large; this is so that we can
// also include the mouse input data here for ease of programming
// when the responding to user defined keys part comes.
// The mouse input data is added to the end of the keyboard
// input data.
BYTE					g_InputDataBuffer[260];





////////////////////////////////////////////////////////////////////
//
//					Function Definitions
//
////////////////////////////////////////////////////////////////////



//-----------------------------------------------------------------------------
// Name: EnumZBufferCallback()
// Desc: Enumeration function to report valid pixel formats for z-buffers.
//-----------------------------------------------------------------------------
static HRESULT WINAPI EnumZBufferCallback( DDPIXELFORMAT* pddpf,
                                           VOID* pddpfDesired )
{
	// For this tutorial, we are only interested in z-buffers, so ignore any
	// other formats (e.g. DDPF_STENCILBUFFER) that get enumerated. An app
	// could also check the depth of the z-buffer (16-bit, etc,) and make a
	// choice based on that, as well. For this tutorial, we'll take the first
	// one we get.
    if( pddpf->dwFlags == DDPF_ZBUFFER )
    {
        memcpy( pddpfDesired, pddpf, sizeof(DDPIXELFORMAT) );

        // Return with D3DENUMRET_CANCEL to end the search.
		return D3DENUMRET_CANCEL;
    }

    // Return with D3DENUMRET_OK to continue the search.
    return D3DENUMRET_OK;
}


//-----------------------------------------------------------------------------
// Name: Initialize Direct3D
// Desc: This function initializes all the DirectDraw/Direct3D objects used for
//       3D-rendering.
//-----------------------------------------------------------------------------
BOOLEAN Init_Direct3D()
{
	HRESULT hr;

	// Get info about the currently selected driver and device. This info is
	// from driver/device/mode enumeration.
	GUID*           pDriverGUID;
	GUID*           pDeviceGUID;
	DDSURFACEDESC2* pMode;


	pDriverGUID = &(g_Drivers[g_DriverInd].DriverGUID);
	pDeviceGUID = &(g_Drivers[g_DriverInd].Devices[g_DeviceInd].DeviceGUID);
	pMode		= &(g_Drivers[g_DriverInd].ddsdModes[g_Drivers[g_DriverInd].Devices[g_DeviceInd].devModes[g_DeviceModeInd]]);


	// Save the mode's screen height & width
	g_ScreenWidth	= pMode->dwWidth;
	g_ScreenHeight	= pMode->dwHeight;
	g_ScreenCenterX = (DWORD)(g_ScreenWidth/2.0f);
	g_ScreenCenterY = (DWORD)(g_ScreenHeight/2.0f);


	// Create the IDirectDraw interface. The first parameter is the GUID,
	// which is allowed to be NULL. If there are more than one DirectDraw
	// drivers on the system, a NULL guid requests the primary driver. For 
	// non-GDI hardware cards like the 3DFX and PowerVR, the guid would need
	// to be explicity specified
	hr = DirectDrawCreateEx( pDriverGUID, (VOID**)&g_lpDD, IID_IDirectDraw7, 
		                     NULL );
	if( FAILED( hr ) )
		return FALSE;

    // Query DirectDraw for access to Direct3D
    g_lpDD->QueryInterface( IID_IDirect3D7, (VOID**)&g_lpD3D );
    if( FAILED( hr) )
		return FALSE;

    // Set the Windows cooperative level
	hr = g_lpDD->SetCooperativeLevel( g_ApphWnd, DDSCL_FULLSCREEN|DDSCL_EXCLUSIVE );
	if( FAILED( hr ) )
		return FALSE;

	hr = g_lpDD->SetDisplayMode(	pMode->dwWidth, pMode->dwHeight,
				                    pMode->ddpfPixelFormat.dwRGBBitCount,
								    pMode->dwRefreshRate, 0L );
	if( FAILED( hr ) )
		return FALSE;

	// Initialize a surface description structure for the primary surface. The
	// primary surface represents the entire display, with dimensions and a
	// pixel format of the display. Therefore, none of that information needs
	// to be specified in order to create the primary surface.
	DDSURFACEDESC2 ddsd;
	ZeroMemory( &ddsd, sizeof(DDSURFACEDESC2) );
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
	ddsd.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | 
		                     DDSCAPS_COMPLEX | DDSCAPS_3DDEVICE;
	ddsd.dwBackBufferCount = 1;

	// Create the primary surface.
	hr = g_lpDD->CreateSurface( &ddsd, &g_lpDDSPrimary, NULL );
	if( FAILED( hr ) )
		return FALSE;

	// Get a ptr to the back buffer, which will be our render target
	DDSCAPS2 ddscaps = { DDSCAPS_BACKBUFFER, 0, 0, 0 };
	hr = g_lpDDSPrimary->GetAttachedSurface( &ddscaps, &g_lpDDSBack );
	if( FAILED( hr ) )
		return FALSE;


	// Enumerate possible formats for the z-buffer
	DDPIXELFORMAT ddpfZBuffer;
	g_lpD3D->EnumZBufferFormats( *pDeviceGUID, EnumZBufferCallback, 
	                           (VOID*)&ddpfZBuffer );

	// If we found a good zbuffer format, then the dwSize field will be
	// properly set during enumeration. Else, we have a problem and will exit.
    if( sizeof(DDPIXELFORMAT) != ddpfZBuffer.dwSize )
        return FALSE;

    // Get z-buffer dimensions from the render target
    // Setup the surface desc for the z-buffer.
    ddsd.dwFlags        = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT|DDSD_PIXELFORMAT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_ZBUFFER;
	ddsd.dwWidth        = pMode->dwWidth;
	ddsd.dwHeight       = pMode->dwHeight;
    memcpy( &ddsd.ddpfPixelFormat, &ddpfZBuffer, sizeof(DDPIXELFORMAT) );

	// For hardware devices, the z-buffer should be in video memory. For
	// software devices, create the z-buffer in system memory
	if(IsEqualIID( *pDeviceGUID, IID_IDirect3DHALDevice    ) ||
	   IsEqualIID( *pDeviceGUID, IID_IDirect3DTnLHalDevice ))
		ddsd.ddsCaps.dwCaps |= DDSCAPS_VIDEOMEMORY;
	else
		ddsd.ddsCaps.dwCaps |= DDSCAPS_SYSTEMMEMORY;

    // Create and attach a z-buffer. Real apps should be able to handle an
	// error here (DDERR_OUTOFVIDEOMEMORY may be encountered). For this 
	// tutorial, though, we are simply going to exit ungracefully.
    if( FAILED( hr = g_lpDD->CreateSurface( &ddsd, &g_lpDDSZBuf, NULL ) ) )
		return FALSE;

	// Attach the z-buffer to the back buffer.
    if( FAILED( hr = g_lpDDSBack->AddAttachedSurface( g_lpDDSZBuf ) ) )
		return FALSE;

	// Before creating the device, check that we are NOT in a palettized
	// display. That case will cause CreateDevice() to fail, since this simple 
	// tutorial does not bother with palettes.
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
	g_lpDD->GetDisplayMode( &ddsd );
	if( ddsd.ddpfPixelFormat.dwRGBBitCount <= 8 )
		return FALSE;

	// Create the device. The device is created off of our back buffer, which
	// becomes the render target for the newly created device. Note that the
	// z-buffer must be created BEFORE the device

    if( FAILED( hr = g_lpD3D->CreateDevice(  *pDeviceGUID,
											 g_lpDDSBack,
											 &g_lpDevice ) ) )
	{
		// This call could fail for many reasons. The most likely cause is
		// that we specifically requested a hardware device, without knowing
		// whether there is even a 3D card installed in the system. Another
		// possibility is the hardware is incompatible with the current display
		// mode (the correct implementation would use enumeration for this.)
		return FALSE;
	}

    // Create the viewport
	D3DVIEWPORT7 vp = { 0, 0, pMode->dwWidth, pMode->dwHeight, 0.0f, 1.0f };
    hr = g_lpDevice->SetViewport( &vp );
	if( FAILED( hr ) )
		return FALSE;



    // Enumerate the available texture formats into a static list
	//------------------------------------------------------------

    if( FAILED( g_lpDevice->EnumTextureFormats( EnumTextureFormats, NULL ) ) )
	{
		g_ErrStr = "Could not Enumerate Texture Formats";
		return FALSE;
	}

	
	// Query the Primary Surface for Gamma Correction Support
	// (even if no support is available we can still use it)
	//--------------------------------------------------------
	g_lpDDSPrimary->QueryInterface(IID_IDirectDrawGammaControl,(void **)&g_lpDDGammaControl);



	// Check the device's capabilities
	//---------------------------------

	// Check if the Device is Hardware or not
	if(g_Drivers[g_DriverInd].Devices[g_DeviceInd].bHardware)
		g_bIsHardware = TRUE;
	else
        g_bIsHardware = FALSE;


    // Check if device supports mipmapping
    DWORD dwFilterCaps = g_Drivers[g_DriverInd].Devices[g_DeviceInd].ddDeviceDesc.dpcTriCaps.dwTextureFilterCaps;
    if( dwFilterCaps & (D3DPTFILTERCAPS_MIPNEAREST|D3DPTFILTERCAPS_MIPLINEAR ) )
        g_bSupportsMipmaps = TRUE;



	// Return success to the caller
	return TRUE;
}



//-----------------------------------------------------------------------------
// Name: Initialize Direct Input
// Desc: This function initializes Direct Input (And the Mouse,Keyboard)
//-----------------------------------------------------------------------------
BOOLEAN	Init_DirectInput(HINSTANCE hInstance)
{

	// Create the DI object
	//----------------------

    if (DirectInputCreate(hInstance, DIRECTINPUT_VERSION, &g_lpDI, NULL) != DI_OK)
		return FALSE;


	// Create the Mouse
	//------------------
    
    // Obtain an interface to the system mouse device.
	if (g_lpDI->CreateDevice(GUID_SysMouse, &g_lpMouse, NULL) != DI_OK)
		return FALSE;

    // Set the data format
    if (g_lpMouse->SetDataFormat(&c_dfDIMouse) != DI_OK)
	{
        SafeRelease(g_lpMouse);
        return FALSE;
    }

	// Set the Cooperative Level
	if (g_lpMouse->SetCooperativeLevel(g_ApphWnd, DISCL_FOREGROUND |
									   DISCL_EXCLUSIVE) != DI_OK)
    {
		SafeRelease(g_lpMouse);
        return FALSE;
    }

    // Acquire the mouse device
    g_lpMouse->Acquire();



	// Create the Keyboard
	//----------------------

    // Obtain an interface to the system keyboard device.
    if (g_lpDI->CreateDevice(GUID_SysKeyboard, &g_lpKeyboard, NULL) != DI_OK)
		return FALSE;
	
	// Set the data format
	if (g_lpKeyboard->SetDataFormat(&c_dfDIKeyboard) != DI_OK)
    {
		SafeRelease(g_lpKeyboard);
        return FALSE;
    }

	// Set the Cooperative Level
    if (g_lpKeyboard->SetCooperativeLevel(g_ApphWnd, DISCL_FOREGROUND |
        DISCL_EXCLUSIVE) != DI_OK)
    {
		SafeRelease(g_lpKeyboard);
        return FALSE;
    }

    // Acquire the keyboard device
    g_lpKeyboard->Acquire();

	
	// We've managed to initialize all the necessary
	// input devices, so return TRUE
	return TRUE;
}




//-----------------------------------------------------------------------------
// Name: RestoreSurfacesIfLost
// Desc: This function checks if any surfaces are lost and
//		 restores them
//-----------------------------------------------------------------------------
inline void RestoreLostSurfaces()
{
	// See if the primary surface is lost
	if (g_lpDDSPrimary->IsLost()==DDERR_SURFACELOST)
		g_lpDDSPrimary->Restore();

	// See if the back buffer is lost
	if (g_lpDDSBack->IsLost()==DDERR_SURFACELOST)
		g_lpDDSBack->Restore();

	// See if the Z buffer is lost
	if (g_lpDDSZBuf->IsLost()==DDERR_SURFACELOST)
		g_lpDDSZBuf->Restore();
}



//-----------------------------------------------------------------------------
// Name: SetGammaCorrection
// Desc: This function sets the Gamma Value (range : 0 - 256)
//-----------------------------------------------------------------------------
void SetGammaCorrection(WORD GammaCorrectionValue)
{
	WORD *redptr	= g_DDGammaRamp.red;
	WORD *greenptr	= g_DDGammaRamp.green;
	WORD *blueptr	= g_DDGammaRamp.blue;
	WORD *redptrEnd	= redptr + 256;
	WORD GVal		= 0;

	// Set the values of the GammaRamp structure properly
	while(redptr < redptrEnd)
	{
		*redptr = *greenptr = *blueptr = GVal;
		redptr++; greenptr++; blueptr++;
		GVal += GammaCorrectionValue;
	}

	// Set the Gamma Correction to the Primary Surface
	if(g_lpDDGammaControl)
		g_lpDDGammaControl->SetGammaRamp(0, &g_DDGammaRamp);
}



//-----------------------------------------------------------------------------
// Name: CleanupDX
// Desc: This function cleans up Direct Draw/3D/Input
//-----------------------------------------------------------------------------
void CleanupDX()
{

	///////////////////////////////////
	//	Cleanup Direct Input
	///////////////////////////////////
	
	// Unacquire the Mouse
    if( g_lpMouse ) 
	    g_lpMouse->Unacquire();
    // Release the Mouse
    SafeRelease( g_lpMouse );

	// Unacquire the Keyboard
	if( g_lpKeyboard ) 
	    g_lpKeyboard->Unacquire();
    // Release the Keyboard
    SafeRelease( g_lpKeyboard );

	// Release the DI Interface
    SafeRelease( g_lpDI );
	

	///////////////////////////////////
	//	Cleanup Direct 3D
	///////////////////////////////////
	
	// Release the 3D Device
	SafeRelease(g_lpDevice);

	// Release the D3D Interface
	SafeRelease(g_lpD3D);


	///////////////////////////////////
	//	Cleanup Direct Draw
	///////////////////////////////////
	
	// Release the Gamma Control
	SafeRelease(g_lpDDGammaControl);

	// Release the Primary Surface
	SafeRelease(g_lpDDSPrimary);

	// Set the Cooperative level of DDraw to Normal
	if(g_ApphWnd && g_lpDD)
		g_lpDD->SetCooperativeLevel(g_ApphWnd, DDSCL_NORMAL );

	// Release the DDraw Interface
	SafeRelease(g_lpDD);
}


