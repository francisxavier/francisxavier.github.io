

//////////////////////////////////////////////////////////////////////
//
//
//					Direct X Enumerate
//
//
//	This header file contains the code necessary to
//	enumerate DirectDraw/Direct3D drivers, devices, and modes.
//
//////////////////////////////////////////////////////////////////////


// Some Defines
#define MAX_DRIVERS		5
#define MAX_DEVICES		5
#define MAX_MODES		100


struct DEVICEINFO
{
	// Device Description
    CHAR			DeviceDesc[100];

    // D3D Device info
	GUID			DeviceGUID;
    D3DDEVICEDESC7	ddDeviceDesc;
    BOOL			bHardware;

	// Supported Modes
	DWORD			dwNumModes;
	DWORD			devModes[MAX_MODES];
};

struct DRIVERINFO
{
	// Driver Description
	CHAR			DriverDesc[100];

    // DDraw Driver info
    GUID			DriverGUID;
    DDCAPS			ddDriverCaps;
    DDCAPS			ddHELCaps;

    DWORD			dwNumModes;
    DDSURFACEDESC2	ddsdModes[MAX_MODES];

	// Devices
	DWORD			NumDevices;
	DEVICEINFO		Devices[MAX_DEVICES];
};


//-----------------------------------------------------------------------------
// Global data for the enumerator functions
//-----------------------------------------------------------------------------

DWORD			g_NumDrivers = 0L;		// The Number of Drivers
DRIVERINFO		g_Drivers[MAX_DRIVERS];	// The Drivers

DWORD			g_TotNumDevices=0L;		// The Total number of devices
										// on the system. Just used to
										// check if any drivers were
										// found at all.


// The Global list of pixel formats
DWORD         m_dwNumPixelFormats;
DDPIXELFORMAT m_PixelFormats[100];




//-----------------------------------------------------------------------------
// Local callback functions used during enumeration
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Name: EnumTextureFormats()
// Desc: Stores enumerates texture formats in a global array.
//-----------------------------------------------------------------------------
HRESULT WINAPI EnumTextureFormats( DDPIXELFORMAT* pddpf,
                                   VOID* )
{
    m_PixelFormats[m_dwNumPixelFormats++] = (*pddpf);

    return DDENUMRET_OK;
}




//-----------------------------------------------------------------------------
// Name: ModeEnumCallback()
// Desc: Callback function for enumerating display modes.
//-----------------------------------------------------------------------------
static HRESULT WINAPI ModeEnumCallback( DDSURFACEDESC2* pddsd,
                                        VOID* pParentInfo )
{
    // Copy the mode into the driver's list of supported modes
    DRIVERINFO* pDriverInfo = (DRIVERINFO *)pParentInfo;
    pDriverInfo->ddsdModes[pDriverInfo->dwNumModes++] = (*pddsd);

    return DDENUMRET_OK;
}




//-----------------------------------------------------------------------------
// Name: DeviceEnumCallback()
// Desc: Callback function for enumerating devices
//-----------------------------------------------------------------------------
static HRESULT WINAPI DeviceEnumCallback(LPSTR strDesc,
                                  LPSTR strName, D3DDEVICEDESC7* pDesc,
                                  VOID* pParentInfo )
{
    // Set some pointers
	DRIVERINFO *pDriverInfo = (DRIVERINFO *)pParentInfo;
	DEVICEINFO *pDeviceInfo = &(pDriverInfo->Devices[pDriverInfo->NumDevices]);

	// Copy the Device's info
    memcpy( &(pDeviceInfo->ddDeviceDesc), pDesc, sizeof(D3DDEVICEDESC7) );
    pDeviceInfo->DeviceGUID		= pDesc->deviceGUID;
    pDeviceInfo->bHardware		= pDesc->dwDevCaps & D3DDEVCAPS_HWRASTERIZATION;
    pDeviceInfo->dwNumModes		= 0;

    // Copy the description for the device
	strncpy( pDeviceInfo->DeviceDesc, strDesc, 100 );
    

    // This is a good place to give the app a chance to accept or reject this
    // device via a callback function. This simple tutorial does not do this,
    // though.
	if(pDeviceInfo->DeviceGUID == IID_IDirect3DRefDevice)
		return D3DENUMRET_OK;


    // Build list of supported modes for the device
    for( DWORD i=0; i<pDriverInfo->dwNumModes; i++ )
    {
        DWORD dwModeDepth = pDriverInfo->ddsdModes[i].ddpfPixelFormat.dwRGBBitCount;
        DWORD dwBitDepth  = pDeviceInfo->ddDeviceDesc.dwDeviceRenderBitDepth;
        BOOL  bCompatible = FALSE;

        // Check mode for compatability with device. Skip 8-bit modes.
        if( (32==dwModeDepth) && (dwBitDepth&DDBD_32) ) bCompatible = TRUE;
        if( (24==dwModeDepth) && (dwBitDepth&DDBD_24) ) bCompatible = TRUE;
        if( (16==dwModeDepth) && (dwBitDepth&DDBD_16) ) bCompatible = TRUE;

        // Copy compatible modes to the list of device-supported modes
        if( bCompatible )
            pDeviceInfo->devModes[pDeviceInfo->dwNumModes++] = i;
    }

    // Make sure the device has supported modes
    if( 0 == pDeviceInfo->dwNumModes )
        return D3DENUMRET_OK;


    // Accept the device and return
	pDriverInfo->NumDevices++;
	g_TotNumDevices++;

	return D3DENUMRET_OK;
}




//-----------------------------------------------------------------------------
// Name: DriverEnumCallback()
// Desc: Callback function for enumerating drivers.
//-----------------------------------------------------------------------------
static BOOL WINAPI DriverEnumCallback( GUID* pGUID, LPSTR strDesc,
                                       LPSTR strName, VOID*, HMONITOR )
{
	DRIVERINFO	  *pDriverInfo;
    LPDIRECT3D7   pD3D;
    LPDIRECTDRAW7 pDD;
    HRESULT       hr;
    
    // Use the GUID to create the DirectDraw object
    hr = DirectDrawCreateEx( pGUID, (VOID**)&pDD, IID_IDirectDraw7, NULL );
    if( FAILED(hr) )
    {
        return D3DENUMRET_OK;
    }

    // Create a D3D object, to enumerate the d3d devices
    hr = pDD->QueryInterface( IID_IDirect3D7, (VOID**)&pD3D );
    if( FAILED(hr) )
    {
        pDD->Release();
        return D3DENUMRET_OK;
    }

	pDriverInfo = &g_Drivers[g_NumDrivers++];

	// Copy the Description of the Device
	strncpy( pDriverInfo->DriverDesc, strDesc, 100 );
	
	// Get the Driver's Caps
    pDriverInfo->ddDriverCaps.dwSize = sizeof(DDCAPS);
    pDriverInfo->ddHELCaps.dwSize    = sizeof(DDCAPS);
    pDD->GetCaps( &(pDriverInfo->ddDriverCaps),
				  &(pDriverInfo->ddHELCaps));

	// Get the GUID of the Driver
    if( pGUID )
		pDriverInfo->DriverGUID = (*pGUID);
    
    // Enumerate the fullscreen display modes.
    pDD->EnumDisplayModes( 0, NULL, pDriverInfo, ModeEnumCallback );

    // Now, enumerate all the 3D devices
    pD3D->EnumDevices( DeviceEnumCallback, pDriverInfo );

    // Clean up and return
    pD3D->Release();
    pDD->Release();

    return DDENUMRET_OK;
}



BOOLEAN EnumerateDXDevices()
{

	// Initialize the driver struct
	for(WORD i=0;i<MAX_DRIVERS;i++)
	{
		g_Drivers[i].dwNumModes = 0L;
		g_Drivers[i].NumDevices = 0L;
	}
	

    // Enumerate drivers, devices, and modes
    DirectDrawEnumerateEx( DriverEnumCallback, NULL,
                           DDENUM_ATTACHEDSECONDARYDEVICES |
                           DDENUM_DETACHEDSECONDARYDEVICES |
                           DDENUM_NONDISPLAYDEVICES );


    // Make sure drivers were actually enumerated
    if( 0 == g_TotNumDevices )
	{
		g_ErrStr = "No Drivers Found";
        return FALSE;
	}

	return TRUE;
}

