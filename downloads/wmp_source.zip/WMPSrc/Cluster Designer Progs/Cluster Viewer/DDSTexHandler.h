

/////////////////////////////////////////////////////////////////////
//
//					DDS	Texture Handler
//
//
//	This header file does all the Texture Management necessary
//
/////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////
//						Defines
/////////////////////////////////////////////////////////////////////

#define MAX_TEXTURES	500		// The maximum no. of Textures



/////////////////////////////////////////////////////////////////////
//
//		Some global vars
//
/////////////////////////////////////////////////////////////////////


// The Base Textures of the Cluster
WORD				 g_NumTextures=0;
LPDIRECTDRAWSURFACE7 g_Textures[MAX_TEXTURES];


// The Special Textures of the Cluster
LPDIRECTDRAWSURFACE7 g_lpLightMapTexture=NULL;	// Light Map Tex
LPDIRECTDRAWSURFACE7 g_lpCoronaTexture=NULL;	// Corona Tex
LPDIRECTDRAWSURFACE7 g_lpSphereMapTexture=NULL;	// Sphere Map Tex


// The Skybox textures
LPDIRECTDRAWSURFACE7 g_SkyBoxTopTexture=NULL;
LPDIRECTDRAWSURFACE7 g_SkyBoxBottomTexture=NULL;
LPDIRECTDRAWSURFACE7 g_SkyBoxLeftTexture=NULL;
LPDIRECTDRAWSURFACE7 g_SkyBoxRightTexture=NULL;
LPDIRECTDRAWSURFACE7 g_SkyBoxFrontTexture=NULL;
LPDIRECTDRAWSURFACE7 g_SkyBoxBackTexture=NULL;



//-----------------------------------------------------------------------------
// Name: GetNumberOfBits()
// Desc: Returns the number of bits set in a DWORD mask
//-----------------------------------------------------------------------------
WORD GetNumberOfBits( DWORD dwMask )
{
    for( WORD wBits = 0; dwMask; wBits++ )
        dwMask = dwMask & ( dwMask - 1 );  

    return wBits;
}


//-----------------------------------------------------------------------------
// Name: FindBestPixelFormatMatch()
// Desc: Finds the best pixel format match for the cuurent device.
//-----------------------------------------------------------------------------
HRESULT FindBestPixelFormatMatch( DDPIXELFORMAT ddpfDDSTexture, 
                                  DDPIXELFORMAT* pddpfBestMatch )
{
    int  nCompAlphaBits;
    int  nHighestFound = 0;
    BOOL bCompressedTexture;
    BOOL bPremultipliedAlpha;

    // Set how many alpha bits are in the compressed texture 
    switch( ddpfDDSTexture.dwFourCC )
    {
        case 0:
            // This dds texture isn't compressed so we need an exact pixel
            // format match to render this surface (or do a manual pixel
            // conversion)
            bCompressedTexture = FALSE;  
            break;

        case MAKEFOURCC('D','X','T','1'):
            nCompAlphaBits      = 1;
            bPremultipliedAlpha = FALSE;
            bCompressedTexture  = TRUE;
            break;

        case MAKEFOURCC('D','X','T','2'):
            nCompAlphaBits      = 4;
            bPremultipliedAlpha = TRUE;
            bCompressedTexture  = TRUE;
            break;

        case MAKEFOURCC('D','X','T','3'):
            nCompAlphaBits      = 4;
            bPremultipliedAlpha = FALSE;
            bCompressedTexture  = TRUE;
            break;

        case MAKEFOURCC('D','X','T','4'):
            nCompAlphaBits      = 8;
            bPremultipliedAlpha = TRUE;
            bCompressedTexture  = TRUE;
            break;

        case MAKEFOURCC('D','X','T','5'):
            nCompAlphaBits      = 8;
            bPremultipliedAlpha = FALSE;
            bCompressedTexture  = TRUE;
            break;
    }

    if( FALSE == bCompressedTexture )
    {
        // If the texture isn't compressed then look for an exact pixel format
        // match, otherwise fail since this sample doesn't implement any manual
        // pixel format conversion algorithms.
        int nTextureABits = GetNumberOfBits( ddpfDDSTexture.dwRGBAlphaBitMask );
        int nTextureRBits = GetNumberOfBits( ddpfDDSTexture.dwRBitMask );
        int nTextureGBits = GetNumberOfBits( ddpfDDSTexture.dwGBitMask );
        int nTextureBBits = GetNumberOfBits( ddpfDDSTexture.dwBBitMask );

        for( DWORD i=0; i<m_dwNumPixelFormats; i++ )
        {
            DDPIXELFORMAT* pddpf = &m_PixelFormats[i];

            int nFormatABits = GetNumberOfBits( pddpf->dwRGBAlphaBitMask );
            int nFormatRBits = GetNumberOfBits( pddpf->dwRBitMask );
            int nFormatGBits = GetNumberOfBits( pddpf->dwGBitMask );
            int nFormatBBits = GetNumberOfBits( pddpf->dwBBitMask );

            if( pddpf->dwFourCC == 0 &&
                nFormatABits == nTextureABits &&
                nFormatRBits == nTextureRBits &&
                nFormatGBits == nTextureGBits &&
                nFormatBBits == nTextureBBits ) 
            {
                // This is an exact pixel format match, so it works
                (*pddpfBestMatch) = (*pddpf);
                return S_OK;
            }
        }

        // pBestPixelFormat will be NULL if no exact match found, and since
        // this is an uncompressed DDS texture format  the blt can not convert
        // between pixel formats. A manual conversion of the pixels could be
        // done, but this is not implemeneted in this sample
    }
    else
    {
        // Search for an exact pixel format match  if renderer supports
        // compressed textures 
        for( DWORD i=0; i<m_dwNumPixelFormats; i++ )
        {
            DDPIXELFORMAT* pddpf = &m_PixelFormats[i];

            if( pddpf->dwFourCC == ddpfDDSTexture.dwFourCC )
            {
                // Look no further, since this is the best possible match
                (*pddpfBestMatch) = (*pddpf);
                return S_OK;
            }
        }

        // A good match was not found then keep looking. Search for exact or
        // highest alpha bit rate match and also make sure the texture isn't
        // blitted to/from premultipled alpha and non-premultipled alpha.
        nHighestFound = -1;

        for( i=0; i<m_dwNumPixelFormats; i++ )
        {
            DDPIXELFORMAT* pddpf = &m_PixelFormats[i];
            int  nFormatABits   = GetNumberOfBits( pddpf->dwRGBAlphaBitMask );
            int  nFormatRBits   = GetNumberOfBits( pddpf->dwRBitMask );
            int  nFormatGBits   = GetNumberOfBits( pddpf->dwGBitMask );
            int  nFormatBBits   = GetNumberOfBits( pddpf->dwBBitMask );
            BOOL bFormatPMAlpha = pddpf->dwFlags & DDPF_ALPHAPREMULT;
            
            if( ( bFormatPMAlpha == bPremultipliedAlpha ) &&
                ( nFormatABits == nCompAlphaBits ) && ( nFormatRBits >= 4 ) &&
                ( nFormatGBits >= 4 ) && ( nFormatBBits >= 4 ) ) 
            {
                // Look no further, this is the next best possible match
                (*pddpfBestMatch) = (*pddpf);
                return S_OK;
            }

            if( ( bFormatPMAlpha == bPremultipliedAlpha ) &&
                ( nFormatABits > nHighestFound ) && ( nFormatRBits >= 4 ) &&
                ( nFormatGBits >= 4 && nFormatBBits >= 4 ) ) 
            {
                // Record, but keep looking for a better match
                nHighestFound     = nFormatABits;
                (*pddpfBestMatch) = (*pddpf);
            }
        
            // If no match was found then either no texture pixel formats are
            // supported by the renderer or this in an uncompressed pixel
            // format and an exact pixel format match was not found
            if( i >= m_dwNumPixelFormats )
                return E_FAIL;
        }
    }

    return S_OK;
}


//-----------------------------------------------------------------------------
// Name: ReadDDSTexture()
// Desc: Reads a DDS texture format from disk given a filename.
//       ppCompTop contains the DDS surface, and 
//       pddsdComp contains the DDS surface description
//-----------------------------------------------------------------------------
HRESULT ReadDDSTexture( CHAR* strTextureName,
                        DDSURFACEDESC2* pddsdNew, 
                        LPDIRECTDRAWSURFACE7* ppddsNew )
{
    LPDIRECTDRAWSURFACE7 pdds = NULL;
    DDSURFACEDESC2       ddsd;
    DWORD   dwMagic;
    HRESULT hr;

    // Open the compressed texture file
    FILE* file = fopen( strTextureName, "rb" );
    if( file == NULL )
		return E_FAIL;

    // Read magic number
    fread( &dwMagic, sizeof(DWORD), 1, file );
    if( dwMagic != MAKEFOURCC('D','D','S',' ') )
    {
        fclose( file );
        return E_FAIL;
    }

    // Read the surface description
    fread( &ddsd, sizeof(DDSURFACEDESC2), 1, file );

    // Load DDS into system memory
    ddsd.ddsCaps.dwCaps  |= DDSCAPS_SYSTEMMEMORY;

    // Handle special case for hardware that doesn't support mipmapping
    if( !g_bSupportsMipmaps )
    {
        ddsd.dwMipMapCount   = 0;
        ddsd.dwFlags        &= ~DDSD_MIPMAPCOUNT;
        ddsd.ddsCaps.dwCaps &= ~( DDSCAPS_MIPMAP | DDSCAPS_COMPLEX );
    }

    // Clear unwanted flags
    ddsd.dwFlags &= (~DDSD_PITCH);
    ddsd.dwFlags &= (~DDSD_LINEARSIZE);

    // Store the return copy of this surfacedesc
    (*pddsdNew) = ddsd;

    // Create a new surface based on the surface description
    if( FAILED( hr = g_lpDD->CreateSurface( &ddsd, &pdds, NULL ) ) )
    {
        fclose( file );
        return hr;
    }

    // Store the return copy of the compressed surface
    (*ppddsNew) = pdds;
    (*ppddsNew)->AddRef();

    while( TRUE )
    {
        if( FAILED( hr = pdds->Lock( NULL, &ddsd, DDLOCK_WAIT, NULL )))
        {
            fclose( file );
            return hr;
        }

        if( ddsd.dwFlags & DDSD_LINEARSIZE )
        {
            fread( ddsd.lpSurface, ddsd.dwLinearSize, 1, file );
        }
        else
        {
            BYTE* pDest = (BYTE*)ddsd.lpSurface;
            DWORD dwBytesPerRow = ddsd.dwWidth * ddsd.ddpfPixelFormat.dwRGBBitCount / 8;
            
            for( DWORD yp = 0; yp < ddsd.dwHeight; yp++ )
            {
                fread( pDest, dwBytesPerRow, 1, file );
                pDest += ddsd.lPitch;
            }
        }

        pdds->Unlock( NULL );

        if( !g_bSupportsMipmaps )
        {
            // For mipless hardware, don't copy mipmaps
            pdds->Release();
            fclose( file );
            return S_OK;
        }

        // Get the next surface.
        LPDIRECTDRAWSURFACE7 pddsNext;
        DDSCAPS2 ddsCaps = { DDSCAPS_TEXTURE|DDSCAPS_MIPMAP|DDSCAPS_COMPLEX, 0, 0, 0 };
        
        if( FAILED( hr = pdds->GetAttachedSurface( &ddsCaps, &pddsNext ) ) )
        {
            // Failure means were done with the mipmaps
            pdds->Release();
            fclose( file );
            return S_OK;
        }

        pdds->Release();
        pdds = pddsNext;
    }
}



//-----------------------------------------------------------------------------
// Name: BltToTextureSurface()
// Desc: Creates an surface in a format that the renderer supports, and copies
//       from the loaded DDS to the texture surface.
//-----------------------------------------------------------------------------
HRESULT BltToTextureSurface( DDSURFACEDESC2 ddsd, 
                             DDPIXELFORMAT ddpf, LPDIRECTDRAWSURFACE7 pddsDXT, 
                             LPDIRECTDRAWSURFACE7* ppddsNewSurface )
{
    LPDIRECTDRAWSURFACE7 pddsNew;
    HRESULT hr;

    // Set surface caps for the new surface
    ddsd.ddpfPixelFormat = ddpf;

    // If this is a hardware device, clear the DDSCAPS_SYSTEMMEMORY
    // flag and turn on automatic texture management
    if(g_bIsHardware )
    {
        ddsd.ddsCaps.dwCaps2 |= DDSCAPS2_TEXTUREMANAGE;
        ddsd.ddsCaps.dwCaps &= ~DDSCAPS_SYSTEMMEMORY;
    }

    // Create a surface based on the enumerated texture formats
    if( FAILED( hr = g_lpDD->CreateSurface( &ddsd, &pddsNew, NULL ) ) )
        return hr;
    *ppddsNewSurface = pddsNew;

    // Transfer image to texture surface, including mips (if any)
    while( TRUE )
    {
        if( FAILED( hr = pddsNew->Blt( NULL, pddsDXT, NULL, DDBLT_WAIT, NULL ) ) )
            return hr;

        // Get next surface in DXT's mipmap chain
        LPDIRECTDRAWSURFACE7 pddsNext;
        DDSCAPS2 ddsCaps = { DDSCAPS_TEXTURE|DDSCAPS_MIPMAP|DDSCAPS_COMPLEX, 0, 0, 0 };

        if( FAILED( pddsDXT->GetAttachedSurface( &ddsCaps, &pddsNext ) ) )
        {
            // Failure here means were done with the mipmap chain
            return S_OK;
        }
        pddsDXT = pddsNext;  

        // Get next surface in the new surface's mipmap chain
        if( FAILED( hr = pddsNew->GetAttachedSurface( &ddsCaps, &pddsNext ) ) )
            return hr;
        pddsNew = pddsNext;
    }
}



//-----------------------------------------------------------------------------
// Name: LoadDDSTexture()
// Desc: Creates the device-dependant surface and loads a DDS texture 
//-----------------------------------------------------------------------------
HRESULT LoadDDSTexture( CHAR* strTextureName,
					 LPDIRECTDRAWSURFACE7* ppddsTexture )
{
    HRESULT              hr;
    LPDIRECTDRAWSURFACE7 pDDSLoad = NULL;
    DDSURFACEDESC2       ddsd;
    DDPIXELFORMAT        ddpfBestMatch;

    // Create a surface based on the DDS file
    // this surface may or may not be compressed
    if( FAILED( hr = ReadDDSTexture( strTextureName,  &ddsd, &pDDSLoad ) ) )
    {
        SAFE_RELEASE( pDDSLoad );
        return hr;
    }

    // Enumerate all pixel formats, then choose the best match
    // based on the read-in DDS pixel format
    if( FAILED( hr = FindBestPixelFormatMatch( ddsd.ddpfPixelFormat, 
                                               &ddpfBestMatch ) ) )
    {
        SAFE_RELEASE( pDDSLoad );
        return hr;
    }


	LPDIRECTDRAWSURFACE7 pDDSNew = NULL;

    // Blt the loaded surface to an texture surface using the best
    // pixel format match
    if( FAILED( hr = BltToTextureSurface( ddsd, ddpfBestMatch,
                                          pDDSLoad, &pDDSNew ) ) )
    {
        SAFE_RELEASE( pDDSNew );
        SAFE_RELEASE( pDDSLoad );
        return hr;
    }

    // Get the texture interface from the new texture surface
    (*ppddsTexture) = pDDSNew;

    // Done with loaded surface, so release it
    SAFE_RELEASE( pDDSLoad );

    return S_OK;
}
