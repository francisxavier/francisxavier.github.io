

/////////////////////////////////////////////////////////////////////
//			Read Initialization File
/////////////////////////////////////////////////////////////////////

BOOLEAN ReadInitFile(char *fileName)
{
	FILE *fName;
	char strIL[100];	// A line of input
	char strKW[20];		// A string keyword


	// Open the initialization file
	if((fName = fopen(fileName,"r")) == (FILE *)NULL)
	{
		g_ErrStr = "Cannot open Initialization File";
		return FALSE;
	}

	
	for(;;)
	{
		// Get a whole line of input
		if(!fgets(strIL,100,fName))
			break;

		// Check if the line is a comment(ie., if it starts with '/')
		// If yes, then skip this line
		if(strIL[0] == '/')
			continue;

		// Extract the first word of the line
		if(sscanf(strIL,"%s = ",strKW) != 1)
			continue;

		// See if it is any of the keywords
		// If yes, then also read its accociated value.
		if(stricmp(strKW,"DRIVER") == 0)
		{
			// Read the index of the Driver to use
			sscanf(strIL,"%s = %u",strKW,&g_DriverInd);
		}
		else if(stricmp(strKW,"DEVICE") == 0)
		{
			// Read the index of the Device to use
			sscanf(strIL,"%s = %u",strKW,&g_DeviceInd);
		}
		else if(stricmp(strKW,"MODE") == 0)
		{
			// Read the index of the Mode to use
			sscanf(strIL,"%s = %u",strKW,&g_DeviceModeInd);
		}
		else if(stricmp(strKW,"GAMMA") == 0)
		{
			// Read the Gamma Correction Value (Range : 0 - 256)
			sscanf(strIL,"%s = %u",strKW,&g_GammaCorrectionVal);
		}

	}

	// Close the Initialization file
	fclose(fName);

	// return success
	return TRUE;
}


BOOLEAN Create_Objects()
{

	//////////////////////////////////////////////////////
	//			Initialize the Floor Structure			//
	//////////////////////////////////////////////////////

	
	// Load the special Textures
	LoadDDSTexture("Crosshair.dds",&g_lpCrossHairTexture);
	LoadDDSTexture("Lightmap.dds", &g_lpLightMapTexture);
	LoadDDSTexture("Corona.dds",   &g_lpCoronaTexture);
	LoadDDSTexture("SphereMap.dds",&g_lpSphereMapTexture);

	// Load the Skybox textures
	LoadDDSTexture("DaySkyUp.dds",		&g_SkyBoxTopTexture);
	LoadDDSTexture("DaySkyDown.dds",	&g_SkyBoxBottomTexture);
	LoadDDSTexture("DaySkyLeft.dds",	&g_SkyBoxLeftTexture);
	LoadDDSTexture("DaySkyRight.dds",	&g_SkyBoxRightTexture);
	LoadDDSTexture("DaySkyFront.dds",	&g_SkyBoxFrontTexture);
	LoadDDSTexture("DaySkyBack.dds",	&g_SkyBoxBackTexture);


	// initialize the Cross Hair vertices
	g_CrossHairVerts[0] = D3DTLVERTEX( D3DVECTOR( (float)g_ScreenCenterX-g_CrossHairRadiusX, (float)g_ScreenCenterY+g_CrossHairRadiusY, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 0.0f, 1.0f );
    g_CrossHairVerts[1] = D3DTLVERTEX( D3DVECTOR( (float)g_ScreenCenterX-g_CrossHairRadiusX, (float)g_ScreenCenterY-g_CrossHairRadiusY, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 0.0f, 0.0f );
    g_CrossHairVerts[2] = D3DTLVERTEX( D3DVECTOR( (float)g_ScreenCenterX+g_CrossHairRadiusX, (float)g_ScreenCenterY+g_CrossHairRadiusY, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 1.0f, 1.0f );
    g_CrossHairVerts[3] = D3DTLVERTEX( D3DVECTOR( (float)g_ScreenCenterX+g_CrossHairRadiusX, (float)g_ScreenCenterY-g_CrossHairRadiusY, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 1.0f, 0.0f );


	// initialize the Billboard Vertices
	g_BillboardVerts[0]=D3DLVERTEX( D3DVECTOR( -1, -1, 0), 0xffffffff, 0,  0.0f,  1.0f );
	g_BillboardVerts[1]=D3DLVERTEX( D3DVECTOR( -1,  1, 0), 0xffffffff, 0,  0.0f,  0.0f );
	g_BillboardVerts[2]=D3DLVERTEX( D3DVECTOR(  1, -1, 0), 0xffffffff, 0,  1.0f,  1.0f );
	g_BillboardVerts[3]=D3DLVERTEX( D3DVECTOR(  1,  1, 0), 0xffffffff, 0,  1.0f,  0.0f );


	// Init the Skybox Verts
	g_SkyBoxTopVerts[0] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS, SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	g_SkyBoxTopVerts[1] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS, SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	g_SkyBoxTopVerts[2] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS, SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	g_SkyBoxTopVerts[3] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS, SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );

	g_SkyBoxBottomVerts[0] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS,-SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	g_SkyBoxBottomVerts[1] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS,-SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	g_SkyBoxBottomVerts[2] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS,-SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	g_SkyBoxBottomVerts[3] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS,-SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );

	g_SkyBoxLeftVerts[0] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS, SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );
	g_SkyBoxLeftVerts[1] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS, SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	g_SkyBoxLeftVerts[2] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS,-SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	g_SkyBoxLeftVerts[3] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS,-SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );

	g_SkyBoxRightVerts[0] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS, SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	g_SkyBoxRightVerts[1] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS, SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );
	g_SkyBoxRightVerts[2] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS,-SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	g_SkyBoxRightVerts[3] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS,-SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );

	g_SkyBoxFrontVerts[0] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS, SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	g_SkyBoxFrontVerts[1] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS, SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );
	g_SkyBoxFrontVerts[2] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS,-SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	g_SkyBoxFrontVerts[3] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS,-SKYBOX_RADIUS,-SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );

	g_SkyBoxBackVerts[0] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS, SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );
	g_SkyBoxBackVerts[1] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS, SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	g_SkyBoxBackVerts[2] = D3DLVERTEX( D3DVECTOR( SKYBOX_RADIUS,-SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	g_SkyBoxBackVerts[3] = D3DLVERTEX( D3DVECTOR(-SKYBOX_RADIUS,-SKYBOX_RADIUS, SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );

	///////////////////////////////////////////////////////

	

	// Open the data file
	FILE *file;
	if((file = fopen("Cdata.bin","rb")) == (FILE *)NULL)
	{
		g_ErrStr = "Cannot Open File \'Data.bin\'";
		return FALSE;
	}

	// Read the user's Initial Position
	fread(&(g_Face.x),sizeof(float),1,file);
	fread(&(g_Face.y),sizeof(float),1,file);
	fread(&(g_Face.z),sizeof(float),1,file);
	fread(&(g_rotAngle),sizeof(float),1,file);


	// Read the no. of Rooms
	fread(&NumRooms,sizeof(WORD),1,file);
	
	// Load all the Rooms
	for(WORD i=0;i<NumRooms;i++)
	{
		file = LoadClusterRoom(file,i,&Rooms[i],g_lpDevice,g_lpD3D);
		
		if(Rooms[i] == NULL)
		{
			NumRooms = i;	// Set the correct number of rooms
							// to prevent causing an error while
							// cleanup of the loaded rooms.

			fclose(file);	// Close the file

			if(!g_ErrStr)	// Set a general error message
				g_ErrStr = "Could not Load Room";

			return FALSE;
		}
	}

	// Read the Textures
	char TextureFileName[100];
	char FullTextureFileName[100];
	WORD Num;
	fread(&g_NumTextures,sizeof(WORD),1,file);
	for(i=0;i<g_NumTextures;i++)
	{
		// Read the Texture File Name
		fread(&Num,sizeof(WORD),1,file);
		fread(TextureFileName,sizeof(char),Num,file);
		TextureFileName[Num-3] = 'd';
		TextureFileName[Num-2] = 'd';
		TextureFileName[Num-1] = 's';
		TextureFileName[Num  ] = '\0';

		sprintf(FullTextureFileName,"TexPool\\%s",TextureFileName);

		// Create the Texture
		if( FAILED(LoadDDSTexture(FullTextureFileName,&g_Textures[i])))
		{	fclose(file); // Close the file
			g_ErrStr = "Could not load texture"; // Set an error message
			return NULL; 
		}
	}


	CurrRoom = Rooms[0];


	return TRUE;
}



//------ Function to Initialize the Application ------//

BOOLEAN InitApp()
{

	g_CrossHairRadiusX = (DWORD)(g_ScreenWidth * 16.0f / 800.0f);
	g_CrossHairRadiusY = (DWORD)(g_ScreenHeight * 16.0f / 600.0f);


	// create 3D objects
	if(!Create_Objects()) return FALSE;


	// return success to caller

	return TRUE;
}
