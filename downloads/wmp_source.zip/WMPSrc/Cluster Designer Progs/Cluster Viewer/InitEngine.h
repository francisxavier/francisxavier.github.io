

/////////////////////////////////////////////////////////////////////
//
//
//			This File handles Initialization of the Engine
//
//
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//					Defines
/////////////////////////////////////////////////////////////////////





/////////////////////////////////////////////////////////////////////
//
//					Global Vars
//
/////////////////////////////////////////////////////////////////////






/////////////////////////////////////////////////////////////////////
//
//					Function Declarations
//
/////////////////////////////////////////////////////////////////////

BOOLEAN SetInitialRenderStates();
BOOLEAN InitEngine();




/////////////////////////////////////////////////////////////////////
//
//					Function Definitions
//
/////////////////////////////////////////////////////////////////////


//------ Function to Set Initial Render States ------//

BOOLEAN SetInitialRenderStates()
{
	// Set projection matrix.
	D3DUtil_SetProjectionMatrix(g_ProjMatrix, g_ZoomValue, 0.75f, FRONT_CULL_PLANE_DIST, BACK_CULL_PLANE_DIST );
	g_lpDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&g_ProjMatrix);

	
	// Set the Texcoords for the proper stages
	g_lpDevice->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
	g_lpDevice->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX, 1);

	// Set Linear texture filtering for texture stages 0 and 1.
	g_lpDevice->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTFG_LINEAR);
	g_lpDevice->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTFN_LINEAR);
	g_lpDevice->SetTextureStageState(1,D3DTSS_MAGFILTER,D3DTFG_LINEAR);
	g_lpDevice->SetTextureStageState(1,D3DTSS_MINFILTER,D3DTFN_LINEAR);

	// Enable z-buffering. 
    g_lpDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, TRUE);

	// Set the appropriate global states
	g_lpDevice->SetRenderState( D3DRENDERSTATE_SHADEMODE,			D3DSHADE_FLAT );
    g_lpDevice->SetRenderState( D3DRENDERSTATE_DITHERENABLE,		TRUE );
    g_lpDevice->SetRenderState( D3DRENDERSTATE_TEXTUREPERSPECTIVE,	TRUE );
    g_lpDevice->SetRenderState( D3DRENDERSTATE_SPECULARENABLE,		FALSE);
    g_lpDevice->SetRenderState( D3DRENDERSTATE_LIGHTING,			FALSE);
	g_lpDevice->SetRenderState( D3DRENDERSTATE_CULLMODE,			D3DCULL_NONE);
  //g_lpDevice->SetRenderState( D3DRENDERSTATE_LOCALVIEWER,			FALSE);


	/////////////////////////////////////////////////////////////
	//
	// Record the necessary state blocks here
	//
	// eg.:-
	//
	//		lpDevice->BeginStateBlock();
	//			.....
	//			.....
	//			(Some RenderStates)
	//			.....
	//			.....
	//		if(lpDevice->EndStateBlock(&StateBlockHandle) != DD_OK)
	//		 return FALSE;
	//
	//
	// IMPORTANT NOTE :-
	//
	//			After recording all the State Blocks, a flag
	//			must be set. This flag must be checked at
	//			'CleanUp time' and only if it is set, the
	//			state blocks should be deleted, otherwise,
	//			trying to delete an invalid state bock handle
	//			will result in a memory fault.			
	//
	///////////////////////////////////////////////////////////////

	return TRUE;
}



//------ Function to Initialize the Engine ------//

BOOLEAN InitEngine()
{

	// Make everything random
	srand((unsigned)time(NULL));

	// Initialize the Global Lights(Dynamic Lighting)
	InitGlobalLights();

	// Set Initial Render States
	if(!SetInitialRenderStates())
		return FALSE;

	// Set Gamma Correction based on the g_GammaCorrectionVal var
	SetGammaCorrection((WORD)g_GammaCorrectionVal);


	return TRUE;
}



