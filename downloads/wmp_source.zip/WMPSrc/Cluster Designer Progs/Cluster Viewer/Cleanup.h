


/////////////////////////////////////////////////////////////////////
//					Cleanup.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
// Cleans up the App
/////////////////////////////////////////////////////////////////////


void Cleanup()
{



	// Release the Rooms
	for(WORD i=0;i<NumRooms;i++)
		CleanupRoom(Rooms[i]);
		
	// Release the Room's Textures
	for(i=0;i<g_NumTextures;i++)
		SafeRelease(g_Textures[i]);

	// Release the Special Textures
	SafeRelease(g_lpCrossHairTexture);
	SafeRelease(g_lpLightMapTexture);
	SafeRelease(g_lpCoronaTexture);
	SafeRelease(g_lpSphereMapTexture);

	// Release the Skybox textures
	SafeRelease(g_SkyBoxTopTexture);
	SafeRelease(g_SkyBoxBottomTexture);
	SafeRelease(g_SkyBoxLeftTexture);
	SafeRelease(g_SkyBoxRightTexture);
	SafeRelease(g_SkyBoxFrontTexture);
	SafeRelease(g_SkyBoxBackTexture);


	// Cleanup Direct X
	CleanupDX();


	// display error if one thrown

	if (g_ErrStr) {
		MessageBox(NULL, g_ErrStr, "CTF-Engine", MB_OK);
		g_ErrStr=NULL;
	}

}
