

/////////////////////////////////////////////////////////////////////
//					HitChecking.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//	Used for Hit-Checking the Player with a Room's Polys
/////////////////////////////////////////////////////////////////////







/////////////////////////////////////////////////////////////////////

//////////////////////////////////////////
//			Function Definitions		//
//////////////////////////////////////////

/////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
// Function to calculate a Polygon's Normal
/////////////////////////////////////////////////////////////////////

inline int CalcPolyNormal(POLYGON *tpoly, ROOM *pRoom)
{
	float tx1,ty1,tz1,tx2,ty2,tz2,Denom;

	tx1 = pRoom->RoomVerts[tpoly->Indices[0]].x - pRoom->RoomVerts[tpoly->Indices[1]].x;
	ty1 = pRoom->RoomVerts[tpoly->Indices[0]].y - pRoom->RoomVerts[tpoly->Indices[1]].y;
	tz1 = pRoom->RoomVerts[tpoly->Indices[0]].z - pRoom->RoomVerts[tpoly->Indices[1]].z;

	tx2 = pRoom->RoomVerts[tpoly->Indices[2]].x - pRoom->RoomVerts[tpoly->Indices[1]].x;
	ty2 = pRoom->RoomVerts[tpoly->Indices[2]].y - pRoom->RoomVerts[tpoly->Indices[1]].y;
	tz2 = pRoom->RoomVerts[tpoly->Indices[2]].z - pRoom->RoomVerts[tpoly->Indices[1]].z;

	
	tpoly->nx = ty2 * tz1 - ty1 * tz2;
	tpoly->ny = tx1 * tz2 - tx2 * tz1;
	tpoly->nz = tx2 * ty1 - tx1 * ty2;

	Denom = sqrtf(tpoly->nx * tpoly->nx + tpoly->ny * tpoly->ny + tpoly->nz * tpoly->nz);

	if(Denom == 0.0f)
		return 0;

	tpoly->nx /= Denom;
	tpoly->ny /= Denom;
	tpoly->nz /= Denom;

	return 1;
}


/////////////////////////////////////////////////////////////////////
// Function to Calculate a Poly's Side Normals
/////////////////////////////////////////////////////////////////////

inline int CalcPolySideNormal(POLYGON *tpoly, ROOM *pRoom)
{
	WORD i;
	float tx1,ty1,tz1,tx2,ty2,tz2,Denom;

	for(i=1;i<tpoly->NumVertices;i++)
	{
		tx1 = pRoom->RoomVerts[tpoly->Indices[i]].x - pRoom->RoomVerts[tpoly->Indices[i-1]].x;
		ty1 = pRoom->RoomVerts[tpoly->Indices[i]].y - pRoom->RoomVerts[tpoly->Indices[i-1]].y;
		tz1 = pRoom->RoomVerts[tpoly->Indices[i]].z - pRoom->RoomVerts[tpoly->Indices[i-1]].z;

		tx2 = -10.0f * tpoly->nx;
		ty2 = -10.0f * tpoly->ny;
		tz2 = -10.0f * tpoly->nz;

		tpoly->Normals[i-1].nx = ty2 * tz1 - ty1 * tz2;
		tpoly->Normals[i-1].ny = tx1 * tz2 - tx2 * tz1;
		tpoly->Normals[i-1].nz = tx2 * ty1 - tx1 * ty2;

		Denom = sqrtf(tpoly->Normals[i-1].nx * tpoly->Normals[i-1].nx 
					+ tpoly->Normals[i-1].ny * tpoly->Normals[i-1].ny
					+ tpoly->Normals[i-1].nz * tpoly->Normals[i-1].nz);
		
		if(Denom == 0.0f)
			return 0;

		tpoly->Normals[i-1].nx /= Denom;
		tpoly->Normals[i-1].ny /= Denom;
		tpoly->Normals[i-1].nz /= Denom;
	}


	tx1 = pRoom->RoomVerts[tpoly->Indices[0]].x - pRoom->RoomVerts[tpoly->Indices[i-1]].x;
	ty1 = pRoom->RoomVerts[tpoly->Indices[0]].y - pRoom->RoomVerts[tpoly->Indices[i-1]].y;
	tz1 = pRoom->RoomVerts[tpoly->Indices[0]].z - pRoom->RoomVerts[tpoly->Indices[i-1]].z;

	tx2 = -10.0f * tpoly->nx;
	ty2 = -10.0f * tpoly->ny;
	tz2 = -10.0f * tpoly->nz;

	tpoly->Normals[i-1].nx = ty2 * tz1 - ty1 * tz2;
	tpoly->Normals[i-1].ny = tx1 * tz2 - tx2 * tz1;
	tpoly->Normals[i-1].nz = tx2 * ty1 - tx1 * ty2;

	Denom = sqrtf(tpoly->Normals[i-1].nx * tpoly->Normals[i-1].nx 
				+ tpoly->Normals[i-1].ny * tpoly->Normals[i-1].ny
				+ tpoly->Normals[i-1].nz * tpoly->Normals[i-1].nz);
		
	if(Denom == 0.0f)
		return 0;

	tpoly->Normals[i-1].nx /= Denom;
	tpoly->Normals[i-1].ny /= Denom;
	tpoly->Normals[i-1].nz /= Denom;
	
	return 1;
}



/////////////////////////////////////////////////////////////////////
// Function to Calculate a Poly's LightMap 2nd Normal
/////////////////////////////////////////////////////////////////////

inline int CalcPolyLightMapNormal2(POLYGON *tpoly,ROOM *pRoom)
{
	float Denom;

	tpoly->LightMapNormal2.nx = pRoom->RoomVerts[tpoly->Indices[1]].x - pRoom->RoomVerts[tpoly->Indices[0]].x;
	tpoly->LightMapNormal2.ny = pRoom->RoomVerts[tpoly->Indices[1]].y - pRoom->RoomVerts[tpoly->Indices[0]].y;
	tpoly->LightMapNormal2.nz = pRoom->RoomVerts[tpoly->Indices[1]].z - pRoom->RoomVerts[tpoly->Indices[0]].z;

	Denom = sqrtf(tpoly->LightMapNormal2.nx * tpoly->LightMapNormal2.nx 
				+ tpoly->LightMapNormal2.ny * tpoly->LightMapNormal2.ny
				+ tpoly->LightMapNormal2.nz * tpoly->LightMapNormal2.nz);

	if(Denom == 0.0f)
		return 0;

	tpoly->LightMapNormal2.nx /= Denom;
	tpoly->LightMapNormal2.ny /= Denom;
	tpoly->LightMapNormal2.nz /= Denom;

	return 1;
}



/////////////////////////////////////////////////////////////////////
// Function to hit-check the player's Face
// Returns pN as the new location after hit-check testing
/////////////////////////////////////////////////////////////////////

inline void DoFaceHitChecking(ROOM *pRoom, D3DVECTOR *pO,D3DVECTOR *pN)
{
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackOB, *pStackNC;
	float			Ix,Iy,Iz,pDist,one_by_denom;
	int				Intersection,i;
	float			OB,NC;


	i=0;
	do
	{

	ppoly = pRoom->BSPPolyHead;
	pStackP = pRoom->StackP;
	pStackOB = pRoom->StackOB;
	pStackNC = pRoom->StackNC;
	Intersection = 0;

	for(;;)
	{
		while(ppoly)
		{
			OB = PERPDISTP(pO,ppoly);
			NC = PERPDISTP(pN,ppoly);				

			if(OB > 0.0f)
			{
				if(NC < MINDIST)
				{ *pStackP++ = ppoly; *pStackOB++ = OB; *pStackNC++ = NC; }
				ppoly = ppoly->front;
			}
			else
			{
				if(NC > -MINDIST)
				{ *pStackP++ = ppoly; *pStackOB++ = OB; }
				ppoly = ppoly->back;
			}
		}

		if(pStackP > pRoom->StackP)
		{
			ppoly = *(--pStackP); OB = *(--pStackOB);
	
			if(OB > 0.0f)
			{
				NC = *(--pStackNC);

				// First do the real hit checking
			
				if((OB > MINDIST - 0.01f) && ppoly->ParentComponent->HitChecked)
				{
					if(NC > 0.0f)
					{	
						Ix = pN->x - NC*ppoly->nx;
						Iy = pN->y - NC*ppoly->ny;
						Iz = pN->z - NC*ppoly->nz;
					}
					else
					{
						one_by_denom = 1.0f/(OB-NC);
						Ix = (pN->x*OB - pO->x*NC)*one_by_denom;
						Iy = (pN->y*OB - pO->y*NC)*one_by_denom;
						Iz = (pN->z*OB - pO->z*NC)*one_by_denom;
					}		
					
					Intersection = 1;
					for(WORD j=0;j<ppoly->NumVertices;j++)
					{
						pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
								+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
								+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
						if(pDist > MINDIST)
						{ Intersection = 0; break; }
					}

					if(Intersection)
					{
						pN->x = Ix + (MINDIST+0.01f)*ppoly->nx;
						pN->y = Iy + (MINDIST+0.01f)*ppoly->ny;
						pN->z = Iz + (MINDIST+0.01f)*ppoly->nz;
						
						if(ppoly->ny > 0.8f)
							g_tGravity = 0.0f;
						else if(ppoly->ny < -0.7 && !g_bIsOnGround)
						{
							g_Force.y = -g_Force.y;
							g_ManHeight = CROUCHHEIGHT;
						}

						break;
					}
				}

				ppoly = ppoly->back;
			}
			else
				ppoly = ppoly->front;
		}
		else
			break;
	}

	i++;
	}while(Intersection && i<10000);
}



/////////////////////////////////////////////////////////////////////
// Function to hit-check the player's Feet
// Sets the Gravity, StandUpForce and CanDoJump
/////////////////////////////////////////////////////////////////////

inline BOOLEAN DoFeetHitChecking(ROOM *pRoom, D3DVECTOR *pO,D3DVECTOR *pN)
{
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackOB, *pStackNC;
	float			Ix,Iy,Iz,pDist,one_by_denom;
	int				Intersection;
	float			OB,NC;


	ppoly    = pRoom->BSPPolyHead;
	pStackP  = pRoom->StackP;
	pStackOB = pRoom->StackOB;
	pStackNC = pRoom->StackNC;
	Intersection = 0;

	for(;;)
	{
		while(ppoly)
		{
			OB = PERPDISTP(pO,ppoly);
			NC = PERPDISTP(pN,ppoly);				

			if(OB > 0.0f)
			{
				if(NC < 0.0f)
				{ *pStackP++ = ppoly; *pStackOB++ = OB; *pStackNC++ = NC; }
				ppoly = ppoly->front;
			}
			else
			{
				if(NC > 0.0f)
				{ *pStackP++ = ppoly; *pStackOB++ = OB; }
				ppoly = ppoly->back;
			}
		}

		if(pStackP > pRoom->StackP)
		{
			ppoly = *(--pStackP); OB = *(--pStackOB);
	
			if(OB > 0.0f)
			{
				NC = *(--pStackNC);

				// First do the real hit checking

				if((OB-NC > 0.001f && ppoly->ny > 0.5f)  && ppoly->ParentComponent->HitChecked)
				{
					one_by_denom = 1.0f/(OB-NC);
					Ix = (pN->x*OB - pO->x*NC)*one_by_denom;
					Iy = (pN->y*OB - pO->y*NC)*one_by_denom;
					Iz = (pN->z*OB - pO->z*NC)*one_by_denom;
				
					Intersection = 1;
					for(WORD j=0;j<ppoly->NumVertices;j++)
					{
						pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
								+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
								+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
						if(pDist > 0.0f)
						{ Intersection = 0; break; }
					}

					if(Intersection)
					{
						if((pO->y-Iy) + STANDUPFORCE*g_Elapsed > g_ManHeight)
						{
							g_StandUpForce = g_ManHeight-(pO->y-Iy);
							g_bCanDoJump = TRUE;
						}
						else
							g_StandUpForce = STANDUPFORCE*g_Elapsed;

						g_tGravity = 0.0f;
						g_bIsOnGround = TRUE;
						
						return TRUE;
					}
				}

				ppoly = ppoly->back;
			}
			else
				ppoly = ppoly->front;
		}
		else
			break;
	}

	return FALSE;
}



/////////////////////////////////////////////////////////////////////
// Function to hit-check the Light's Coronas
// Returns a float value determining the visibility of a light corona
/////////////////////////////////////////////////////////////////////

inline BOOLEAN IsLightCoronaVisible(NONAMBLIGHT *pL, ROOM *pRoom)
{
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackOB, *pStackNC;
	float			Ix,Iy,Iz,pDist,one_by_denom;
	int				Intersection;
	float			OB,NC;


	ppoly    = pRoom->BSPPolyHead;
	pStackP  = pRoom->StackP;
	pStackOB = pRoom->StackOB;
	pStackNC = pRoom->StackNC;
	Intersection = 0;

	for(;;)
	{
		while(ppoly)
		{
			OB = PERPDISTV(g_Face,ppoly);
			NC = PERPDISTP(pL,ppoly);				

			if(OB > 0.0f)
			{
				if(NC < 0.0f)
				{ *pStackP++ = ppoly; *pStackOB++ = OB; *pStackNC++ = NC; }
				ppoly = ppoly->front;
			}
			else
			{
				if(NC > 0.0f)
				{ *pStackP++ = ppoly; *pStackOB++ = OB; }
				ppoly = ppoly->back;
			}
		}

		if(pStackP > pRoom->StackP)
		{
			ppoly = *(--pStackP); OB = *(--pStackOB);
	
			if(OB > 0.0f)
			{
				NC = *(--pStackNC);

				// First do the real hit checking

				if(	OB-NC > 0.001f &&
					(!ppoly->ParentComponent->HasAlpha) &&
					  ppoly->ParentComponent->HitChecked)
				{
					one_by_denom = 1.0f/(OB-NC);
					Ix = (pL->x*OB - g_Face.x*NC)*one_by_denom;
					Iy = (pL->y*OB - g_Face.y*NC)*one_by_denom;
					Iz = (pL->z*OB - g_Face.z*NC)*one_by_denom;
				
					Intersection = 1;
					for(WORD j=0;j<ppoly->NumVertices;j++)
					{
						pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
								+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
								+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;

						if(pDist > 0.0f)
						{  Intersection = 0; break; }
					}

					if(Intersection)
					{
						return FALSE;
					}
				}

				ppoly = ppoly->back;
			}
			else
				ppoly = ppoly->front;
		}
		else
			break;
	}

	return TRUE;
}


