

/////////////////////////////////////////////////////////////////////
//
//
//			Time Handler : Handles Everything to do with time
//
//
/////////////////////////////////////////////////////////////////////


// Global Time vars
//------------------

float		g_Elapsed;					// The time elapsed
LONGLONG	g_CurrentTime;				// current time
LONGLONG	g_LastTime;					// time of previous frame

LONGLONG	g_PerfTimerFreq;			// performance timer frequency
BOOLEAN		g_bPerfTimerThere = FALSE;	// flag determining which timer to use
float		g_TimeScale;				// scaling factor for time





/////////////////////////////////////////////////////////////////////
//
//					Function Definitions
//
/////////////////////////////////////////////////////////////////////


void InitTimeHandler()
{
	// See if the high performance timer is available.
	// If it is, then use it.

	if (QueryPerformanceFrequency((LARGE_INTEGER *) &g_PerfTimerFreq))
	{ 
		g_bPerfTimerThere = TRUE;
		QueryPerformanceCounter((LARGE_INTEGER *) &g_LastTime); 
		g_TimeScale = 1.0f / g_PerfTimerFreq;
	}
	else
	{ 
		g_LastTime  = timeGetTime(); 
		g_TimeScale = 0.001f;
	}
}


void HandleTime()
{
	// Get the current time using the appropriate method
	if (g_bPerfTimerThere) 
		QueryPerformanceCounter((LARGE_INTEGER *) &g_CurrentTime); 
	else 
		g_CurrentTime = timeGetTime(); 

	// Calculate elapsed time
	g_Elapsed = (g_CurrentTime - g_LastTime) * g_TimeScale;

	// save last time
	g_LastTime = g_CurrentTime;
				
}


