

/////////////////////////////////////////////////////////////////////
//							LightMap.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//	Handles all the Global LightMaps
/////////////////////////////////////////////////////////////////////

//	Note :	While initializing Lights, the 'one_by_2Radius' member
//			of the light must be initialized properly, but the 
//			'Brightness_by_Radius' member need not be initialized
//			 for spot lights, it is only used with point lights.


/////////////////////////////////////////////////////////////////////
//						Defines
/////////////////////////////////////////////////////////////////////

#define MAX_LIGHTS		1000	// The maximum no. of Global lights



/////////////////////////////////////////////////////////////////////
//						Var Declarations
/////////////////////////////////////////////////////////////////////

LIGHT	g_GlobalLights[MAX_LIGHTS + 1];	// The Global Lights array
LIGHT	*g_UsedGL,*g_UnusedGL;			// The used and unused GL ptrs.





/////////////////////////////////////////////////////////////////////
//						Function Prototypes
/////////////////////////////////////////////////////////////////////

void			InitGlobalLights();
inline LIGHT	*GetNewGLptr();
inline void		ReturnUsedGLptr(LIGHT *tmpGL);





/////////////////////////////////////////////////////////////////////
//	Initialize the Global Lights
/////////////////////////////////////////////////////////////////////

void InitGlobalLights()
{
	// Set up the used GLs

	g_UsedGL = g_GlobalLights;
	g_UsedGL->next = g_UsedGL;
	g_UsedGL->previous = g_UsedGL;

	// Set up the Unused GLs

	g_UnusedGL = &g_GlobalLights[1];
	for(WORD i=2; i<MAX_LIGHTS + 1; i++)
		g_GlobalLights[i-1].next = &g_GlobalLights[i];

	g_GlobalLights[MAX_LIGHTS].next = NULL;
}


/////////////////////////////////////////////////////////////////////
//	Get a new light pointer
/////////////////////////////////////////////////////////////////////

inline LIGHT *GetNewGLptr()
{
	LIGHT *tmpGL;

	if(g_UnusedGL == NULL) return(g_UsedGL);

	tmpGL = g_UnusedGL;
	g_UnusedGL = g_UnusedGL->next;

	tmpGL->next = g_UsedGL->next;
	g_UsedGL->next = tmpGL;
	tmpGL->previous = g_UsedGL;
	tmpGL->next->previous = tmpGL;

	return(tmpGL);
}


/////////////////////////////////////////////////////////////////////
// Put back an old light
/////////////////////////////////////////////////////////////////////

inline void ReturnUsedGLptr(LIGHT *tmpGL)
{
	if(tmpGL == g_UsedGL) return;

	tmpGL->previous->next = tmpGL->next;
	tmpGL->next->previous = tmpGL->previous;

	tmpGL->next = g_UnusedGL;
	g_UnusedGL = tmpGL;
}



/////////////////////////////////////////////////////////////////////
//	Draw the Global Lights on a given Room's solid components
/////////////////////////////////////////////////////////////////////

void DrawSolidComponentsGlobalLights(ROOM *pRoom, D3DVECTOR *ViewPos, LPDIRECT3DDEVICE7 lpD)
{
	// Vars used for BSP-Walking
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackDist,*pStackOB,*pStackNC;
	float			Ix,Iy,Iz,pDist,Dist,OB,NC;
	float			one_by_denom,denom_by_OB;
	int				Intersection;
	D3DVECTOR		O,N;

	// Vars used to draw the Lightmaps
	WORD			*ppoly_index,*ppoly_end_index;
	WORD			*ppoly_Dindex,*ppoly_end_Dindex;

	WORD				*Triind;
	TRANSFORMED_VERTEX	*pTVertices;
			
	
	for(LIGHT *pLight=g_UsedGL->next;
		pLight != g_UsedGL;
		pLight = pLight->next
	   )
	{

		// Lock the transformed VB
		if( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
			                         NULL ) != D3D_OK )
			return;


	if(pLight->x2 || pLight->y2 || pLight->z2)
	{
		// Spot Light
		///////////////


		// Some variables
		Triind	= pRoom->RoomVertInds;

		ppoly = pRoom->BSPPolyHead;
		pStackP = pRoom->StackP;
		pStackOB = pRoom->StackOB;
		pStackNC = pRoom->StackNC;

		O.x = pLight->x; N.x = pLight->x2;
		O.y = pLight->y; N.y = pLight->y2;
		O.z = pLight->z; N.z = pLight->z2;


		for(;;)
		{
			while(ppoly)
			{
				OB = PERPDISTV(O,ppoly);
				NC = PERPDISTV(N,ppoly);

				if(OB > 0.0f)
				{
					if(NC < pLight->Radius)
					{ *pStackP++ = ppoly; *pStackOB++ = OB; *pStackNC++ = NC; }
					ppoly = ppoly->front;
				}
				else
				{
					if(NC > -pLight->Radius)
					{ *pStackP++ = ppoly; *pStackOB++ = OB; }
					ppoly = ppoly->back;
				}
			}

			if(pStackP > pRoom->StackP)
			{
				ppoly = *(--pStackP); OB = *(--pStackOB);
	
				if(OB > 0.0f)
				{
					NC = *(--pStackNC);
					
					// Do the hit checking

					if(	(NC < 0.0f)							&&
						(!ppoly->ParentComponent->Energy)	&&
						(!ppoly->ParentComponent->HasAlpha)	&&
						(PERPDISTP(ViewPos,ppoly) > 0.0f)
					  )
					{
						one_by_denom = 1.0f/(OB-NC);
						denom_by_OB = (OB-NC)/OB;
						Ix = (N.x*OB - O.x*NC)*one_by_denom;
						Iy = (N.y*OB - O.y*NC)*one_by_denom;
						Iz = (N.z*OB - O.z*NC)*one_by_denom;

						Intersection = 1;
						for(WORD j=0;j<ppoly->NumVertices;j++)
						{
							pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
									+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
									+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
							if(pDist > pLight->Radius)
							{ Intersection = 0; break; }
						}

						if(Intersection)
						{
							// This poly's color is changed
							ppoly->ColorChanged = TRUE;

							ppoly_end_index  = ppoly->Indices  + ppoly->NumVertices;
							ppoly_end_Dindex = ppoly->DIndices + ppoly->NumVertices;
							
							float LBrightness = pLight->Brightness * (1.0f - OB * one_by_denom);
							// Apply Lambert's Law to the Spot Light
							LBrightness *= (pLight->nx * ppoly->nx +
											pLight->ny * ppoly->ny + 
											pLight->nz * ppoly->nz);

							// Avoid drawing spot lights without enough brightness
							if(LBrightness > 0.01f)
							{
								// See that the brightness does not go beyond 1.0
								if(LBrightness > 1.0f)
									LBrightness = 1.0f;

								DWORD LColor = D3DRGB(LBrightness*(pLight->R),LBrightness*(pLight->G),LBrightness*(pLight->B));

								for(ppoly_index = ppoly->Indices,ppoly_Dindex = ppoly->DIndices;
									ppoly_index < ppoly_end_index;
									ppoly_index++,ppoly_Dindex++)
								{
									pTVertices[*ppoly_Dindex].color = LColor;
							
									pTVertices[*ppoly_Dindex].tuL = 0.5f
										+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->LightMapNormal2)
										* pLight->one_by_2Radius * denom_by_OB;
								
									pTVertices[*ppoly_Dindex].tvL = 0.5f
										+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->Normals[0])
										* pLight->one_by_2Radius * denom_by_OB;

									if(ppoly_Dindex < ppoly->DIndices + 3)
										*Triind++ = *ppoly_Dindex;
									else
									{
										*Triind++ = *(ppoly->DIndices);
										*Triind++ = *(Triind - 2);
										*Triind++ = *ppoly_Dindex;
									}
								}
							}
						}
					}	
					ppoly = ppoly->back;
				}
				else
					ppoly = ppoly->front;
			}
			else
				break;
		}


	}	// End of calculating Spot Light
	else	
	{
		// Point Light
		//////////////

		// Some variables
		Triind	= pRoom->RoomVertInds; 

		ppoly = pRoom->BSPPolyHead;
		pStackP = pRoom->StackP;
		pStackDist = pRoom->StackOB;

	
		for(;;)
		{
			while(ppoly)
			{
				Dist = PERPDISTP(pLight,ppoly);
				
				if(Dist > 0.0f)
				{
					if(Dist < pLight->Radius)
					{ *pStackP++ = ppoly; *pStackDist++ = Dist; }
	
					ppoly = ppoly->front;
				}
				else
				{
					if(Dist > -pLight->Radius)
					{ *pStackP++ = ppoly; *pStackDist++ = Dist; }
					
					ppoly = ppoly->back;
				}
			}

			if(pStackP > pRoom->StackP)
			{
				ppoly = *(--pStackP); Dist = *(--pStackDist);
	
				if(Dist > 0.0f)
				{

					if(	(Dist < pLight->Radius)				&&
						(!ppoly->ParentComponent->Energy)	&&
						(!ppoly->ParentComponent->HasAlpha)	&&
						(PERPDISTP(ViewPos,ppoly) > 0.0f)
					  )
					{
						Ix = pLight->x - Dist*ppoly->nx;
						Iy = pLight->y - Dist*ppoly->ny;
						Iz = pLight->z - Dist*ppoly->nz;
						
						Intersection = 1;
						for(WORD j=0;j<ppoly->NumVertices;j++)
						{
							pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
									+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
									+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
							if(pDist > pLight->Radius)
							{ Intersection = 0; break; }
						}

						if(Intersection)
						{
							// This poly's color is changed
							ppoly->ColorChanged = TRUE;

							ppoly_end_index  = ppoly->Indices  + ppoly->NumVertices;
							ppoly_end_Dindex = ppoly->DIndices + ppoly->NumVertices;

							float LBrightness = pLight->Brightness - Dist * pLight->Brightness_by_Radius;
							DWORD LColor = D3DRGB(LBrightness*(pLight->R),LBrightness*(pLight->G),LBrightness*(pLight->B));

							for(ppoly_index = ppoly->Indices,ppoly_Dindex = ppoly->DIndices;
								ppoly_index < ppoly_end_index;
								ppoly_index++,ppoly_Dindex++)
							{
								pTVertices[*ppoly_Dindex].color = LColor;
							
								pTVertices[*ppoly_Dindex].tuL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->LightMapNormal2)
									* pLight->one_by_2Radius;

								pTVertices[*ppoly_Dindex].tvL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->Normals[0])
									* pLight->one_by_2Radius;

								if(ppoly_Dindex < ppoly->DIndices + 3)
									*Triind++ = *ppoly_Dindex;
								else
								{
									*Triind++ = *(ppoly->DIndices);
									*Triind++ = *(Triind - 2);
									*Triind++ = *ppoly_Dindex;
								}
							}
						}
					}

					ppoly = ppoly->back;
				}
				else
					ppoly = ppoly->front;
			}
			else
				break;
		}


	}// End of calculating Point Light


		// Unlock the Transformed VB
		pRoom->TransformedRoomVB->Unlock();


	// Draw the Light (Spot or Point)
	if(Triind > pRoom->RoomVertInds)
	{
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									pRoom->RoomVertInds,
									(Triind - pRoom->RoomVertInds),
									0);
	}

	}// End of drawing this light, go to the next light
}




/////////////////////////////////////////////////////////////////////
//	Draw the Global Lights on a given Room's Glass components
/////////////////////////////////////////////////////////////////////

void DrawAlphaComponentsGlobalLights(ROOM *pRoom, D3DVECTOR *ViewPos, LPDIRECT3DDEVICE7 lpD)
{
	// Vars used for BSP-Walking
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackDist,*pStackOB,*pStackNC;
	float			Ix,Iy,Iz,pDist,Dist,OB,NC;
	float			one_by_denom,denom_by_OB;
	int				Intersection;
	D3DVECTOR		O,N;

	// Vars used to draw the Lightmaps
	WORD			*ppoly_index,*ppoly_end_index;
	WORD			*ppoly_Dindex,*ppoly_end_Dindex;

	WORD				*Triind;
	TRANSFORMED_VERTEX	*pTVertices;
			
	
	for(LIGHT *pLight=g_UsedGL->next;
		pLight != g_UsedGL;
		pLight = pLight->next
	   )
	{

		// Lock the transformed VB
		if( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
			                         NULL ) != D3D_OK )
			return;


	if(pLight->x2 || pLight->y2 || pLight->z2)
	{
		// Spot Light
		///////////////


		// Some variables
		Triind	= pRoom->RoomVertInds;

		ppoly = pRoom->BSPPolyHead;
		pStackP = pRoom->StackP;
		pStackOB = pRoom->StackOB;
		pStackNC = pRoom->StackNC;

		O.x = pLight->x; N.x = pLight->x2;
		O.y = pLight->y; N.y = pLight->y2;
		O.z = pLight->z; N.z = pLight->z2;


		for(;;)
		{
			while(ppoly)
			{
				OB = PERPDISTV(O,ppoly);
				NC = PERPDISTV(N,ppoly);

				if(OB > 0.0f)
				{
					if(NC < pLight->Radius)
					{ *pStackP++ = ppoly; *pStackOB++ = OB; *pStackNC++ = NC; }
					ppoly = ppoly->front;
				}
				else
				{
					if(NC > -pLight->Radius)
					{ *pStackP++ = ppoly; *pStackOB++ = OB; }
					ppoly = ppoly->back;
				}
			}

			if(pStackP > pRoom->StackP)
			{
				ppoly = *(--pStackP); OB = *(--pStackOB);
	
				if(OB > 0.0f)
				{
					NC = *(--pStackNC);
					
					// Do the hit checking

					if(	(NC < 0.0f)							&&
						(!ppoly->ParentComponent->Energy)	&&
						(ppoly->ParentComponent->HasAlpha)	&&
						(PERPDISTP(ViewPos,ppoly) > 0.0f)
					  )
					{
						one_by_denom = 1.0f/(OB-NC);
						denom_by_OB = (OB-NC)/OB;
						Ix = (N.x*OB - O.x*NC)*one_by_denom;
						Iy = (N.y*OB - O.y*NC)*one_by_denom;
						Iz = (N.z*OB - O.z*NC)*one_by_denom;

						Intersection = 1;
						for(WORD j=0;j<ppoly->NumVertices;j++)
						{
							pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
									+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
									+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
							if(pDist > pLight->Radius)
							{ Intersection = 0; break; }
						}

						if(Intersection)
						{
							// This poly's color is changed
							ppoly->ColorChanged = TRUE;

							ppoly_end_index  = ppoly->Indices  + ppoly->NumVertices;
							ppoly_end_Dindex = ppoly->DIndices + ppoly->NumVertices;
							
							float LBrightness = pLight->Brightness * (1.0f - OB * one_by_denom);
							// Apply Lambert's Law to the Spot Light
							LBrightness *= (pLight->nx * ppoly->nx +
											pLight->ny * ppoly->ny + 
											pLight->nz * ppoly->nz);

							// Avoid drawing spot lights without enough brightness
							if(LBrightness > 0.01f)
							{
								// See that the brightness does not go beyond 1.0
								if(LBrightness > 1.0f)
									LBrightness = 1.0f;

								DWORD LColor = D3DRGB(LBrightness*(pLight->R),LBrightness*(pLight->G),LBrightness*(pLight->B));

								for(ppoly_index = ppoly->Indices,ppoly_Dindex = ppoly->DIndices;
									ppoly_index < ppoly_end_index;
									ppoly_index++,ppoly_Dindex++)
								{
									pTVertices[*ppoly_Dindex].color = LColor;
							
									pTVertices[*ppoly_Dindex].tuL = 0.5f
										+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->LightMapNormal2)
										* pLight->one_by_2Radius * denom_by_OB;
								
									pTVertices[*ppoly_Dindex].tvL = 0.5f
										+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->Normals[0])
										* pLight->one_by_2Radius * denom_by_OB;

									if(ppoly_Dindex < ppoly->DIndices + 3)
										*Triind++ = *ppoly_Dindex;
									else
									{
										*Triind++ = *(ppoly->DIndices);
										*Triind++ = *(Triind - 2);
										*Triind++ = *ppoly_Dindex;
									}
								}
							}
						}
					}	
					ppoly = ppoly->back;
				}
				else
					ppoly = ppoly->front;
			}
			else
				break;
		}


	}	// End of calculating Spot Light
	else	
	{
		// Point Light
		//////////////

		// Some variables
		Triind	= pRoom->RoomVertInds; 

		ppoly = pRoom->BSPPolyHead;
		pStackP = pRoom->StackP;
		pStackDist = pRoom->StackOB;

	
		for(;;)
		{
			while(ppoly)
			{
				Dist = PERPDISTP(pLight,ppoly);
				
				if(Dist > 0.0f)
				{
					if(Dist < pLight->Radius)
					{ *pStackP++ = ppoly; *pStackDist++ = Dist; }
	
					ppoly = ppoly->front;
				}
				else
				{
					if(Dist > -pLight->Radius)
					{ *pStackP++ = ppoly; *pStackDist++ = Dist; }
					
					ppoly = ppoly->back;
				}
			}

			if(pStackP > pRoom->StackP)
			{
				ppoly = *(--pStackP); Dist = *(--pStackDist);
	
				if(Dist > 0.0f)
				{

					if(	(Dist < pLight->Radius)				&&
						(!ppoly->ParentComponent->Energy)	&&
						(ppoly->ParentComponent->HasAlpha)	&&
						(PERPDISTP(ViewPos,ppoly) > 0.0f)
					  )
					{
						Ix = pLight->x - Dist*ppoly->nx;
						Iy = pLight->y - Dist*ppoly->ny;
						Iz = pLight->z - Dist*ppoly->nz;
						
						Intersection = 1;
						for(WORD j=0;j<ppoly->NumVertices;j++)
						{
							pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
									+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
									+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
							if(pDist > pLight->Radius)
							{ Intersection = 0; break; }
						}

						if(Intersection)
						{
							// This poly's color is changed
							ppoly->ColorChanged = TRUE;

							ppoly_end_index  = ppoly->Indices  + ppoly->NumVertices;
							ppoly_end_Dindex = ppoly->DIndices + ppoly->NumVertices;

							float LBrightness = pLight->Brightness - Dist * pLight->Brightness_by_Radius;
							DWORD LColor = D3DRGB(LBrightness*(pLight->R),LBrightness*(pLight->G),LBrightness*(pLight->B));

							for(ppoly_index = ppoly->Indices,ppoly_Dindex = ppoly->DIndices;
								ppoly_index < ppoly_end_index;
								ppoly_index++,ppoly_Dindex++)
							{
								pTVertices[*ppoly_Dindex].color = LColor;
							
								pTVertices[*ppoly_Dindex].tuL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->LightMapNormal2)
									* pLight->one_by_2Radius;

								pTVertices[*ppoly_Dindex].tvL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->Normals[0])
									* pLight->one_by_2Radius;

								if(ppoly_Dindex < ppoly->DIndices + 3)
									*Triind++ = *ppoly_Dindex;
								else
								{
									*Triind++ = *(ppoly->DIndices);
									*Triind++ = *(Triind - 2);
									*Triind++ = *ppoly_Dindex;
								}
							}
						}
					}

					ppoly = ppoly->back;
				}
				else
					ppoly = ppoly->front;
			}
			else
				break;
		}


	}// End of calculating Point Light


		// Unlock the Transformed VB
		pRoom->TransformedRoomVB->Unlock();


	// Draw the Light (Spot or Point)
	if(Triind > pRoom->RoomVertInds)
	{
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									pRoom->RoomVertInds,
									(Triind - pRoom->RoomVertInds),
									0);
	}

	}// End of drawing this light, go to the next light
}
