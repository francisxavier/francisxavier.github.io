

/////////////////////////////////////////////////////////////////////
//					Engine Defines and Globals.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//	Consists of all the defines and Global variables for the
//	CTF Engine.
/////////////////////////////////////////////////////////////////////


// Var that indicates if the App is Running or has Stopped(Paused)
BOOLEAN		g_AppRunning=FALSE;


// The Screen Width,Height,Center
DWORD	g_ScreenWidth,g_ScreenHeight;
DWORD	g_ScreenCenterX,g_ScreenCenterY;


// Switches
BOOLEAN g_bStatusEnabled=TRUE;
BOOLEAN g_bHitChecking=TRUE;		
BOOLEAN g_bGravityEnabled=FALSE;
BOOLEAN g_bDrawDynamicLights=TRUE;
BOOLEAN g_bDrawUserSpotLight=FALSE;
BOOLEAN g_bDrawUserPointLight=FALSE;



// The radius of the skybox
#define SKYBOX_RADIUS			25000.0f
#define MAX_MOVEABLE_DIST		(SKYBOX_RADIUS-1000.0f)
#define FRONT_CULL_PLANE_DIST	5.0f
#define BACK_CULL_PLANE_DIST	(SKYBOX_RADIUS * 3.465)



// Some Colours
#define WHITE			0xffffffff
#define LIGHTGRAY		0xC0C0C0


// Check if a vector is in a room
#define VEC_IN_ROOM(V,R)	((V).x > (R)->Rx1 &&	\
							 (V).y > (R)->Ry1 &&	\
							 (V).z > (R)->Rz1 &&	\
							 (V).x < (R)->Rx2 &&	\
							 (V).y < (R)->Ry2 &&	\
							 (V).z < (R)->Rz2 )



// Perpendicular distance
#define PERPDISTP(V,P) ((V->x - pRoom->RoomVerts[P->Indices[0]].x) * P->nx +	\
				        (V->y - pRoom->RoomVerts[P->Indices[0]].y) * P->ny +	\
					    (V->z - pRoom->RoomVerts[P->Indices[0]].z) * P->nz )

#define PERPDISTV(V,P) ((V.x - pRoom->RoomVerts[P->Indices[0]].x) * P->nx +	\
				        (V.y - pRoom->RoomVerts[P->Indices[0]].y) * P->ny +	\
				        (V.z - pRoom->RoomVerts[P->Indices[0]].z) * P->nz )

#define CURRPERPDISTV(V,P) ((V.x - CurrRoom->RoomVerts[P->Indices[0]].x) * P->nx +	\
							(V.y - CurrRoom->RoomVerts[P->Indices[0]].y) * P->ny +	\
							(V.z - CurrRoom->RoomVerts[P->Indices[0]].z) * P->nz )

#define PERPDISTPOLYVERT(I,N) ((pRoom->RoomVerts[tPoly->Indices[I]].x - pRoom->RoomVerts[tPoly->Indices[0]].x) * N.nx +	\
							   (pRoom->RoomVerts[tPoly->Indices[I]].y - pRoom->RoomVerts[tPoly->Indices[0]].y) * N.ny +	\
							   (pRoom->RoomVerts[tPoly->Indices[I]].z - pRoom->RoomVerts[tPoly->Indices[0]].z) * N.nz )

// Texture Coordinate Distance
#define TEXCOORDDIST(V,N) (((V).x - Ix) * (N).nx +		\
					       ((V).y - Iy) * (N).ny +		\
						   ((V).z - Iz) * (N).nz )

#define SQUARE(Num) ((Num) * (Num))


// Delete & Release
#define SafeRelease(x) {if (x) { x->Release(); x=NULL;}}
#define SafeDelete(x)  {if (x) { delete x;     x=NULL;}}


// Define for checking if a certain key is pressed or not
#define KEYDOWN(IKC) (g_InputDataBuffer[IKC] & 0x80)




//------ Error Return String ------//

char *g_ErrStr=NULL;	


//////////////////////////////////////
//			Data Structures			//
//////////////////////////////////////


struct VERTEX
{
	float x,y,z;	// Only Position
};

struct NORMAL
{
	float nx,ny,nz;
};

struct UNTRANSFORMED_VERTEX
{ 
	float x,y,z;	// Only Position
};

struct TRANSFORMED_VERTEX
{ float x,y,z;		// Position
  float rhw;		// RHW value
  DWORD color;		// Diffuse Color
  float tuB,tvB;	// Base Texture Coords
  float tuS,tvS;	// Shadow Map Coords
  float tuL,tvL;	// Light Map Coords
  float tuR,tvR;	// Reflection Coords
};

struct TEXCOORD
{
	float tu,tv;
};

struct POLYSTEXCOORD
{
	TEXCOORD *ptexcoord;
};

struct WATER
{
	float	y;
	float	R,G,B;
	WORD	NumBoundingPolys;
	WORD	*BoundingPolyInds;
};

struct COMPONENT
{ // The Component's Indices
  WORD	NumPolyIndices;
  WORD	*PolyIndices;

  WORD	*Triind;			// Used while drawing the components, to
  WORD	*TriVertInds;		// find out which triangles are to be drawn.
  WORD	*eTriVertInds;

  
  BOOLEAN HasAlpha;			// If the component's tex has alpha or not
  BOOLEAN IsGlass;			// If the component's tex is glass  or not
  BOOLEAN IsReflective;		// If the component's tex is reflective or not
  DWORD   ReflectiveBrightness; // If the component's tex is reflective, then
								// ReflectionBrightness contains the color of
								// reflection of the component
  BOOLEAN Energy;			// If the component is ENERGY type
  BOOLEAN HitChecked;		// If hit checking must be done with polys of this component

  char    NumAniFrames;		// The no. of frames of animation
  char    CurrAniFrame;		// The current frame of animation(The texture table index)
  float   AniTS,AniTDiff;	// The time intervals for animation
							// If they are equal, then the animation
							// isn't random, otherwise the animation
							// interval is a random value between
							// these two time intervals
  float   CurrentAniTime;	// The time elapsed since the last animation
  float   NextAniTime;		// The time when the next animation will take place


  // The Component's Texture index 
  // in the texture table
  WORD	TexTableIndex;
  // The Component's Shadow Map
  LPDIRECTDRAWSURFACE7 ShadowMapTexture;
};

struct POLYGON
{ WORD		NumVertices;
  WORD		*DIndices;			// The drawing indices
  WORD		*Indices;			// The hit-checking indices
  NORMAL	*Normals;			// The side normals
  float		nx,ny,nz;			// The poly's face normal
  NORMAL	LightMapNormal2;	// The normal perpendicular to 
								// the normal of the first side
								// of the polygon
  BOOLEAN	ColorChanged;
  COMPONENT	*ParentComponent;
  POLYGON	*front,*back;
};

struct LIGHT
{
	float x,y,z;				// Starting point			(Point,	Spot)
	float x2,y2,z2;				// Ending point				(		Spot)
	float nx,ny,nz;				// Reverse Normalized dir	(		Spot)
	float Radius;				// Radius					(Point,	Spot)
	float Brightness;			// Brightness				(Point,	Spot)
	float R,G,B;				// Color					(Point,	Spot)
	float Brightness_by_Radius;	// Used for Calc			(Point		)
	float one_by_2Radius;		// Used for Calc			(Point,	Spot)

	LIGHT *next,*previous;
};

struct TLIGHT
{
	float x,y,z;
	float x2,y2,z2;
	float Radius;
	float Brightness;
	float R,G,B;
};

struct NONAMBLIGHT
{
	float x,y,z;
	float x2,y2,z2;
	float Radius;
	float Brightness;
	float R,G,B;

	float nx,ny,nz;

	NONAMBLIGHT *next;
};

struct TRANSPARENT_COMP_DRAWING_LIST_NODE
{
	COMPONENT *pTComp;
	WORD	  *pStartInd;
	WORD	  *pEndInd;
};

struct ROOM
{
  // The Room's Components
  WORD		NumComponents;
  COMPONENT	*Components;
  
  COMPONENT **SCompDrawingList;	// Gives the order for drawing the Solid components
  COMPONENT **eSCompDrawingList;// The end ptr of the above list
  TRANSPARENT_COMP_DRAWING_LIST_NODE  *TCompDrawingList; // Gives the order for drawing the Transparent Components
  TRANSPARENT_COMP_DRAWING_LIST_NODE  *eTCompDrawingList;// The end ptr of the above list


  // The Room's Vertex Index Buffer(used for Drawing Lightmaps
  // since I'm using my own Back-Face Culling
  WORD		 *RoomVertInds;
  
  // The Room's Polys
  WORD		NumBSPPolys;
  POLYGON	*BSPPolyHead;

  // Stacks used for hit checking
  POLYGON	**StackP;
  float		*StackOB,*StackNC;

  // The Room's Vertices
  WORD		NumVerts;
  VERTEX	*RoomVerts;

    // The Room's Waters
  WORD		NumWaters;
  WATER		*RoomWaters;


  // The Room's Connected,Viewable Rooms
  WORD		NumConnectedRooms;
  WORD		*ConnectedRooms;
  WORD		NumViewableRooms;
  WORD		*ViewableRooms;

  // The Room's Extents
  float		Rx1,Ry1,Rz1,Rx2,Ry2,Rz2;
  

  // The Room's Vertex Buffers
  WORD						VBCapacity;
  LPDIRECT3DVERTEXBUFFER7	UntransformedRoomVB;
  LPDIRECT3DVERTEXBUFFER7	TransformedRoomVB;


  // The Room's Lights(Non-Ambient Lights)
  NONAMBLIGHT		*NonAmbLights;
};





//--------- Window Handle ------------//
HWND	g_ApphWnd;





// Physics Defines
#define		STANDMOVEVEL					750.0f
#define		CROUCHMOVEVEL					250.0f
#define		MINDIST							 10.0f
#define		ONE_BY_MINDIST					(1.0f/MINDIST)
#define		LANDGRAVITY					    400.0f
#define		WATERGRAVITY					 10.0f
#define		STANDUPHEIGHT					 25.0f
#define		CROUCHHEIGHT					 16.0f
#define		STANDUPFORCE					 75.0f
#define		JUMPVEL							170.0f



//----- Rotation position and speed -----//

float g_rotAngle=0.0f;		// current angle of Y rotation
float g_rotVel=0.0f;		// current velocity of Y rotation
float g_lookupAngle=0.0f;	// current angle of X rotation
float g_lookupVel=0.0f;		// current velocity of X rotation
float g_leanAngle=0.0f;		// current angle of Z rotation(view blob)

float g_frontPtz,g_frontPtx;		// temp vars
float g_MoveVel=0.0f;				// the moving velocity
float g_StrafeVel=0.0f;				// the strafing velocity
float g_tGravity = 0.0f;			// the 't' in gravity acceleration
float g_ManHeight=STANDUPHEIGHT;	// the man's current height
float g_StandUpForce;				// the force to stand up with


// Zoom value
float g_ZoomValue = 1.57f;

//----- Position, speed, etc. --------//
D3DVECTOR g_ViewDir	 = D3DVECTOR(0.0f,0.0f,0.0f);
D3DVECTOR g_ViewNorm = D3DVECTOR(0.0f,1.0f,0.0f);


// Positions
D3DVECTOR	g_O,g_N;
D3DVECTOR	g_Face,g_Feet;
D3DVECTOR   g_Force;


// Jump Vars
BOOL		g_bCanDoJump;
BOOL		g_bIsOnGround;


// Water Vars
BOOLEAN		g_bFaceIsUnderWater=FALSE;
BOOLEAN		g_bFeetIsUnderWater=FALSE;
BOOLEAN		g_bIsUnderWater=FALSE;
BOOLEAN		g_bSetNonWaterColor=FALSE;
D3DCOLOR	g_UnderWaterColor;
float		g_UnderWaterDistortion=0.75f;
float		g_UnderWaterDistortionInc=0.025f;



// Others
BOOLEAN		g_walkleanDir=0;	// the tilting dir while walking




// Matrices
D3DMATRIX	g_ProjMatrix;				// Projection matrix.
D3DMATRIX	g_WorldMatrix;
D3DMATRIX	g_RotationMatrix;
D3DMATRIX	g_BillboardMatrix;

/////////////////////////////////////////////////////////////////

// A Billboard
D3DLVERTEX	g_BillboardVerts[4];

// Crosshair Verts
D3DTLVERTEX	g_CrossHairVerts[4];

// The Skybox Verts
D3DLVERTEX	g_SkyBoxTopVerts[4];
D3DLVERTEX	g_SkyBoxBottomVerts[4];
D3DLVERTEX	g_SkyBoxLeftVerts[4];
D3DLVERTEX	g_SkyBoxRightVerts[4];
D3DLVERTEX	g_SkyBoxFrontVerts[4];
D3DLVERTEX	g_SkyBoxBackVerts[4];



// Others
float FrameRate=0.0f;
float Time_To_Update_FrameRate=0.0f;
LIGHT *UserSpotLight,*UserPointLight;



// Dummy Vars (used to ouput var values while debugging)
float fDummyOutputVar1 = 0.0f;
float fDummyOutputVar2 = 0.0f;
float fDummyOutputVar3 = 0.0f;

