// CComb.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#define POLY_AMBIENT_LIGHT	0.0f


#define MAX_BUFFER_SIZE 1000

#define NUM_FILTER_PASSES 1


#define CLAMP_COLOR(Col) {	if(Col.R < 0.0f)					\
								Col.R = 0.0f;					\
							else if(Col.R > 1.0f)				\
								Col.R = 1.0f;					\
																\
							if(Col.G < 0.0f)					\
								Col.G = 0.0f;					\
							else if(Col.G > 1.0f)				\
								Col.G = 1.0f;					\
																\
							if(Col.B < 0.0f)					\
								Col.B = 0.0f;					\
							else if(Col.B > 1.0f)				\
								Col.B = 1.0f;					\
						 }


#define PERPDIST(P,V,N) (((P).x - (V).x) * (N).nx +	\
						 ((P).y - (V).y) * (N).ny +	\
						 ((P).z - (V).z) * (N).nz )


#define ClearRGBArray(RGBArray,size) {	for(int i=0;i<size;i++)	\
										for(int j=0;j<size;j++)	\
										{						\
											RGBArray[i][j].R = 0.0f;\
											RGBArray[i][j].G = 0.0f;\
											RGBArray[i][j].B = 0.0f;\
										}						\
									 }				


#define AVERAGEALLROUND(A,x,y,C) ((A[y-1][x-1].C +			\
								   A[y-1][x  ].C +			\
								   A[y-1][x+1].C +			\
								   A[y  ][x-1].C +			\
								   A[y  ][x  ].C +			\
								   A[y  ][x  ].C +			\
								   A[y  ][x  ].C +			\
								   A[y  ][x  ].C +			\
								   A[y  ][x+1].C +			\
								   A[y+1][x-1].C +			\
								   A[y+1][x  ].C +			\
								   A[y+1][x+1].C) / 12.0f);

#define AVERAGETOPROUND(A,x,y,C) ((A[y  ][x-1].C +			\
								   A[y  ][x  ].C +			\
								   A[y  ][x+1].C +			\
								   A[y+1][x-1].C +			\
								   A[y+1][x  ].C +			\
								   A[y+1][x+1].C) / 6.0f);

#define AVERAGEBOTTOMROUND(A,x,y,C) ((A[y-1][x-1].C +			\
								      A[y-1][x  ].C +			\
								      A[y-1][x+1].C +			\
								      A[y  ][x-1].C +			\
								      A[y  ][x  ].C +			\
								      A[y  ][x+1].C) / 6.0f);

#define AVERAGELEFTROUND(A,x,y,C) ((A[y-1][x  ].C +			\
								    A[y-1][x+1].C +			\
								    A[y  ][x  ].C +			\
								    A[y  ][x+1].C +			\
								    A[y+1][x  ].C +			\
								    A[y+1][x+1].C) / 6.0f);

#define AVERAGERIGHTROUND(A,x,y,C) ((A[y-1][x-1].C +			\
								     A[y-1][x  ].C +			\
								     A[y  ][x-1].C +			\
								     A[y  ][x  ].C +			\
								     A[y+1][x-1].C +			\
								     A[y+1][x  ].C) / 6.0f);

#define AVERAGETOPLEFTROUND(A,x,y,C) ((A[y  ][x  ].C +			\
								       A[y  ][x+1].C +			\
								       A[y+1][x  ].C +			\
								       A[y+1][x+1].C) / 4.0f);

#define AVERAGETOPRIGHTROUND(A,x,y,C) ((A[y  ][x-1].C +			\
								        A[y  ][x  ].C +			\
								        A[y+1][x-1].C +			\
								        A[y+1][x  ].C) / 4.0f);

#define AVERAGEBOTTOMLEFTROUND(A,x,y,C) ((A[y-1][x  ].C +			\
								          A[y-1][x+1].C +			\
								          A[y  ][x  ].C +			\
								          A[y  ][x+1].C) / 4.0f);

#define AVERAGEBOTTOMRIGHTROUND(A,x,y,C) ((A[y-1][x-1].C +			\
								           A[y-1][x  ].C +			\
								           A[y  ][x-1].C +			\
								           A[y  ][x  ].C) / 4.0f);

#define SQUARE(Num) ((Num)*(Num))



//	Some Structures

struct COLOR
{
	float R,G,B;
};

struct VERTEX
{
	float x,y,z;
};

struct NORMAL
{
	float nx,ny,nz;
};

struct POLYGON
{
	float  nx,ny,nz;
	NORMAL *Normals;
	NORMAL LightMapNormal2;
		
	unsigned short	numind;
	unsigned short	*inds;

	unsigned short  TextureIndex;

	char HasAlpha,IsGlass;

	VERTEX	minBound,maxBound;
};

struct COMPONENT
{
	unsigned short	numpolyinds;
	unsigned short	*polyinds;
	char			IsEnergy;
};

struct ROOM
{
	unsigned short	numcomponents;
	COMPONENT		components[50];
};

struct LIGHT
{
	float x1,y1,z1;
	float x2,y2,z2;
	float Radius1;
	float Radius2;
	float Brightness;
	float R,G,B;
	char  ambLight;
	float LightLength;
	float Brightness_by_Radius;
};

int				numverts=0;		// The no. of vertices of all rooms
VERTEX			verts[500000];	// The vertices of all rooms

int				numpolys=0;		// The no. of polys of all rooms
POLYGON			polys[500000];	// The polys of all rooms

int				numlights=0;	// The no. of lights of all rooms
LIGHT			lights[500000];	// The lights of all rooms

int				numrooms;		// The number of rooms in this cluster
ROOM			rooms[500];		// The rooms



// Other vars
char			Command[500];
char			WorkingPath[100];
unsigned short	NumLightCheckInds;
unsigned short	LightCheckInds[10000];

// Functions
//------------------------------------------
int CalcPolyShadowData();


int CalcPolyBoundingBox(POLYGON	*tpoly)
{
	int i;

	tpoly->minBound = tpoly->maxBound = verts[tpoly->inds[0]];
	for(i=1;i<tpoly->numind;i++)
	{
		if(verts[tpoly->inds[i]].x < tpoly->minBound.x)
			tpoly->minBound.x = verts[tpoly->inds[i]].x;
		if(verts[tpoly->inds[i]].y < tpoly->minBound.y)
			tpoly->minBound.y = verts[tpoly->inds[i]].y;
		if(verts[tpoly->inds[i]].z < tpoly->minBound.z)
			tpoly->minBound.z = verts[tpoly->inds[i]].z;

		if(verts[tpoly->inds[i]].x > tpoly->maxBound.x)
			tpoly->maxBound.x = verts[tpoly->inds[i]].x;
		if(verts[tpoly->inds[i]].y > tpoly->maxBound.y)
			tpoly->maxBound.y = verts[tpoly->inds[i]].y;
		if(verts[tpoly->inds[i]].z > tpoly->maxBound.z)
			tpoly->maxBound.z = verts[tpoly->inds[i]].z;
	}

	return 1;
}

// Calculate a poly's normal
int CalcPolyNormal(POLYGON *tpoly)
{
	float tx1,ty1,tz1,tx2,ty2,tz2,Denom;

	tx1 = verts[tpoly->inds[0]].x - verts[tpoly->inds[1]].x;
	ty1 = verts[tpoly->inds[0]].y - verts[tpoly->inds[1]].y;
	tz1 = verts[tpoly->inds[0]].z - verts[tpoly->inds[1]].z;

	tx2 = verts[tpoly->inds[2]].x - verts[tpoly->inds[1]].x;
	ty2 = verts[tpoly->inds[2]].y - verts[tpoly->inds[1]].y;
	tz2 = verts[tpoly->inds[2]].z - verts[tpoly->inds[1]].z;

	
	tpoly->nx = ty2 * tz1 - ty1 * tz2;
	tpoly->ny = tx1 * tz2 - tx2 * tz1;
	tpoly->nz = tx2 * ty1 - tx1 * ty2;

	Denom = sqrtf(tpoly->nx * tpoly->nx + tpoly->ny * tpoly->ny + tpoly->nz * tpoly->nz);

	if(Denom == 0.0f)
		return 0;

	tpoly->nx /= Denom;
	tpoly->ny /= Denom;
	tpoly->nz /= Denom;

	return 1;
}


// Calculate a Poly's Side Normals
int CalcPolySideNormal(POLYGON *tpoly)
{
	float tx1,ty1,tz1,tx2,ty2,tz2,Denom;

	for(int i=1;i<tpoly->numind;i++)
	{
		tx1 = verts[tpoly->inds[i]].x - verts[tpoly->inds[i-1]].x;
		ty1 = verts[tpoly->inds[i]].y - verts[tpoly->inds[i-1]].y;
		tz1 = verts[tpoly->inds[i]].z - verts[tpoly->inds[i-1]].z;

		tx2 = -10.0f * tpoly->nx;
		ty2 = -10.0f * tpoly->ny;
		tz2 = -10.0f * tpoly->nz;

		tpoly->Normals[i-1].nx = ty2 * tz1 - ty1 * tz2;
		tpoly->Normals[i-1].ny = tx1 * tz2 - tx2 * tz1;
		tpoly->Normals[i-1].nz = tx2 * ty1 - tx1 * ty2;

		Denom = sqrtf(tpoly->Normals[i-1].nx * tpoly->Normals[i-1].nx 
					+ tpoly->Normals[i-1].ny * tpoly->Normals[i-1].ny
					+ tpoly->Normals[i-1].nz * tpoly->Normals[i-1].nz);
		
		if(Denom == 0.0f)
			return 0;

		tpoly->Normals[i-1].nx /= Denom;
		tpoly->Normals[i-1].ny /= Denom;
		tpoly->Normals[i-1].nz /= Denom;
	}


	tx1 = verts[tpoly->inds[0]].x - verts[tpoly->inds[i-1]].x;
	ty1 = verts[tpoly->inds[0]].y - verts[tpoly->inds[i-1]].y;
	tz1 = verts[tpoly->inds[0]].z - verts[tpoly->inds[i-1]].z;

	tx2 = -10.0f * tpoly->nx;
	ty2 = -10.0f * tpoly->ny;
	tz2 = -10.0f * tpoly->nz;

	tpoly->Normals[i-1].nx = ty2 * tz1 - ty1 * tz2;
	tpoly->Normals[i-1].ny = tx1 * tz2 - tx2 * tz1;
	tpoly->Normals[i-1].nz = tx2 * ty1 - tx1 * ty2;

	Denom = sqrtf(tpoly->Normals[i-1].nx * tpoly->Normals[i-1].nx 
				+ tpoly->Normals[i-1].ny * tpoly->Normals[i-1].ny
				+ tpoly->Normals[i-1].nz * tpoly->Normals[i-1].nz);
		
	if(Denom == 0.0f)
		return 0;

	tpoly->Normals[i-1].nx /= Denom;
	tpoly->Normals[i-1].ny /= Denom;
	tpoly->Normals[i-1].nz /= Denom;
	
	return 1;
}


// Calculate a Poly's LightMap 2nd Normal
int CalcPolyLightMapNormal2(POLYGON *tpoly)
{
	float Denom;

	tpoly->LightMapNormal2.nx = verts[tpoly->inds[1]].x - verts[tpoly->inds[0]].x;
	tpoly->LightMapNormal2.ny = verts[tpoly->inds[1]].y - verts[tpoly->inds[0]].y;
	tpoly->LightMapNormal2.nz = verts[tpoly->inds[1]].z - verts[tpoly->inds[0]].z;

	Denom = sqrtf(tpoly->LightMapNormal2.nx * tpoly->LightMapNormal2.nx 
				+ tpoly->LightMapNormal2.ny * tpoly->LightMapNormal2.ny
				+ tpoly->LightMapNormal2.nz * tpoly->LightMapNormal2.nz);

	if(Denom == 0.0f)
		return 0;

	tpoly->LightMapNormal2.nx /= Denom;
	tpoly->LightMapNormal2.ny /= Denom;
	tpoly->LightMapNormal2.nz /= Denom;

	return 1;
}




// Get a Poly's Attributes
inline void GetPolyData(POLYGON *tPoly, VERTEX *TopLeftVert,
				 float *PolyWidth, float *PolyHeight)
{
	float Dist,MaxHDist,MinHDist,MaxVDist;

	MaxHDist = MinHDist = MaxVDist = 0.0f;

	for(int i=1;i<tPoly->numind;i++)
	{
		Dist = PERPDIST(verts[tPoly->inds[i]],verts[tPoly->inds[0]],tPoly->LightMapNormal2);
		if(Dist > MaxHDist) MaxHDist = Dist;
		if(Dist < MinHDist) MinHDist = Dist;

		Dist = -PERPDIST(verts[tPoly->inds[i]],verts[tPoly->inds[0]],tPoly->Normals[0]);
		if(Dist > MaxVDist) MaxVDist = Dist;
	}

	TopLeftVert->x = verts[tPoly->inds[0]].x + tPoly->LightMapNormal2.nx * MinHDist;
	TopLeftVert->y = verts[tPoly->inds[0]].y + tPoly->LightMapNormal2.ny * MinHDist;
	TopLeftVert->z = verts[tPoly->inds[0]].z + tPoly->LightMapNormal2.nz * MinHDist;

	*PolyWidth = MaxHDist - MinHDist;
	*PolyHeight= MaxVDist;
}


inline void SetPolyLightCheckInds(POLYGON *tPoly)
{
	VERTEX	O,N;
	float Dist;
	
	NumLightCheckInds=0;
	for(int li=0;li<numlights;li++)
	{
		// The vector from the light's source to us(the point)
		O.x = lights[li].x1; O.y = lights[li].y1; O.z = lights[li].z1;
		N.x = lights[li].x2; N.y = lights[li].y2; N.z = lights[li].z2;

		// Get the perpendicular dist from the light's
		// starting point to us
		Dist = PERPDIST(O,verts[tPoly->inds[0]],(*tPoly));

		// If the light is behind us, then we're done,
		// unless we're Glass
		if(Dist < 0.0f && !(tPoly->IsGlass))
			continue;


		if(N.x || N.y || N.z)
		{
			// Spot Light

			// For Spot Lights, there is no simple
			// non-calculation intensive method to
			// find out if the spot light can
			// partially/fully fall on a polygon.
			// So, we'll just have to pass all Spot
			// Lights to be checked against this poly.
		}
		else
		{
			// Point Light

			// If the perpendicular dist of the point light's
			// starting point to the poly is greater than
			// it's radius, then we're done
			if(Dist > lights[li].Radius2)
				continue;
		}

		// This light may now fall on the polygon
		LightCheckInds[NumLightCheckInds++] = li;
	}
}



// Calculate the value of the light at a point
inline void CalcPointLightData(int PolyInd,VERTEX Pt,COLOR *pColor)
{
	VERTEX Vec,A,O,N;
	float Dist,Decay,OB,NC,one_by_denom,dum;
	COLOR Col,LightCol;
	int i,li,Intersection;
	float LambertConst;


	// See if the Point is in the Poly's Boundary
	// If not, then force it to be so.
	for(i=0;i<polys[PolyInd].numind;i++)
	{
		Dist = PERPDIST(Pt,verts[polys[PolyInd].inds[i]],polys[PolyInd].Normals[i]);

		if(Dist > 0.0f)
		{
			Pt.x -= Dist*polys[PolyInd].Normals[i].nx;
			Pt.y -= Dist*polys[PolyInd].Normals[i].ny;
			Pt.z -= Dist*polys[PolyInd].Normals[i].nz;
		}
	}
	
	// Set the ambient light
	Col.R = Col.G = Col.B = POLY_AMBIENT_LIGHT;


	for(i=0;i<NumLightCheckInds;i++)
	{
		li = LightCheckInds[i];

		// Initialize a value
		Intersection = 0;
	
		// The vector from the light's source to us(the point)
		O.x = lights[li].x1; O.y = lights[li].y1; O.z = lights[li].z1;
		N.x = Pt.x;			 N.y = Pt.y;		  N.z = Pt.z;

		// If the light is behind us, then we're done,
		// unless we're Glass
		if(PERPDIST(O,verts[polys[PolyInd].inds[0]],polys[PolyInd]) < 0.0f &&
								!polys[PolyInd].IsGlass)
			continue;


		if(lights[li].x2 || lights[li].y2 || lights[li].z2)
		{
			// Spot Light

			float CosA,lCosA1,lCosA2;
			float a1,b1,c1,a2,b2,c2;
			float hyp;

			// Calc Light length
			a2 = lights[li].x2 - lights[li].x1;
			b2 = lights[li].y2 - lights[li].y1;
			c2 = lights[li].z2 - lights[li].z1;
			
			// Calc Dist from us to the light
			a1 = Pt.x - lights[li].x1;
			b1 = Pt.y - lights[li].y1;
			c1 = Pt.z - lights[li].z1;
			Dist = sqrtf(a1*a1 + b1*b1 + c1*c1);

			// If we are farther than the light's reach
			// then we're done
			if(Dist > lights[li].LightLength)
				continue;

			// Calc the cosines of the spot light's angles
			hyp = sqrtf(lights[li].Radius1*lights[li].Radius1 + lights[li].LightLength*lights[li].LightLength);
			lCosA1 = lights[li].LightLength / hyp;
			hyp = sqrtf(lights[li].Radius2*lights[li].Radius2 + lights[li].LightLength*lights[li].LightLength);
			lCosA2 = lights[li].LightLength / hyp;


			// Normalize the vectors
			dum = 1.0f / Dist;					 a1*=dum; b1*=dum; c1*=dum;
			dum = 1.0f / lights[li].LightLength; a2*=dum; b2*=dum; c2*=dum;

			// Calculate the cosine of the angle between us
			// and the light's vector
			CosA = a1*a2 + b1*b2 + c1*c2;

			// See if we are out of the spot light's Radius
			// If we are, then we're done
			if(CosA < lCosA2)
				continue;


			// Calc Lambert's Const
			if(	lights[li].ambLight == 1 ||
				lights[li].ambLight == 3 )
			{
				LambertConst = -a1*polys[PolyInd].nx - b1*polys[PolyInd].ny - c1*polys[PolyInd].nz;
			}


			// Decay the spotlight's light

			// Take into account the distance from
			// the spot light's source-point.
			Decay = (1.0f - Dist/lights[li].LightLength) * lights[li].Brightness;
			// Take into account the spotlight's fall-off
			if(CosA < lCosA1)
				Decay *= (CosA - lCosA2)/(lCosA1 - lCosA2);

		}
		else
		{
			// Point Light

			Vec.x = Pt.x - lights[li].x1;
			Vec.y = Pt.y - lights[li].y1;
			Vec.z = Pt.z - lights[li].z1;

			Dist = sqrtf(Vec.x * Vec.x + Vec.y * Vec.y + Vec.z * Vec.z);

			if(Dist > lights[li].Radius2)
				continue;

			// Calc Lambert's Const
			if(	lights[li].ambLight == 1 ||
				lights[li].ambLight == 3 )
			{
				// Normalize the vector
				dum = 1.0f / Dist;
				Vec.x *= dum; Vec.y *= dum; Vec.z *= dum;

				LambertConst = -Vec.x*polys[PolyInd].nx - Vec.y*polys[PolyInd].ny - Vec.z*polys[PolyInd].nz;
			}

			// Take into account the distance from
			// the point light's source-point.
			if(Dist < lights[li].Radius1)
				Decay = lights[li].Brightness;
			else
				Decay = lights[li].Brightness - (Dist - lights[li].Radius1) * lights[li].Brightness_by_Radius;

		}


		if(	lights[li].ambLight == 1 ||
			lights[li].ambLight == 3 )
		{
			if(LambertConst < 0.0f)
				LambertConst = -LambertConst;

			LightCol.R = lights[li].R * Decay * LambertConst;
			LightCol.G = lights[li].G * Decay * LambertConst;
			LightCol.B = lights[li].B * Decay * LambertConst;
		}
		else
		{
			LightCol.R = lights[li].R * Decay;
			LightCol.G = lights[li].G * Decay;
			LightCol.B = lights[li].B * Decay;
		}


		for(int pi=0;pi<numpolys;pi++)
		{
			if(pi == PolyInd || polys[pi].HasAlpha)
				continue;

			if(O.x < polys[pi].minBound.x &&
				N.x < polys[pi].minBound.x )
				continue;
			else if(O.y < polys[pi].minBound.y &&
					N.y < polys[pi].minBound.y )
				continue;
			else if(O.z < polys[pi].minBound.z &&
					N.z < polys[pi].minBound.z )
				continue;
			else if(O.x > polys[pi].maxBound.x &&
					N.x > polys[pi].maxBound.x )
				continue;
			else if(O.y > polys[pi].maxBound.y &&
					N.y > polys[pi].maxBound.y )
				continue;
			else if(O.z > polys[pi].maxBound.z &&
					N.z > polys[pi].maxBound.z )
				continue;


			OB = PERPDIST(O,verts[polys[pi].inds[0]],polys[pi]);
			NC = PERPDIST(N,verts[polys[pi].inds[0]],polys[pi]);

			if((OB>0.0f && NC>0.0f) || (OB<0.0f && NC<0.0f) ||
			   (OB>0.0f && NC>-0.01f) || (NC>0.0f && OB>-0.01f)
			  )
				continue;
			
			one_by_denom = 1.0f / (OB-NC);

			A.x = (N.x * OB - O.x * NC) * one_by_denom;
			A.y = (N.y * OB - O.y * NC) * one_by_denom;
			A.z = (N.z * OB - O.z * NC) * one_by_denom;

			Intersection = 1;
			for(int i=0;i<polys[pi].numind;i++)
			{
				Dist = PERPDIST(A,verts[polys[pi].inds[i]],polys[pi].Normals[i]);

				if(Dist > 0.0f)
				{	Intersection = 0; break; }
			}

			if(Intersection) break;
		}

		if(!Intersection)
		{
			if(LightCol.R > Col.R)
				Col.R = LightCol.R;
			if(LightCol.G > Col.G)
				Col.G = LightCol.G;
			if(LightCol.B > Col.B)
				Col.B = LightCol.B;
			
//			Col.R = Col.R + LightCol.R - Col.R * LightCol.R;
//			Col.G = Col.G + LightCol.G - Col.G * LightCol.G;
//			Col.B = Col.B + LightCol.B - Col.B * LightCol.B;
		}

	} // End of this light, go to the next light


	// Clamp the color
	CLAMP_COLOR(Col);

	// Set the return color
	*pColor = Col;
}



// Program Entry
//--------------------------------------------------

int main(int argc, char* argv[])
{
	FILE			*inf,*outf,*tmpf;
	char			Buffer[MAX_BUFFER_SIZE];

	float			UserPosX,UserPosY,UserPosZ,ViewAngle;
	char			RoomName[100],dummyStr[100];
	float			Scale,transX,transY,transZ;
	unsigned short	NumConnectedRooms,ConnectedRooms[20];
	unsigned short	NumViewableRooms,ViewableRooms[20];


	if(argc < 3)
	{
		printf("Insufficient arguments\n");
		printf("Syntax : CComb <input-filename> <output-path>\n");
		getch();
		return 0;
	}

	strcpy(WorkingPath,argv[2]);

	// Open the Cluster file
	if((inf = fopen(argv[1],"r")) == (FILE *)NULL)
	{
		printf("Fatal Error : Unable to open inputfile %s\n",argv[1]);
		getch();
		return 0;
	}

	// Create the output file
	sprintf(Command,"%s\\Cdata.bin",WorkingPath);
	if((outf = fopen(Command,"wb")) == (FILE *)NULL)
	{
		printf("Fatal Error : Unable to open outputfile %s\n",Command);
		fclose(inf);
		getch();
		return 0;
	}


	// Read the user's initial position
	fscanf(inf,"%f,%f,%f,%f",&UserPosX,&UserPosY,&UserPosZ,&ViewAngle);
	fwrite(&UserPosX,sizeof(float),1,outf);
	fwrite(&UserPosY,sizeof(float),1,outf);
	fwrite(&UserPosZ,sizeof(float),1,outf);
	ViewAngle = 3.14159f * ViewAngle / 180.0f;
	fwrite(&ViewAngle,sizeof(float),1,outf);


	// Read the no. of Rooms
	fscanf(inf,"%u",&numrooms);
	fwrite(&numrooms,sizeof(unsigned short),1,outf);

	
	printf("\n");

	// Clear the Temp directory
	sprintf(Command,"if exist %s\\Temp\\*.bin del %s\\Temp\\*.bin",WorkingPath,WorkingPath);
	system(Command);
	sprintf(Command,"if exist %s\\Temp\\*.txt del %s\\Temp\\*.txt",WorkingPath,WorkingPath);
	system(Command);
	sprintf(Command,"if exist %s\\Temp\\*.bmp del %s\\Temp\\*.bmp",WorkingPath,WorkingPath);
	system(Command);
	sprintf(Command,"if exist %s\\Temp\\*.dds del %s\\Temp\\*.dds",WorkingPath,WorkingPath);
	system(Command);



	printf("Cluster file creation initiated\n");
	printf("-------------------------------\n\n");


	// Go through the rooms
	int i,j;
	float cx,cy,cz;
	for(i=0;i<numrooms;i++)
	{

		// Read the Room Properties
		///////////////////////////////////////////////////////
		printf("Reading Room%d Properties... ",i);
		
		// Read Room Properties
		fscanf(inf,"%s",RoomName);
		fscanf(inf,"%f,%f,%f,%f",&Scale,&transX,&transY,&transZ);
		fscanf(inf,"%u",&NumConnectedRooms);
		for(j=0;j<NumConnectedRooms;j++)
		 fscanf(inf,"%u",&ConnectedRooms[j]);
		fscanf(inf,"%u",&NumViewableRooms);
		for(j=0;j<NumViewableRooms;j++)
		 fscanf(inf,"%u",&ViewableRooms[j]);

		printf("Complete\n");
		///////////////////////////////////////////////////////
		
		// Read the Room Data
		///////////////////////////////////////////////////////
		printf("Reading Room%d Data... ",i);

		FILE *infile;
		int  numvertse,numpolyse,numlightse;
		
		// Read Room Data
		if((infile = fopen(RoomName,"r")) == (FILE *)NULL)
		{
			printf("Fatal Error : Cannot open input-file\n");
			getch();
			return 0;
		}

		// Read the vertex data
		fscanf(infile,"%u",&numvertse);

		cx=cy=cz=0.0f;
		float dumf1;
		for(int j=numverts;j<numverts+numvertse;j++)
		{
			fscanf(infile,"%f,%f,%f",&verts[j].x, &verts[j].y, &verts[j].z);
			fscanf(infile,"%f,%f",&dumf1, &dumf1);

			// Add up to find the mid-pt of all the verts
			cx += verts[j].x;
			cy += verts[j].y;
			cz += verts[j].z;
		}

		cx /= (float)numvertse;
		cy /= (float)numvertse;
		cz /= (float)numvertse;

		// Based on the final position for first vertex,
		// find the translation values for the remaining
		// vertices
		float tX = transX - ((verts[numverts].x - cx) * Scale);
		float tY = transY - ((verts[numverts].y - cy) * Scale);
		float tZ = transZ - ((verts[numverts].z - cz) * Scale);
		
		// Centerize,scale & translate all the vertices
		for(j=numverts;j<numverts+numvertse;j++)
		{
			verts[j].x = (verts[j].x - cx) * Scale + tX;
			verts[j].y = (verts[j].y - cy) * Scale + tY;
			verts[j].z = (verts[j].z - cz) * Scale + tZ;
		}


		// Read the polygon data
		fscanf(infile,"%u",&numpolyse);
		unsigned int dummyui;
		for(j=numpolys;j<numpolys+numpolyse;j++)
		{
			fscanf(infile,"%u",&(polys[j].numind));
			polys[j].inds    = new unsigned short[polys[j].numind];
			polys[j].Normals = new NORMAL[polys[j].numind];
			for(int k=0;k<polys[j].numind;k++)
			{
				fscanf(infile,"%u",&dummyui);
				polys[j].inds[k] = dummyui;
				polys[j].inds[k] += numverts;
			}

			fscanf(infile,"%u",&polys[j].TextureIndex);
			polys[j].TextureIndex--;
		}
		numverts += numvertse;


		fscanf(infile,"%u\n",&(rooms[i].numcomponents));
		unsigned int   dummy1,dummy2,dummy4,dummy7,dummy8;
		float dummy3,dummy5,dummy6;
		for(j=0;j<rooms[i].numcomponents;j++)
		{
			rooms[i].components[j].numpolyinds = 0;

			dummy1 = fgetc(infile);
			fgets(dummyStr,100,infile);

			fscanf(infile,"%u,%u,%f,%u,%f,%f,%u,%u\n",
							&dummy1,&dummy2,&dummy3,&dummy4,
							&dummy5,&dummy6,&dummy7,&dummy8);

			for(int k=numpolys;k<numpolys+numpolyse;k++)
			 if(polys[k].TextureIndex == j)
			 {
				 polys[k].HasAlpha = (dummy1 || dummy7)?1:0;
				 polys[k].IsGlass  = (dummy2)?1:0;

				 rooms[i].components[j].numpolyinds++;
			 }
			rooms[i].components[j].IsEnergy	= dummy7;

			rooms[i].components[j].polyinds = new unsigned short[rooms[i].components[j].numpolyinds];
			dummy1=0;
			for(k=numpolys;k<numpolys+numpolyse;k++)
			 if(polys[k].TextureIndex == j)
			  rooms[i].components[j].polyinds[dummy1++] = k;
		}
		numpolys += numpolyse;

		
		fscanf(infile,"%u",&numlightse);
		for(j=numlights;j<numlights+numlightse;j++)
		{
			fscanf(infile,"%f,%f,%f",&lights[j].x1, &lights[j].y1, &lights[j].z1);
			fscanf(infile,"%f,%f,%f",&lights[j].x2, &lights[j].y2, &lights[j].z2);
			fscanf(infile,"%f",&lights[j].Radius1);
			fscanf(infile,"%f",&lights[j].Radius2);
			fscanf(infile,"%f",&lights[j].Brightness);
			fscanf(infile,"%f,%f,%f",&lights[j].R, &lights[j].G, &lights[j].B);
			fscanf(infile,"%u",&dummyui);
			lights[j].ambLight = dummyui;

			// Centerize,scale & translate the light
			lights[j].x1 = (lights[j].x1 - cx) * Scale + tX;
			lights[j].y1 = (lights[j].y1 - cy) * Scale + tY;
			lights[j].z1 = (lights[j].z1 - cz) * Scale + tZ;
			if(lights[j].x2 || lights[j].y2 || lights[j].z2)
			{
				lights[j].x2 = (lights[j].x2 - cx) * Scale + tX;
				lights[j].y2 = (lights[j].y2 - cy) * Scale + tY;
				lights[j].z2 = (lights[j].z2 - cz) * Scale + tZ;

				float a,b,c;
				a = lights[j].x2 - lights[j].x1;
				b = lights[j].y2 - lights[j].y1;
				c = lights[j].z2 - lights[j].z1;
				lights[j].LightLength = sqrtf(a*a + b*b + c*c);
			}
			lights[j].Radius1 *= Scale;
			lights[j].Radius2 *= Scale;

			if((lights[j].Radius2 - lights[j].Radius1) > 0.0f)
				lights[j].Brightness_by_Radius = lights[j].Brightness / (lights[j].Radius2 - lights[j].Radius1);
			else
				lights[j].Brightness_by_Radius = 0.0f;
		}
		numlights += numlightse;

		fclose(infile);
		printf("Complete\n");
		///////////////////////////////////////////////////////
		

		// Build the Room's BSP Tree
		///////////////////////////////////////////////////////
		sprintf(Command,"%s\\CBsp2 %s %s %d %f %f %f %f",
				WorkingPath,RoomName,WorkingPath,i,Scale,transX,transY,transZ);

		// Build the BSP Tree
		system(Command);
		///////////////////////////////////////////////////////
				
		
		// Write the Room Data to the Cluster File
		///////////////////////////////////////////////////////
		printf("Updating Cluster file... ");


		// Write the Room's Connected Rooms Indices
		fwrite(&NumConnectedRooms,sizeof(unsigned short),1,outf);
		for(j=0;j<NumConnectedRooms;j++)
		 fwrite(&ConnectedRooms[j],sizeof(unsigned short),1,outf);

		// Write the Room's Viewable Rooms Indices
		fwrite(&NumViewableRooms,sizeof(unsigned short),1,outf);
		for(j=0;j<NumViewableRooms;j++)
		 fwrite(&ViewableRooms[j],sizeof(unsigned short),1,outf);


		// Open the BSP Tree file
		sprintf(Command,"%s\\Temp\\Room%d.bin",WorkingPath,i);
		if((tmpf = fopen(Command,"rb")) == (FILE *)NULL)
		{
			printf("Error : Unable to open BSP-Tree file\n");
			printf("Cluster Compilation Terminated\n");
			getch();
			fclose(inf);
			fclose(outf);
			return 0;
		}

		// Just Copy the Contents of this BSP Tree file to the
		// Cluster file 'MAX_BUFFER_SIZE' bytes at a time.
		int NumBytesRead;
		for(;;)
		{
			NumBytesRead = fread(Buffer,sizeof(char),MAX_BUFFER_SIZE,tmpf);
			fwrite(Buffer,sizeof(char),NumBytesRead,outf);
			
			if(NumBytesRead < MAX_BUFFER_SIZE)
				break;
		}
		
		fclose(tmpf);
		printf("Complete\n");
		///////////////////////////////////////////////////////
		
		printf("\n");
	}


	printf("\nWriting texture file names... ");

	// Write the Texture filenames from the texture table
	// to the output file.

	sprintf(Command,"%s\\Temp\\TexTable.txt",WorkingPath);
	if((tmpf = fopen(Command,"r")) == (FILE *)NULL)
	{
		printf("Error : Unable to open Texture Table\n");
		printf("Cluster Compilation Terminated\n");
		getch();
		fclose(inf);
		fclose(outf);
		return 0;
	}

	unsigned short	NumTextures;
	unsigned short	ushortvar;
	char			TexFileName[100];

	fscanf(tmpf,"%u\n",&NumTextures);
	fwrite(&NumTextures,sizeof(unsigned short),1,outf);
	for(i=0;i<NumTextures;i++)
	{
		fscanf(tmpf,"%s\n",TexFileName);
		ushortvar = strlen(TexFileName);
		fwrite(&ushortvar,sizeof(unsigned short),1,outf);
		fwrite(TexFileName,sizeof(char),ushortvar,outf);
	}
	fclose(tmpf);

	printf("Complete\n");


	// Close the files
	fclose(inf);
	fclose(outf);

	
	// Calculate the polygon shadows
	if(!CalcPolyShadowData())
	{
		printf("Cluster Compilation Terminated\n");
		getch();
		return 0;
	}
	
	// Free the allocated memory of the poly's inds & normals
	for(i=0;i<numpolys;i++)
	{
		delete(polys[i].inds);
		delete(polys[i].Normals);
	}


	// We did it!!
	printf("\n\n");
	printf("----------------------------------------------------------------------\n");
	printf("                    Cluster Compilation Successful!\n");
	printf("----------------------------------------------------------------------\n");
	printf("\nPress any key to continue...");

	getch();
	return 1;
}



int CalcPolyShadowData()
{
	int		i,j;


	printf("\n\nShadow Calculation initiated\n");
	printf("-------------------------------\n\n");

	// Calculate necessary data
	printf("\nCalculating necessary data... ");

	// Calculate all poly's face normals
	for(i=0;i<numpolys;i++)
	{
		CalcPolyBoundingBox(&polys[i]);
		CalcPolyNormal(&(polys[i]));
		CalcPolySideNormal(&(polys[i]));
		CalcPolyLightMapNormal2(&(polys[i]));
	}

	printf("Done\n");

	printf("\n");


	// Some vars
	FILE *f; char fname[100];
	COLOR CSD[256][256];	// Component Shadow Data
	VERTEX TLVert;			// Top-Left Vertex of polygon
	float pw,ph,bpw,bph,dpw,dph;
	int   x,y,btx,bty;
	int	  psize;
	VERTEX Vert; COLOR Col;
	int pi;


	// Write some data for the shadow generator(The making of BMPs)
	sprintf(Command,"%s\\Temp\\BasicClusterInfo.txt",WorkingPath);
	f = fopen(Command,"w");
	// Write the no. of rooms
	fprintf(f,"%d\n",numrooms);
	// Write the no. of components for each room
	for(i=0;i<numrooms;i++)
	{
		int NonEnergyComponentCount=0;
		// Count the no. of non-energy components
		for(j=0;j<rooms[i].numcomponents;j++)
			if(!rooms[i].components[j].IsEnergy)
				NonEnergyComponentCount++;

		// Write the no. of non-energy components
		fprintf(f,"%d\n",NonEnergyComponentCount);
		// Write the indices of the non-energy components
		for(j=0;j<rooms[i].numcomponents;j++)
		 if(!rooms[i].components[j].IsEnergy)
	 		fprintf(f,"%d\n",j);
	}
	//Close the file
	fclose(f);


	
	// ----------- Let the Shadow Calculation Begin !! ----------//

	// Go through the rooms
	for(i=0;i<numrooms;i++)
	{
		printf("Calculating Room%d Shadows ",i);

		for(j=0;j<rooms[i].numcomponents;j++)
			if(!rooms[i].components[j].IsEnergy)
				printf("%c",176);
		for(j=0;j<rooms[i].numcomponents;j++)
			if(!rooms[i].components[j].IsEnergy)
				printf("\b");

		// Go through the rooms components
		for(j=0;j<rooms[i].numcomponents;j++)
		if(!rooms[i].components[j].IsEnergy)
		{
			ClearRGBArray(CSD,256);

			if(rooms[i].components[j].numpolyinds == 1)
				psize = 256;
			else if(rooms[i].components[j].numpolyinds <= SQUARE(2))
				psize = 128;
			else if(rooms[i].components[j].numpolyinds <= SQUARE(4))
				psize = 64;
			else if(rooms[i].components[j].numpolyinds <= SQUARE(8))
				psize = 32;
			else if(rooms[i].components[j].numpolyinds <= SQUARE(16))
				psize = 16;
			else if(rooms[i].components[j].numpolyinds <= SQUARE(32))
				psize = 8;
			else if(rooms[i].components[j].numpolyinds <= SQUARE(64))
				psize = 4;
			else if(rooms[i].components[j].numpolyinds <= SQUARE(128))
				psize = 2;
			else
				psize = 1;


			btx = bty = 0;

			for(int k=0;k<rooms[i].components[j].numpolyinds;k++)
			{
				pi = rooms[i].components[j].polyinds[k];

				GetPolyData(&(polys[pi]),&TLVert,&pw,&ph);
				SetPolyLightCheckInds(&(polys[pi]));

				dpw = pw/psize;   dph = ph/psize;
				bpw = dpw * 0.5f; bph = dph * 0.5f;

				for(y=0;y<psize;y++)
				{
					for(x=0;x<psize;x++)
					{
						

			Vert.x = TLVert.x + polys[pi].LightMapNormal2.nx * bpw;
			Vert.y = TLVert.y + polys[pi].LightMapNormal2.ny * bpw;
			Vert.z = TLVert.z + polys[pi].LightMapNormal2.nz * bpw;

			Vert.x -= polys[pi].Normals[0].nx * bph;
			Vert.y -= polys[pi].Normals[0].ny * bph;
			Vert.z -= polys[pi].Normals[0].nz * bph;

						CalcPointLightData(pi,Vert,&Col);

						CSD[bty + y][btx + x] = Col;

						bpw += dpw;
					}

					bph += dph;
					bpw = dpw * 0.5f;
				}

				btx += psize;
				if(btx == 256.0f) { bty += psize; btx = 0; }
			}



			// Do some filtering

			int a,b,p=256/psize;
			COLOR tmpArr[256][256];

			// Repeat the filtering NUM_FILTER_PASSES times
			for(int fi=0;fi<NUM_FILTER_PASSES;fi++)
			{
				for(a=0;a<p;a++)
				for(b=0;b<p;b++)
				{
					// Copy a single poly's shadow tex
					for(y=0;y<psize;y++)
					for(x=0;x<psize;x++)
						tmpArr[y][x] = CSD[a*psize + y][b*psize + x];

					
					// Average All round
					for(y=1;y<psize-1;y++)
					for(x=1;x<psize-1;x++)
					{
						CSD[a*psize + y][b*psize + x].R = AVERAGEALLROUND(tmpArr,x,y,R);
						CSD[a*psize + y][b*psize + x].G = AVERAGEALLROUND(tmpArr,x,y,G);
						CSD[a*psize + y][b*psize + x].B = AVERAGEALLROUND(tmpArr,x,y,B);
					}

					for(x=1;x<psize-1;x++)
					{
						// Average top round
						CSD[a*psize][b*psize + x].R = AVERAGETOPROUND(tmpArr,x,0,R);
						CSD[a*psize][b*psize + x].G = AVERAGETOPROUND(tmpArr,x,0,G);
						CSD[a*psize][b*psize + x].B = AVERAGETOPROUND(tmpArr,x,0,B);

						// Average bottom round
						CSD[a*psize + psize-1][b*psize + x].R = AVERAGEBOTTOMROUND(tmpArr,x,psize-1,R);
						CSD[a*psize + psize-1][b*psize + x].G = AVERAGEBOTTOMROUND(tmpArr,x,psize-1,G);
						CSD[a*psize + psize-1][b*psize + x].B = AVERAGEBOTTOMROUND(tmpArr,x,psize-1,B);
					}
					for(y=1;y<psize-1;y++)
					{
						// Average left round
						CSD[a*psize + y][b*psize].R = AVERAGELEFTROUND(tmpArr,0,y,R);
						CSD[a*psize + y][b*psize].G = AVERAGELEFTROUND(tmpArr,0,y,G);
						CSD[a*psize + y][b*psize].B = AVERAGELEFTROUND(tmpArr,0,y,B);

						// Average right round
						CSD[a*psize + y][b*psize + psize-1].R = AVERAGERIGHTROUND(tmpArr,psize-1,y,R);
						CSD[a*psize + y][b*psize + psize-1].G = AVERAGERIGHTROUND(tmpArr,psize-1,y,G);
						CSD[a*psize + y][b*psize + psize-1].B = AVERAGERIGHTROUND(tmpArr,psize-1,y,B);
					}

					// Average top left round
					CSD[a*psize][b*psize].R = AVERAGETOPLEFTROUND(tmpArr,0,0,R);
					CSD[a*psize][b*psize].G = AVERAGETOPLEFTROUND(tmpArr,0,0,G);
					CSD[a*psize][b*psize].B = AVERAGETOPLEFTROUND(tmpArr,0,0,B);
					// Average top right round
					CSD[a*psize][b*psize + psize-1].R = AVERAGETOPRIGHTROUND(tmpArr,psize-1,0,R);
					CSD[a*psize][b*psize + psize-1].G = AVERAGETOPRIGHTROUND(tmpArr,psize-1,0,G);
					CSD[a*psize][b*psize + psize-1].B = AVERAGETOPRIGHTROUND(tmpArr,psize-1,0,B);
					// Average bottom left round
					CSD[a*psize + psize-1][b*psize].R = AVERAGEBOTTOMLEFTROUND(tmpArr,0,psize-1,R);
					CSD[a*psize + psize-1][b*psize].G = AVERAGEBOTTOMLEFTROUND(tmpArr,0,psize-1,G);
					CSD[a*psize + psize-1][b*psize].B = AVERAGEBOTTOMLEFTROUND(tmpArr,0,psize-1,B);
					// Average bottom right round
					CSD[a*psize + psize-1][b*psize + psize-1].R = AVERAGEBOTTOMRIGHTROUND(tmpArr,psize-1,psize-1,R);
					CSD[a*psize + psize-1][b*psize + psize-1].G = AVERAGEBOTTOMRIGHTROUND(tmpArr,psize-1,psize-1,G);
					CSD[a*psize + psize-1][b*psize + psize-1].B = AVERAGEBOTTOMRIGHTROUND(tmpArr,psize-1,psize-1,B);
				}
			}

			
			// Write the color data to a file
			sprintf(fname,"%s\\Temp\\R%dC%d.bin",WorkingPath,i,j);
			f = fopen(fname,"wb");

			for(y=0;y<256;y++)
			for(x=0;x<256;x++)
				fwrite(&(CSD[y][x].R),sizeof(float),3,f);

			fclose(f);

			// Free the no longer needed component's poly inds array
			delete rooms[i].components[j].polyinds;

			// Update the gauge
			printf("%c",178);
		}

		printf("\n");
	}

	return 1;
}

