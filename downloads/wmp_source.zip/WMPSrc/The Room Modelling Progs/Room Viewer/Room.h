

/////////////////////////////////////////////////////////////////////
//						Room.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
// Consists of all the necessary functions for handling rooms
/////////////////////////////////////////////////////////////////////




WORD	NumRooms;			// The no. of Rooms
ROOM	*Rooms[MAX_ROOMS];	// The array of Rooms
ROOM	*CurrRoom;			// The Current Room




/////////////////////////////////////////////////////////////////////
//					Function Prototypes
/////////////////////////////////////////////////////////////////////








/////////////////////////////////////////////////////////////////////
//					Function Definitions
/////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////
//	Loads a Room, given the filename
/////////////////////////////////////////////////////////////////////

ROOM *Create_Room(char *filename, LPDIRECT3DDEVICE7 lpD, LPDIRECT3D7 lpD3D)
{
	TEXCOORD *ptexcoord;

	// Allocate memory for a Room
	ROOM *pRoom = new ROOM;
	
	// Initialize the Room Structure
	pRoom->Components		= NULL;
	pRoom->RoomVertInds		= NULL;
	pRoom->BSPPolyHead		= NULL;
	pRoom->StackP			= NULL;
	pRoom->StackOB			= NULL;
	pRoom->StackNC			= NULL;
	pRoom->RoomVerts		= NULL;
	pRoom->RoomWaters		= NULL;
	pRoom->UntransformedRoomVB	= NULL;
	pRoom->TransformedRoomVB	= NULL;



	// Load the Room data
	FILE	*file;
	WORD	Num;

	if((file = fopen(filename,"rb")) == (FILE *)NULL)
		return NULL;

	// Read the no. of Vertices
	fread(&(pRoom->NumVerts),sizeof(WORD),1,file);

	// Allocate memory for the Room's Vertices
	pRoom->RoomVerts = new VERTEX[pRoom->NumVerts];
	// Allocate memory for a temporary buffer to hold the
	// texture coordinates
	ptexcoord = new TEXCOORD[pRoom->NumVerts];

	// Read the Room's Vertices
	fread(pRoom->RoomVerts,sizeof(VERTEX),pRoom->NumVerts,file);
	fread(ptexcoord,sizeof(TEXCOORD),pRoom->NumVerts,file);

	// Read the no. of polys
	fread(&(pRoom->NumBSPPolys),sizeof(WORD),1,file);
	// Allocate memory for the Room's BSP Polys
	pRoom->BSPPolyHead = new POLYGON[pRoom->NumBSPPolys];
	// Allocate memory for the Room's Stacks
	pRoom->StackP  = new POLYGON*	[pRoom->NumBSPPolys];
	pRoom->StackOB = new float	[pRoom->NumBSPPolys];
	pRoom->StackNC = new float	[pRoom->NumBSPPolys];

	for(int i=0;i<pRoom->NumBSPPolys;i++)
	{
		// Read the no. of vertices(or indices) for this polygon
		fread(&(pRoom->BSPPolyHead[i].NumVertices),sizeof(WORD),1,file);
		
		// Allocate memory for this poly's drawing indices
		pRoom->BSPPolyHead[i].DIndices = new WORD[pRoom->BSPPolyHead[i].NumVertices];
		// Allocate memory for this poly's indices
		pRoom->BSPPolyHead[i].Indices = new WORD[pRoom->BSPPolyHead[i].NumVertices];
		// Allocate memory for this poly's normals
		pRoom->BSPPolyHead[i].Normals = new NORMAL[pRoom->BSPPolyHead[i].NumVertices];
		
		// Read the Indices
		fread(pRoom->BSPPolyHead[i].Indices,sizeof(WORD),pRoom->BSPPolyHead[i].NumVertices,file);

		// Read the index of this Poly's Front poly
		fread(&Num,sizeof(WORD),1,file);
		// Set the front poly's address of this poly
		if(Num)
			pRoom->BSPPolyHead[i].front = &(pRoom->BSPPolyHead[Num]);
		else
			pRoom->BSPPolyHead[i].front = NULL;
	
		// Read the index of this Poly's Back poly
		fread(&Num,sizeof(WORD),1,file);
		// Set the front poly's address of this poly
		if(Num)
			pRoom->BSPPolyHead[i].back = &(pRoom->BSPPolyHead[Num]);
		else
			pRoom->BSPPolyHead[i].back = NULL;

		// Set the Polygon's Color Changed Value
		pRoom->BSPPolyHead[i].ColorChanged = FALSE;
	}

	// Read the no. of components
	fread(&(pRoom->NumComponents),sizeof(WORD),1,file);
	// Allocate memory for the room's components
	pRoom->Components = new COMPONENT[pRoom->NumComponents];

	for(i=0;i<pRoom->NumComponents;i++)
	{
		// Read the Component's type & brightness
		fread(&(pRoom->Components[i].HasAlpha),sizeof(char),1,file);
		fread(&(pRoom->Components[i].IsGlass),sizeof(char),1,file);
		fread(&(pRoom->Components[i].HitChecked),sizeof(char),1,file);

		// Read the no. of polys for this component
		fread(&(pRoom->Components[i].NumPolyIndices),sizeof(WORD),
														1,file);

		// Allocate memory for the Component's poly indices
		pRoom->Components[i].PolyIndices = 
						new WORD[pRoom->Components[i].NumPolyIndices];
		
		// Read this component's poly indices
		fread(pRoom->Components[i].PolyIndices,sizeof(WORD),
							pRoom->Components[i].NumPolyIndices,file);
	}

	// Allocate memory for storing the component drawing list
	// Count the no. of non-alpha components
	WORD NumNonGlassComps=0;
	for(i=0;i<pRoom->NumComponents;i++)
		if(!(pRoom->Components[i].HasAlpha))
			NumNonGlassComps++;
	// Allocate memory
	pRoom->CompDrawingList = new COMPONENT *[NumNonGlassComps];
	

	// Read the Component's Textures
	char TextureFileName[100];
	char FullTextureFileName[100];
	for(i=0;i<pRoom->NumComponents;i++)
	{
		// Read the Texture File Name
		fread(&Num,sizeof(WORD),1,file);
		fread(TextureFileName,sizeof(char),Num,file);
		TextureFileName[Num] = '\0';

		strcpy(FullTextureFileName,"TexPool\\");
		strcat(FullTextureFileName,TextureFileName);
		
		// Create the Mip Map Chain
		pRoom->Components[i].lpComponentTexture = CreateTexture(FullTextureFileName,lpD);
		if(pRoom->Components[i].lpComponentTexture == NULL)
		{	fclose(file); return NULL; }
	}
	
	
	// Read the no. of Room Lights and add them to the
	// Global Room Lights
	
	WORD NumGlobalLights;
	LIGHT *tmpL;

	// Read the no. of GLs
	fread(&NumGlobalLights,sizeof(WORD),1,file);

	for(i=0;i<NumGlobalLights;i++)
	{
		tmpL = GetNewGLptr();
		fread(tmpL,(sizeof(float) * 11),1,file);
		tmpL->Brightness_by_Radius = 
				tmpL->Brightness / tmpL->Radius;
		tmpL->one_by_2Radius = 
				1.0f / (2.0f * tmpL->Radius);
	}

	// Read the Room's Waters
	fread(&(pRoom->NumWaters),sizeof(WORD),1,file);
	pRoom->RoomWaters = new WATER[pRoom->NumWaters];
	for(i=0;i<pRoom->NumWaters;i++)
	{
		fread(&(pRoom->RoomWaters[i].y),sizeof(float)*4 + sizeof(WORD),1,file);
		pRoom->RoomWaters[i].BoundingPolyInds = new WORD[pRoom->RoomWaters[i].NumBoundingPolys];
		fread((pRoom->RoomWaters[i].BoundingPolyInds),sizeof(WORD),pRoom->RoomWaters[i].NumBoundingPolys,file);
	}


	// We're done reading
	fclose(file);


	// Calculate the Room's Poly's Normals
	for(i=0;i<pRoom->NumBSPPolys;i++)
	{
		// Calculate this poly's Normal
		CalcPolyNormal(&(pRoom->BSPPolyHead[i]),pRoom);

		// Calculate this poly's Side Normals
		CalcPolySideNormal(&(pRoom->BSPPolyHead[i]),pRoom);

		// Calculate this poly's 2nd LightMap Normal
		CalcPolyLightMapNormal2(&(pRoom->BSPPolyHead[i]),pRoom);
	}


	// Set the polygon's parent component
	// Also, allocate memory for the Component's
	// triangle vertex index buffer
	
	DWORD TotRoomTriInds=0;
	for(i=0;i<pRoom->NumComponents;i++)
	{
		DWORD TotCompTriInds=0;

		for(int j=0;j<pRoom->Components[i].NumPolyIndices;j++)
		{
			// Set the parent component
			pRoom->BSPPolyHead[pRoom->Components[i].PolyIndices[j]].ParentComponent = &(pRoom->Components[i]);
			
			// Add the poly's triangles to the total
			TotCompTriInds +=(pRoom->BSPPolyHead[pRoom->Components[i].PolyIndices[j]].NumVertices) +
						 (pRoom->BSPPolyHead[pRoom->Components[i].PolyIndices[j]].NumVertices - 3) * 2;
		}

		// Allocate memory for this component's triangle indices
		pRoom->Components[i].TriVertInds = new WORD[TotCompTriInds];

		// Add this component's tri-indices to the room's tri indices
		TotRoomTriInds += TotCompTriInds;
	}
	// Allocate memory for the Room's Tri-Inds
	pRoom->RoomVertInds = new WORD[TotRoomTriInds];

	
	// Calculate the size necessary for the room's VBs
	// and set the poly's drawing vertices
	pRoom->VBCapacity = 0;
	for(i=0;i<pRoom->NumBSPPolys;i++)
	for(int j=0;j<pRoom->BSPPolyHead[i].NumVertices;j++)
		pRoom->BSPPolyHead[i].DIndices[j] = pRoom->VBCapacity++;
				
	///////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////
	// Create and Fill all the Room's  Vertex Buffers	//
	//////////////////////////////////////////////////////

	// Give a description for the Room's VBs
	D3DVERTEXBUFFERDESC vbdesc;
	ZeroMemory( &vbdesc, sizeof(D3DVERTEXBUFFERDESC) );
	vbdesc.dwSize        = sizeof(D3DVERTEXBUFFERDESC);
	vbdesc.dwCaps        = D3DVBCAPS_SYSTEMMEMORY;
	vbdesc.dwFVF         = D3DFVF_XYZ;
	vbdesc.dwNumVertices = pRoom->VBCapacity;

	// Create the Untransformed VB
	if( FAILED( lpD3D->CreateVertexBuffer( &vbdesc, &(pRoom->UntransformedRoomVB), 0L ) ) )
        return NULL;

	// Set Caps & Vertex Format for the Transformed VB
	vbdesc.dwFVF         = D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX3;

	// Create the Transformed VB
	if( FAILED( lpD3D->CreateVertexBuffer( &vbdesc, &(pRoom->TransformedRoomVB), 0L ) ) )
        return NULL;

	
	// Lock & Fill the Untransformed VB with Vertex Coordinate Data
	UNTRANSFORMED_VERTEX *pUTVertices;
	if( SUCCEEDED( pRoom->UntransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pUTVertices,
                                          NULL ) ) )
    {
		for(i=0;i<pRoom->NumBSPPolys;i++)
		for(int j=0;j<pRoom->BSPPolyHead[i].NumVertices;j++)
		{
			pUTVertices->x = pRoom->RoomVerts[pRoom->BSPPolyHead[i].Indices[j]].x;
			pUTVertices->y = pRoom->RoomVerts[pRoom->BSPPolyHead[i].Indices[j]].y;
			pUTVertices->z = pRoom->RoomVerts[pRoom->BSPPolyHead[i].Indices[j]].z;

			pUTVertices++;
		}

        pRoom->UntransformedRoomVB->Unlock();
    }


	// Lock & Fill the Transformed VB with 
	// Color and Texture Data
	TRANSFORMED_VERTEX *pTVertices;
	if( SUCCEEDED( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
                                          NULL ) ) )
    {
		for(i=0;i<pRoom->NumBSPPolys;i++)
		for(int j=0;j<pRoom->BSPPolyHead[i].NumVertices;j++)
		{
			pTVertices->color	= WHITE;

			pTVertices->tuB		= ptexcoord[pRoom->BSPPolyHead[i].Indices[j]].tu;
			pTVertices->tvB		= ptexcoord[pRoom->BSPPolyHead[i].Indices[j]].tv;

			pTVertices++;
		}
		
        pRoom->TransformedRoomVB->Unlock();
    }


	// Optimize the Untransformed VB
	pRoom->UntransformedRoomVB->Optimize(lpD,0);


	// free the temp allocation
	free(ptexcoord);

	return(pRoom);
}




/////////////////////////////////////////////////////////////////////
// Process Room Vertices
/////////////////////////////////////////////////////////////////////

inline void ProcessRoomVBVertices(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	// Process Vertices
	pRoom->TransformedRoomVB->ProcessVertices(D3DVOP_TRANSFORM | D3DVOP_CLIP,
										0,pRoom->VBCapacity,
										pRoom->UntransformedRoomVB,0,
										lpD,D3DPV_DONOTCOPYDATA);
}




/////////////////////////////////////////////////////////////////////
// Set Room Triangles that have to be Drawn
/////////////////////////////////////////////////////////////////////

void SetRoomDrawingTriangles(ROOM *pRoom, D3DVECTOR *ViewPos)
{

	// Vars used for bsp walking
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackDist;
	float			Dist;
	WORD			*ppoly_index,*ppoly_end_index;
	COMPONENT		**pComp;

	// Initialize the component's vars
	for(int i=0;i<pRoom->NumComponents;i++)
		pRoom->Components[i].Triind = pRoom->Components[i].TriVertInds;
		
	// Set the end ptr to the beginning of the comp drawing list
	pRoom->eCompDrawingList = pRoom->CompDrawingList;


	ppoly = pRoom->BSPPolyHead;
	pStackP = pRoom->StackP;
	pStackDist = pRoom->StackOB;

	
	for(;;)
	{
		while(ppoly)
		{
			Dist = PERPDISTP(ViewPos,ppoly);
				
			*pStackP++ = ppoly; *pStackDist++ = Dist;

			if(Dist > 0.0f)
				ppoly = ppoly->front;
			else
				ppoly = ppoly->back;
		}

		if(pStackP > pRoom->StackP)
		{
			ppoly = *(--pStackP); Dist = *(--pStackDist);
	
						
			// Copy only polygons that face frontwards,

			if(Dist > 0.0f)
			{
				ppoly_index = ppoly->DIndices;
				ppoly_end_index	= ppoly->DIndices + ppoly->NumVertices;
								
				// Copy the first triangle
				*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
				*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
				*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
				
				// Copy the remaining triangles
				for( ; ppoly_index < ppoly_end_index ; )
				{
					*(ppoly->ParentComponent->Triind)++ = *(ppoly->DIndices);
					*(ppoly->ParentComponent->Triind)++ = *(ppoly->ParentComponent->Triind - 2);
					*(ppoly->ParentComponent->Triind)++ = *ppoly_index++;
				}

				// See if it is a new component and add it to
				// the component drawing list (if it is not glass)
				if(!(ppoly->ParentComponent->HasAlpha))
				{
					for(pComp = pRoom->CompDrawingList;
						pComp < pRoom->eCompDrawingList;
						pComp++)
					{
						if(ppoly->ParentComponent == *pComp)
							break;
					}

					if(pComp == pRoom->eCompDrawingList)
						*(pRoom->eCompDrawingList)++ = ppoly->ParentComponent;
				}
			
			}


			if(Dist > 0.0f)
				ppoly = ppoly->back;
			else
				ppoly = ppoly->front;
		}
		else
			break;
	}
}


/////////////////////////////////////////////////////////////////////
// Draw the Solid Room Components
/////////////////////////////////////////////////////////////////////

void DrawRoomSolidComponents(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	COMPONENT **pComp;

	for(pComp = pRoom->CompDrawingList;
		pComp < pRoom->eCompDrawingList;
		pComp++)
	{
		// Set the component's Texture
		lpD->SetTexture(0,(*pComp)->lpComponentTexture);

		// Draw
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									(*pComp)->TriVertInds,
									((*pComp)->Triind - (*pComp)->TriVertInds),
									0);
	}
}


/////////////////////////////////////////////////////////////////////
// Draw the Room Glass Components
/////////////////////////////////////////////////////////////////////

void DrawRoomGlassComponents(ROOM *pRoom, LPDIRECT3DDEVICE7 lpD)
{
	for(int i=0;i < pRoom->NumComponents;i++)
		if(pRoom->Components[i].HasAlpha)
		{
			// Set the component's Texture
			lpD->SetTexture(0,pRoom->Components[i].lpComponentTexture);

			// Draw
			lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
										pRoom->TransformedRoomVB,
										0,pRoom->VBCapacity,
										pRoom->Components[i].TriVertInds,
										(pRoom->Components[i].Triind - pRoom->Components[i].TriVertInds),
										0);
		}
}




/////////////////////////////////////////////////////////////////////
//	Cleans up a Room
/////////////////////////////////////////////////////////////////////

void CleanupRoom(ROOM *pRoom)
{	
	
	/////////////////////////////////////////////
	//		Release the Room's Index Buffer		
	/////////////////////////////////////////////
	
	// Delete the Room's Index Buffer
	SafeDelete(pRoom->RoomVertInds);
	
	//////////////////////////////////////
	//		Release the Room's Vertices
	//////////////////////////////////////

	// Delete the Room's Vertices
	SafeDelete(pRoom->RoomVerts);

	//////////////////////////////////////
	//		Release the Room's Waters
	//////////////////////////////////////

	// Delete the Room's Waters
	for(int i=0;i<pRoom->NumWaters;i++)
		SafeDelete(pRoom->RoomWaters[i].BoundingPolyInds);
	SafeDelete(pRoom->RoomWaters);


	//////////////////////////////////
	// Release the Room's Stacks
	//////////////////////////////////

	// Delete the Room's Stacks
	SafeDelete(pRoom->StackP);
	SafeDelete(pRoom->StackOB);
	SafeDelete(pRoom->StackNC);


	//////////////////////////////////
	//	Release the Room's Polys
	//////////////////////////////////

	for(i=0;i<pRoom->NumBSPPolys;i++)
	{
		// Delete the Room's Poly's drawing Indices
		SafeDelete(pRoom->BSPPolyHead[i].DIndices);
	
		// Delete the Room's Poly's Indices
		SafeDelete(pRoom->BSPPolyHead[i].Indices);
	
		// Delete the Room's Poly's Normals
		SafeDelete(pRoom->BSPPolyHead[i].Normals);
	}


	// Delete the Room's BSP Polys
	SafeDelete(pRoom->BSPPolyHead);
	

	//////////////////////////////////////
	//	Release the Room's Components
	//////////////////////////////////////

	for(i=0;i<pRoom->NumComponents;i++)
	{
		// Delete the component's Vertex indices
		SafeDelete(pRoom->Components[i].PolyIndices);
		SafeDelete(pRoom->Components[i].TriVertInds);
		SafeRelease(pRoom->Components[i].lpComponentTexture);
	}

	// Delete the Room's Components
	SafeDelete(pRoom->Components);

	// Delete the component drawing list
	SafeDelete(pRoom->CompDrawingList);
	
	//////////////////////////////////////
	// Release the Room's Vertex Buffers
	//////////////////////////////////////

	SafeRelease(pRoom->UntransformedRoomVB);
	SafeRelease(pRoom->TransformedRoomVB);


	//////////////////////////////////////
	// Release the Room itself
	//////////////////////////////////////

	SafeDelete(pRoom);	

}
