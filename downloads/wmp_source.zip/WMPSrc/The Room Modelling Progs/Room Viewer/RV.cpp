
//------ Include Files ------//

#define D3D_OVERLOADS
#define INITGUID
#include <windows.h>
#include <mmsystem.h>
#include <ddraw.h>
#include <d3d.h>
#include <d3dtypes.h>
#include "d3dutil.h"
#include <dinput.h>
#include <stdio.h>
#include "resource.h"
#include "Defines and globals.h"
#include "Texture.h"
#include "LightMap.h"
#include "HitChecking.h"
#include "Room.h"
#include "Cleanup.h"



DWORD cx  = (DWORD)(SCREEN_RES_X/2.0f);
DWORD cy  = (DWORD)(SCREEN_RES_Y/2.0f);
DWORD inx = (DWORD)(SCREEN_RES_X * 16.0f / 800.0f);
DWORD iny = (DWORD)(SCREEN_RES_Y * 16.0f / 600.0f);


// The Ceiling & Floor structure
D3DLVERTEX SkyBoxTop_Verts[4];
D3DLVERTEX SkyBoxBottom_Verts[4];
D3DLVERTEX SkyBoxLeft_Verts[4];
D3DLVERTEX SkyBoxRight_Verts[4];
D3DLVERTEX SkyBoxBack_Verts[4];
D3DLVERTEX SkyBoxFront_Verts[4];

D3DTLVERTEX	CrossHairVerts[4];


// Switches
WORD HitChecking=1;		
WORD GravityEnabled=0;
WORD DrawDynamicLights=0;
WORD DrawUserSpotLight=0;

// Others
float FrameRate=0.0f;
float Time_To_Update_FrameRate=0.0f;
LIGHT *UserSpotLight;


//------ Function Prototypes -----//

int  create_objects();
static BOOL Init(HINSTANCE hInstance, int nCmdShow);
BOOL init_d3d();
BOOL init_ddraw(HWND hWnd);
void render_frame();


// ----- Function Definitions -----//

void OutputText( DWORD x, DWORD y, TCHAR* str )
{
    HDC hDC;

    // Get a DC for the surface. Then, write out the buffer
    if( lpDDSBack )
    {
        if( SUCCEEDED( lpDDSBack->GetDC(&hDC) ) )
        {
            SetBkMode( hDC, TRANSPARENT );
            
			SetTextColor( hDC, RGB(0,0,0) );
            ExtTextOut( hDC, x+1, y+1, 0, NULL, str, lstrlen(str), NULL );
			SetTextColor( hDC, RGB(255,255,255) );
            ExtTextOut( hDC, x, y, 0, NULL, str, lstrlen(str), NULL );
			
            lpDDSBack->ReleaseDC(hDC);
        }
    }
}


LRESULT CALLBACK 
WindowProc(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {	   	
		case WM_DESTROY:

			Cleanup();
            PostQuitMessage(0);
            break;

	    case WM_KEYDOWN: 

	        switch (wParam) { 

			case VK_UP:
				
				if(ManHeight == STANDUPHEIGHT || IsUnderWater)
					MoveVel=STANDMOVEVEL;
				else
					MoveVel=CROUCHMOVEVEL;
				break;

			case VK_DOWN:

				if(ManHeight == STANDUPHEIGHT || IsUnderWater)
					MoveVel=-STANDMOVEVEL;
				else
					MoveVel=-CROUCHMOVEVEL;
				break;

			case VK_RIGHT:

				if(ManHeight == STANDUPHEIGHT || IsUnderWater)
					StrafeVel=-STANDMOVEVEL;
				else
					StrafeVel=-CROUCHMOVEVEL;
				break;

			case VK_LEFT:

				if(ManHeight == STANDUPHEIGHT || IsUnderWater)
					StrafeVel=STANDMOVEVEL;
				else
					StrafeVel=CROUCHMOVEVEL;
				break;

			case VK_NUMPAD0: case VK_INSERT:

				CrouchKeyPressed = TRUE;
				break;

			}
			break;

	    case WM_KEYUP: 

	        switch (wParam) { 

			case '1':

				DrawDynamicLights = !DrawDynamicLights;
				break;

			case '2':

				DrawUserSpotLight = !DrawUserSpotLight;

				if(DrawUserSpotLight)
				{
					// Allocate a Spot Light for the user
					UserSpotLight = GetNewGLptr();
					UserSpotLight->Brightness	= 1.0f;
					UserSpotLight->Radius		= 500.0f;
					UserSpotLight->R			= 1.0f;
					UserSpotLight->G			= 1.0f;
					UserSpotLight->B			= 1.0f;
					UserSpotLight->Brightness_by_Radius =// Not necessary
								UserSpotLight->Brightness / UserSpotLight->Radius;
					UserSpotLight->one_by_2Radius = // Is necessary
								1.0f / (2.0f * UserSpotLight->Radius);
				}
				else
					ReturnUsedGLptr(UserSpotLight);

				break;

			case 'h':case 'H':

				HitChecking = !HitChecking;
				break;
			
			case 'g':case 'G':

				GravityEnabled = !GravityEnabled; tGravity = 0.0f;
				break;

			case VK_UP:
			case VK_DOWN:
			
				MoveVel=0.0f;
				break;

			case VK_RIGHT:
			case VK_LEFT:

				StrafeVel=0.0f;
				break; 

			case VK_NUMPAD0:
			case VK_INSERT:

				CrouchKeyPressed = FALSE;
				break;


			case VK_ESCAPE:

				// exit the program on escape

				DestroyWindow(hWnd);
				break;


			}
			break;

        default:
            return DefWindowProc(hWnd, uMsg, wParam, lParam);
    }
	
	return 0L;
}

BOOL init_ddraw(HWND hWnd)
{
	HRESULT ddrval;

    // Create the main DirectDraw object

    ddrval = DirectDrawCreateEx(NULL, (void **) &lpDD, IID_IDirectDraw7, NULL);
    if (ddrval != DD_OK) {
		ErrStr=Err_DirectDrawCreate;
		return FALSE;
	}

    // Set our cooperative level

    ddrval = lpDD->SetCooperativeLevel(hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
    if (ddrval != DD_OK) {
		ErrStr=Err_Coop;
		return FALSE;
	}

	// Set the display mode

	ddrval = lpDD->SetDisplayMode( SCREEN_RES_X, SCREEN_RES_Y, 16, 0, 0);
	if (ddrval !=DD_OK) {
		ErrStr=Err_DispMode;
		return FALSE;
	}

    // Create the primary surface with 1 back buffer

    DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
    ddsd.dwSize = sizeof( ddsd );
    ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
                          DDSCAPS_FLIP | DDSCAPS_3DDEVICE |
                          DDSCAPS_COMPLEX;
    ddsd.dwBackBufferCount = 1;
    ddrval = lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL );
	if (ddrval!=DD_OK) {
		ErrStr=Err_CreateSurf;
		return FALSE;
	}

	// Fetch back buffer interface

	DDSCAPS2 ddscaps;
	ZeroMemory(&ddscaps,sizeof(ddscaps));
	ddscaps.dwCaps=DDSCAPS_BACKBUFFER;
	ddrval=lpDDSPrimary->GetAttachedSurface(&ddscaps,&lpDDSBack);
	if (ddrval!=DD_OK) {
		ErrStr=Err_CreateSurf;
		return FALSE;
	}

	// return success to caller

	return TRUE;
}

// Variables used when looking for z-buffer
BOOL zbuf_flag=FALSE;

// Used to keep track of which z-buffer device we got.
char zbuf_format=0;

// Z-Buffer callback function
static HRESULT WINAPI EnumZBufferFormatsCallback( DDPIXELFORMAT* pddpf,
                                                  VOID* pddpfDesired )
{
    // If parameters == NULL, don't enumerate more
	if( NULL==pddpf || NULL==pddpfDesired )
        return D3DENUMRET_CANCEL;

    // If the current pixel format's match the desired ones (DDPF_ZBUFFER and
    // possibly DDPF_STENCILBUFFER), lets copy it and return. This function is
    // not choosy...it accepts the first valid format that comes along.
    if( pddpf->dwFlags == ((DDPIXELFORMAT*)pddpfDesired)->dwFlags )
    {
        memcpy( pddpfDesired, pddpf, sizeof(DDPIXELFORMAT) );
		
		// Set flag to TRUE, since we got a valid z-buffer format.
		zbuf_flag=TRUE;
        return D3DENUMRET_CANCEL;
    }

    return D3DENUMRET_OK;
}

BOOL init_d3d()
{
	
	// Get Direct3D interface
	if (FAILED(lpDD->QueryInterface(IID_IDirect3D7, (LPVOID *)&lpD3D))) 
	{
		// Set error string.
		ErrStr=Err_Query;
		
		// Return false
		return FALSE;
	}
	
	// Enumerate the Z-buffer formats, making sure they fit the device.
	// First try hardware with accelerated transform and lighting.
	DDPIXELFORMAT m_ddpfZBuffer;
	ZeroMemory(&m_ddpfZBuffer,sizeof(m_ddpfZBuffer));
	m_ddpfZBuffer.dwSize=sizeof(m_ddpfZBuffer);
	m_ddpfZBuffer.dwFlags = DDPF_ZBUFFER ;
	lpD3D->EnumZBufferFormats( IID_IDirect3DTnLHalDevice, 
							   EnumZBufferFormatsCallback,
							   (VOID*)&m_ddpfZBuffer);
	
	
	if (zbuf_flag) {
		zbuf_format=1;
	} else {
		lpD3D->EnumZBufferFormats( IID_IDirect3DHALDevice, EnumZBufferFormatsCallback,
		                            (VOID*)&m_ddpfZBuffer );
		if (zbuf_flag) {
			zbuf_format=2;
		} else {
			lpD3D->EnumZBufferFormats( IID_IDirect3DMMXDevice, EnumZBufferFormatsCallback,
			                            (VOID*)&m_ddpfZBuffer );
			if (zbuf_flag) {
				zbuf_format=3;
			} else {
				lpD3D->EnumZBufferFormats( IID_IDirect3DRGBDevice, EnumZBufferFormatsCallback,
				                            (VOID*)&m_ddpfZBuffer );
				if (zbuf_flag) 
					zbuf_format=4;
			}
		}
	}

	// Create the zbuffer
	DDSURFACEDESC2 ddsd;
	HRESULT ddrval;
	ZeroMemory(&ddsd,sizeof(ddsd));
    ddsd.dwSize = sizeof( ddsd );
    ddsd.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT|DDSD_PIXELFORMAT;
	
	// Use counter to check if we should create z-buffer in video or system memory
	// Note flag that specifies that this is a z-buffer surface.
	if (zbuf_format<3)
		ddsd.ddsCaps.dwCaps = DDSCAPS_ZBUFFER|DDSCAPS_VIDEOMEMORY;
	else
		ddsd.ddsCaps.dwCaps = DDSCAPS_ZBUFFER|DDSCAPS_SYSTEMMEMORY;
	
	// Set this to size of screen
	ddsd.dwWidth=SCREEN_RES_X;
	ddsd.dwHeight=SCREEN_RES_Y;
	ddsd.ddpfPixelFormat.dwSize=sizeof(DDPIXELFORMAT);
	ddsd.ddpfPixelFormat.dwFlags=DDPF_ZBUFFER;
	memcpy(&ddsd.ddpfPixelFormat,&m_ddpfZBuffer,sizeof(DDPIXELFORMAT));
    ddrval = lpDD->CreateSurface( &ddsd, &lpDDSZBuf, NULL );
	if (ddrval!=DD_OK) 
	{
		ErrStr = "Failed to create Z-buffer";
		return FALSE; // Could not get z-buffer. Return false
	} else 
	{
		
		// Attach z-buffer to surface
		lpDDSBack->AddAttachedSurface(lpDDSZBuf);
	}

	// Set up the best device interface

	if (lpD3D->CreateDevice(IID_IDirect3DTnLHalDevice,lpDDSBack,&lpDevice)!=D3D_OK) 
	{
		if (lpD3D->CreateDevice(IID_IDirect3DHALDevice,lpDDSBack,&lpDevice)!=D3D_OK) 
		{
			if (lpD3D->CreateDevice(IID_IDirect3DMMXDevice,lpDDSBack,&lpDevice)!=D3D_OK) 
			{
				if (lpD3D->CreateDevice(IID_IDirect3DRGBDevice,lpDDSBack,&lpDevice)!=D3D_OK) 
				{
				// Set error string.
				ErrStr=Err_Device;
		
				// Return false
				return FALSE;
				}
			}
		}
	}

	// Set up the viewport
	D3DVIEWPORT7 view;
	view.dwX=0;
	view.dwY=0;
	view.dwWidth=SCREEN_RES_X;
	view.dwHeight=SCREEN_RES_Y; 
	view.dvMinZ=0.0f;
	view.dvMaxZ=1.0f;
	if (lpDevice->SetViewport(&view)!=D3D_OK)
	{
		// Set error string.
		ErrStr=Err_SetView;
		
		// Return false
		return FALSE;
	}
	
	// Projection matrix.
	D3DMATRIX proj_m;
	
	// Set projection matrix. 
	D3DUtil_SetProjectionMatrix(proj_m, 1.57f, 0.75f, 5.0f, 25000.0f );
	lpDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&proj_m);


	// Set linear (nice) filtering.
	lpDevice->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTFG_LINEAR);
	lpDevice->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTFN_LINEAR);

	// Enable z-buffering. 
    lpDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, TRUE);


	// Set the appropriate global states
	lpDevice->SetRenderState( D3DRENDERSTATE_SHADEMODE,			D3DSHADE_FLAT );
    lpDevice->SetRenderState( D3DRENDERSTATE_DITHERENABLE,		TRUE );
    lpDevice->SetRenderState( D3DRENDERSTATE_TEXTUREPERSPECTIVE,TRUE );
    lpDevice->SetRenderState( D3DRENDERSTATE_SPECULARENABLE,	FALSE );
    lpDevice->SetRenderState( D3DRENDERSTATE_LIGHTING,			FALSE );
	lpDevice->SetRenderState( D3DRENDERSTATE_CULLMODE,			D3DCULL_NONE);



	// Record the necessary state blocks

	// StateBlock0
	lpDevice->BeginStateBlock();
	lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
	lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
	lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_SRCCOLOR);
	lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_INVSRCCOLOR);
	lpDevice->EndStateBlock(&GlassSetStatesBlockHandle);

	// StateBlock1
	lpDevice->BeginStateBlock();
	lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
	lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);
	lpDevice->EndStateBlock(&GlassResetStatesBlockHandle);

	// StateBlock2
	lpDevice->BeginStateBlock();
	lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,			D3DTADDRESS_CLAMP );
	lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,	2);
	lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
	lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
	lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_SRCCOLOR );
	lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_ONE);
	lpDevice->EndStateBlock(&LightmapSetStatesBlockHandle);

	// StateBlock2
	lpDevice->BeginStateBlock();
	lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,			D3DTADDRESS_WRAP );
	lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,	0);
	lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
	lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);
	lpDevice->EndStateBlock(&LightmapResetStatesBlockHandle);




	// return success to caller
	return TRUE;
}


int create_objects()
{

	//////////////////////////////////////////////////////
	//			Initialize the Floor Structure			//
	//////////////////////////////////////////////////////

	
	// Load the special Textures
	lpSkyBoxTopTexture    = CreateTexture("skybox_top0.bmp",lpDevice);
	lpSkyBoxBottomTexture = CreateTexture("skybox_bottom0.bmp",lpDevice);
	lpSkyBoxLeftTexture   = CreateTexture("skybox_left0.bmp",lpDevice);
	lpSkyBoxRightTexture  = CreateTexture("skybox_right0.bmp",lpDevice);
	lpSkyBoxBackTexture   = CreateTexture("skybox_back0.bmp",lpDevice);
	lpSkyBoxFrontTexture  = CreateTexture("skybox_front0.bmp",lpDevice);
	
	lpCrossHairTexture = CreateTexture("Crosshair0.bmp",lpDevice);
	lpLightMapTexture  = CreateTexture("Lightmap0.bmp",	lpDevice);
	

	// Initialize the ceiling & floor vertices

	SkyBoxTop_Verts[0]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );
	SkyBoxTop_Verts[1]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	SkyBoxTop_Verts[2]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	SkyBoxTop_Verts[3]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );

	SkyBoxBottom_Verts[0]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, -SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	SkyBoxBottom_Verts[1]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, -SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	SkyBoxBottom_Verts[2]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, -SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );
	SkyBoxBottom_Verts[3]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, -SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );

	SkyBoxLeft_Verts[0]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, -SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	SkyBoxLeft_Verts[1]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS,  SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	SkyBoxLeft_Verts[2]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, -SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	SkyBoxLeft_Verts[3]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS,  SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );
		
	SkyBoxRight_Verts[0]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, -SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	SkyBoxRight_Verts[1]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS,  SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	SkyBoxRight_Verts[2]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, -SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	SkyBoxRight_Verts[3]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS,  SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );

	SkyBoxBack_Verts[0]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, -SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	SkyBoxBack_Verts[1]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS,  SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	SkyBoxBack_Verts[2]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, -SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	SkyBoxBack_Verts[3]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS,  SKYBOX_RADIUS,  SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );

	SkyBoxFront_Verts[0]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS, -SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  1.0f );
	SkyBoxFront_Verts[1]=D3DLVERTEX( D3DVECTOR(  SKYBOX_RADIUS,  SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  1.0f,  0.0f );
	SkyBoxFront_Verts[2]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS, -SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  1.0f );
	SkyBoxFront_Verts[3]=D3DLVERTEX( D3DVECTOR( -SKYBOX_RADIUS,  SKYBOX_RADIUS, -SKYBOX_RADIUS), 0xffffffff, 0,  0.0f,  0.0f );


	// initialize the Cross Hair vertices
	CrossHairVerts[0] = D3DTLVERTEX( D3DVECTOR( (float)cx-inx, (float)cy+iny, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 0.0f, 1.0f );
    CrossHairVerts[1] = D3DTLVERTEX( D3DVECTOR( (float)cx-inx, (float)cy-iny, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 0.0f, 0.0f );
    CrossHairVerts[2] = D3DTLVERTEX( D3DVECTOR( (float)cx+inx, (float)cy+iny, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 1.0f, 1.0f );
    CrossHairVerts[3] = D3DTLVERTEX( D3DVECTOR( (float)cx+inx, (float)cy-iny, 0.0f ), 0.5f,  D3DRGB(1.0f,1.0f,1.0f), 0, 1.0f, 0.0f );

	///////////////////////////////////////////////////////

	NumRooms = 1;
	// Load all the Rooms
	for(WORD i=0;i<NumRooms;i++)
	{
		Rooms[i] = Create_Room("Rdata.bin",lpDevice,lpD3D);
		
		if(Rooms[i] == NULL)
		{	ErrStr = "Could not Load Room";
			return FALSE;
		}
	}

	CurrRoom = Rooms[0];


	return TRUE;
}


void render_frame()
{
	// recover any lost surfaces

	if (lpDDSPrimary->IsLost()==DDERR_SURFACELOST)
		lpDDSPrimary->Restore();
	if (lpDDSBack->IsLost()==DDERR_SURFACELOST)
		lpDDSBack->Restore();
	if (lpDDSZBuf->IsLost()==DDERR_SURFACELOST)
		lpDDSZBuf->Restore();
	

	// increment viewer position
	
	rotAngle+=rotVel*elapsed;
	// correct the angle of rotation
	if(rotAngle > 6.283185f) rotAngle -= 6.283185f;

	lookupAngle+=lookupVel*elapsed;
	// Restrict the angle of elevation
	if(lookupAngle > 1.570796f) lookupAngle = 1.570796f;
	else if(lookupAngle < -1.570796f) lookupAngle = -1.570796f;


	BOOLEAN FaceWasUnderWater=FaceIsUnderWater;
	for(int i=0;i<CurrRoom->NumWaters;i++)
	{
		if(Face.y - MINDIST * 1.5f < CurrRoom->RoomWaters[i].y)
		{
			for(int j=0;j<CurrRoom->RoomWaters[i].NumBoundingPolys;j++)
				if(CURRPERPDISTV(Face,(CurrRoom->BSPPolyHead + CurrRoom->RoomWaters[i].BoundingPolyInds[j])) < 0.0f)
					break;

			if(j == CurrRoom->RoomWaters[i].NumBoundingPolys)
			{
				IsUnderWater = TRUE;
				tGravity = 0.0f;

				if(Face.y < CurrRoom->RoomWaters[i].y)
				{
					if(!FaceIsUnderWater)
					{
						FaceIsUnderWater = TRUE;

						UnderWaterColor = D3DRGB(CurrRoom->RoomWaters[i].R,
												 CurrRoom->RoomWaters[i].G,
												 CurrRoom->RoomWaters[i].B);

						// Lock and fill the transformed VB with
						// the required color
						TRANSFORMED_VERTEX *pTVertices;
						if( SUCCEEDED( CurrRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
							                                  NULL ) ) )
						{
							POLYGON *pPoly  = CurrRoom->BSPPolyHead;
							POLYGON *epPoly = pPoly + CurrRoom->NumBSPPolys;
							WORD	*i,*ei;
			
							for( ; pPoly < epPoly ; pPoly++)
							{
								// Set back the color changed flag
								if(pPoly->ColorChanged)
									pPoly->ColorChanged = FALSE;

								i  = pPoly->DIndices;
								ei = i + pPoly->NumVertices;
				
								for(; i < ei ; i++)
									pTVertices[*i].color = UnderWaterColor;
							}

							CurrRoom->TransformedRoomVB->Unlock();
						}
					}
				}
				else
					FaceIsUnderWater=FALSE;


				break;
			}
		}
	}

	if(IsUnderWater && (i == CurrRoom->NumWaters))
	{
		// We're not under water anymore
		IsUnderWater = FALSE;
	}

	if(FaceIsUnderWater)
	{
		UnderWaterDistortion += UnderWaterDistortionInc * elapsed;

		if(UnderWaterDistortion > 0.77f)
		{
			UnderWaterDistortion = 0.77f;
			UnderWaterDistortionInc = -0.025f;
		}
		else if(UnderWaterDistortion < 0.73f)
		{
			UnderWaterDistortion = 0.73f;
			UnderWaterDistortionInc = 0.025f;
		}
		
		// Projection matrix.
		D3DMATRIX proj_m;

		// Set projection matrix. 
		D3DUtil_SetProjectionMatrix(proj_m, 1.57f, UnderWaterDistortion, 5.0f, 25000.0f );
		lpDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION,&proj_m);

	}
	else if(FaceWasUnderWater)
	{		
		// Lock and fill the transformed VB with
		// the required color
		TRANSFORMED_VERTEX *pTVertices;
		if( SUCCEEDED( CurrRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
		                                      NULL ) ) )
		{
			POLYGON *pPoly  = CurrRoom->BSPPolyHead;
			POLYGON *epPoly = pPoly + CurrRoom->NumBSPPolys;
			WORD	*i,*ei;
			
			for( ; pPoly < epPoly ; pPoly++)
			{
				// Set back the color changed flag
				if(pPoly->ColorChanged)
					pPoly->ColorChanged = FALSE;

				i  = pPoly->DIndices;
				ei = i + pPoly->NumVertices;
				
				for(; i < ei ; i++)
					pTVertices[*i].color = WHITE;
			}

			CurrRoom->TransformedRoomVB->Unlock();
		}
	}



	if(GravityEnabled)
	{
		// Calc lean Angle (view blob)
		if((MoveVel || StrafeVel) && IsOnGround)
		{
			if(walkleanDir)
			{
				leanAngle += 0.1f * elapsed;
				if(leanAngle > 0.01745329f)
				{	
					leanAngle = 0.01745329f;
					walkleanDir = 0;
				}
			}
			else
			{
				leanAngle -= 0.1f * elapsed;
				if(leanAngle < -0.01745329f)
				{	
					leanAngle = -0.01745329f;
					walkleanDir = 1;
				}
			}
		}
		else if(leanAngle)
		{
			if(leanAngle > 0.0f)
			{
				leanAngle -= 0.05f * elapsed;
				if(leanAngle < 0.0f) leanAngle = 0.0f;
			}
			else
			{	
				leanAngle += 0.1f * elapsed;
				if(leanAngle > 0.0f) leanAngle = 0.0f;
			}
		}

	}

	//////////////////////////////////////////////
	//		Calculate the Rotation Matrix		//
	//////////////////////////////////////////////

    D3DUtil_SetIdentityMatrix(RotationMatrix);
	// Produce and combine the rotation matrices.
	D3DMATRIX	TempMat;	// A temp matrix
    D3DUtil_SetRotateZMatrix(TempMat, leanAngle);	// roll
    D3DUtil_MatrixMultiply(RotationMatrix,RotationMatrix,TempMat);
	D3DUtil_SetRotateXMatrix(TempMat,lookupAngle);	// pitch
	D3DUtil_MatrixMultiply(RotationMatrix,RotationMatrix,TempMat);
	D3DUtil_SetRotateYMatrix(TempMat,-rotAngle);	// yaw
	D3DUtil_MatrixMultiply(RotationMatrix,RotationMatrix,TempMat);
	
	///////////////////////////////////////////////

	

	// calculate the next position
	frontPtz = cosf(rotAngle);
	frontPtx = sinf(rotAngle);

	// calculate the looking at direction and the normal to it
	ViewDir.y = sinf(lookupAngle);
	ViewNorm.y = cosf(lookupAngle);
	ViewDir.z = frontPtz * ViewNorm.y;
	ViewDir.x = frontPtx * ViewNorm.y;
	ViewNorm.z = -frontPtz * ViewDir.y;
	ViewNorm.x = -frontPtx * ViewDir.y;

	// Decrease the force
	if(GravityEnabled)
	{
		if(IsUnderWater)
			Force -= Force * elapsed * 2.0f;
		else
			Force -= Force * elapsed * 5.0f;
	}
	else
		Force -= Force * elapsed * 5.0f;
	
	if(GravityEnabled)
	{
		if(IsUnderWater)
		{
			Force += ViewDir * MoveVel * 0.2f * elapsed;

			Force.x += -frontPtz * StrafeVel * 0.2f * elapsed;
			Force.z +=  frontPtx * StrafeVel * 0.2f * elapsed;

			Force.y -= WATERGRAVITY * elapsed;

			O = Face;
			N = Face + Force * elapsed;
		}
		else
		{
			Force.x += frontPtx * MoveVel * elapsed;
			Force.z += frontPtz * MoveVel * elapsed;

			Force.x += -frontPtz * StrafeVel * elapsed;
			Force.z +=  frontPtx * StrafeVel * elapsed;

			Force.y -= LANDGRAVITY * tGravity;
			tGravity += elapsed;
		
			Feet.x = Face.x; Feet.z = Face.z;
			Feet.y = Face.y - ManHeight - 0.1f;

			O = Face; N = Feet;
			StandUpForce = 0.0f;
			CanDoJump = FALSE;
			IsOnGround = FALSE;
			if(HitChecking)
				DoFeetHitChecking(CurrRoom,&O,&N);

			O = Face;
			N = Face + Force * elapsed;
			N.y += StandUpForce;
		}
	}
	else
	{
		Force += ViewDir * MoveVel * 2.0f * elapsed;

		Force.x += -frontPtz * StrafeVel * 2.0f * elapsed;
		Force.z +=  frontPtx * StrafeVel * 2.0f * elapsed;

		O = Face;
		N = Face + Force * elapsed;
	}


	// Do some simple hit checking
		 if(N.y < -MAX_MOVEABLE_DIST) { N.y = -MAX_MOVEABLE_DIST; tGravity = 0.0f; }
	else if(N.y >  MAX_MOVEABLE_DIST)	N.y =  MAX_MOVEABLE_DIST;
		 if(N.x < -MAX_MOVEABLE_DIST)	N.x = -MAX_MOVEABLE_DIST;
	else if(N.x >  MAX_MOVEABLE_DIST)	N.x =  MAX_MOVEABLE_DIST;
		 if(N.z < -MAX_MOVEABLE_DIST)	N.z = -MAX_MOVEABLE_DIST;
	else if(N.z >  MAX_MOVEABLE_DIST)	N.z =  MAX_MOVEABLE_DIST;

	// Set the man's height depending on the crouch status
	if(CrouchKeyPressed == TRUE)
		ManHeight = CROUCHHEIGHT;
	else
		ManHeight = STANDUPHEIGHT;


	// Do the Hit-Checking with the Face
	if(HitChecking)
		DoFaceHitChecking(CurrRoom,&O,&N);
	
	Face = N; 	// Update the position of the face

	// Set the man's move vel depending on his height
	if(ManHeight == STANDUPHEIGHT || IsUnderWater)
	{	if(MoveVel > 0.0f) MoveVel = STANDMOVEVEL;
		else if(MoveVel < 0.0f) MoveVel = -STANDMOVEVEL;
		if(StrafeVel > 0.0f) StrafeVel = STANDMOVEVEL;
		else if(StrafeVel < 0.0f) StrafeVel = -STANDMOVEVEL;
	}
	else
	{	if(MoveVel > 0.0f) MoveVel = CROUCHMOVEVEL;
		else if(MoveVel < 0.0f) MoveVel = -CROUCHMOVEVEL;
		if(StrafeVel > 0.0f) StrafeVel = CROUCHMOVEVEL;
		else if(StrafeVel < 0.0f) StrafeVel = -CROUCHMOVEVEL;
	}




	// Clear the z-buffer
    lpDevice->Clear(0,NULL,D3DCLEAR_ZBUFFER,0,1.0f,0);


	// Start the scene render
	if( SUCCEEDED( lpDevice->BeginScene() ) ) 
	{


///////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////
		//			Draw the Static Stuff			//
		//////////////////////////////////////////////

///////////////////////////////////////////////////////////////////


	    // Set the World Matrix Transformation
		// First set the Translation
		D3DUtil_SetTranslateMatrix(WorldMatrix, -Face);
		// Then set the Rotation
		D3DUtil_MatrixMultiply(WorldMatrix,RotationMatrix,WorldMatrix);
		// Set the World Matrix
		lpDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, &WorldMatrix);
		
		

		///////////////////////////////////////////////////////////
		//////////////////////////
		// Draw the sky here	//
		//////////////////////////

  		// Disable z-buffering. 
		// Because nothing can go behind the sky.
	    lpDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, FALSE);
		// Set the wrap addressing mode to ensure that
		lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS, D3DTADDRESS_CLAMP );

		lpDevice->SetTexture( 0, lpSkyBoxTopTexture);	
		lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,SkyBoxTop_Verts,4,0);
		lpDevice->SetTexture( 0, lpSkyBoxBottomTexture);	
		lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,SkyBoxBottom_Verts,4,0);
		lpDevice->SetTexture( 0, lpSkyBoxLeftTexture);
		lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,SkyBoxLeft_Verts,4,0);
		lpDevice->SetTexture( 0, lpSkyBoxRightTexture);
		lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,SkyBoxRight_Verts,4,0);
		lpDevice->SetTexture( 0, lpSkyBoxBackTexture);	
		lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,SkyBoxBack_Verts,4,0);
		lpDevice->SetTexture( 0, lpSkyBoxFrontTexture);	
		lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_LVERTEX,SkyBoxFront_Verts,4,0);
		
		// Enable z-buffering. 
		// This is to ensure proper sorting order of the Room
	    lpDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, TRUE);
		lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS, D3DTADDRESS_WRAP );

		/////////////////////////////////////////////////////////////


		//////////////////////////////////////
		//	Process Room VB Vertices
		//////////////////////////////////////

		// Process the room verts
		ProcessRoomVBVertices(CurrRoom,lpDevice);
		
		// Set the Drawing triangles
		SetRoomDrawingTriangles(CurrRoom,&Face);

		

		//////////////////////////////////////
		//	Draw the room's triangles
		//////////////////////////////////////

		// Lock and fill the transformed VB with
		// the required color
		TRANSFORMED_VERTEX *pTVertices;
		if( SUCCEEDED( CurrRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
		                                      NULL ) ) )
		{
			POLYGON *pPoly  = CurrRoom->BSPPolyHead;
			POLYGON *epPoly = pPoly + CurrRoom->NumBSPPolys;
			WORD	*i,*ei;
			
			if(FaceIsUnderWater)
			{
				for( ; pPoly < epPoly ; pPoly++)
					if(pPoly->ColorChanged)
					{
						// Set back the color changed flag
						pPoly->ColorChanged = FALSE;

						i  = pPoly->DIndices;
						ei = i + pPoly->NumVertices;
				
						for(; i < ei ; i++)
							pTVertices[*i].color = UnderWaterColor;
					}
			}
			else
			{
				for( ; pPoly < epPoly ; pPoly++)
					if(pPoly->ColorChanged)
					{
						// Set back the color changed flag
						pPoly->ColorChanged = FALSE;

						i  = pPoly->DIndices;
						ei = i + pPoly->NumVertices;
				
						for(; i < ei ; i++)
							pTVertices[*i].color = WHITE;
					}
			}

			CurrRoom->TransformedRoomVB->Unlock();
		}

		// Set the proper tex coord set
		lpDevice->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);

		// Draw the Room's Solid Components
		DrawRoomSolidComponents(CurrRoom,lpDevice);


		// Apply the appropriate state block
		lpDevice->ApplyStateBlock(GlassSetStatesBlockHandle);

		// Draw the Room's Glass Components
		DrawRoomGlassComponents(CurrRoom,lpDevice);

		// Apply the appropriate state block
		lpDevice->ApplyStateBlock(GlassResetStatesBlockHandle);


		//////////////////////////////////////


		//////////////////////////////////////
		//		Draw the Dynamic Lights		//
		//////////////////////////////////////


		if(DrawDynamicLights)
		{
			if(DrawUserSpotLight)
			{
				UserSpotLight->x  = Face.x;
				UserSpotLight->y  = Face.y;
				UserSpotLight->z  = Face.z;
				UserSpotLight->x2 = Face.x + ViewDir.x * 500.0f;
				UserSpotLight->y2 = Face.y + ViewDir.y * 500.0f;
				UserSpotLight->z2 = Face.z + ViewDir.z * 500.0f;
			}


			// Set the LightMap Texture
			lpDevice->SetTexture(0,lpLightMapTexture);

			// Apply the appropriate state block
			lpDevice->ApplyStateBlock(LightmapSetStatesBlockHandle);

			// Loop through the rooms here and Draw all their Lights
			DrawGlobalLights(CurrRoom,&Face,lpDevice);
			
			// Apply the appropriate state block
			lpDevice->ApplyStateBlock(LightmapResetStatesBlockHandle);
		}

		//////////////////////////////////////



////////////////////////////////////////////////////////////////////
//					(end of drawing static stuff)				  //
////////////////////////////////////////////////////////////////////


		
		
		
		// Draw the movable objects here





/////////////////////////////////////////////////////////////////////

		// Draw the Cross Hair 
		// Set the render states
		lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,   TRUE );
	    lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,  D3DBLEND_SRCCOLOR );
		lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND, D3DBLEND_ONE );
		
		lpDevice->SetTexture(0,lpCrossHairTexture);
		lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,D3DFVF_TLVERTEX,CrossHairVerts,4,0);

		lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,FALSE);

/////////////////////////////////////////////////////////////////////

		// end the scene
		lpDevice->EndScene();
	}


	char mess[100];
	
	sprintf(mess,"Status :");
	OutputText(10,cy-60,mess);


	if(GravityEnabled)
		sprintf(mess,"Gravity : ON");
	else
		sprintf(mess,"Gravity : OFF");
	OutputText(20,cy-45,mess);
	
	if(HitChecking)
		sprintf(mess,"HitChecking : ON");
	else
		sprintf(mess,"HitChecking : OFF");
	OutputText(20,cy-30,mess);

	if(DrawDynamicLights)
		sprintf(mess,"Dynamic Lights : ON");
	else
		sprintf(mess,"Dynamic Lights : OFF");
	OutputText(20,cy-15,mess);

	if(DrawUserSpotLight)
		sprintf(mess,"User Spot Light : ON");
	else
		sprintf(mess,"User Spot Light : OFF");
	OutputText(20,cy,mess);

	

	Time_To_Update_FrameRate += elapsed;
	if(Time_To_Update_FrameRate > 0.5f)
	{	Time_To_Update_FrameRate -= 0.5f;
		FrameRate = 1.0f/elapsed;
	}
	sprintf(mess,"Frame Rate : %.2f",FrameRate);
	OutputText(10,10,mess);

	sprintf(mess,"Help :");
	OutputText(10,cy+20,mess);
	sprintf(mess,"G toggles gravity");
	OutputText(20,cy+35,mess);
	sprintf(mess,"H toggles hit-testing");
	OutputText(20,cy+50,mess);
	sprintf(mess,"1 toggles dynamic lighting");
	OutputText(20,cy+65,mess);
	sprintf(mess,"2 toggles the user spot light");
	OutputText(20,cy+80,mess);


	// flip to the primary surface

	lpDDSPrimary->Flip(0,DDFLIP_WAIT);
}

//------ Function to Initialize DirectDraw and the Application ------//

static BOOL Init(HINSTANCE hInstance, int nCmdShow)
{
    WNDCLASS                    wc;

    // Set up and register window class

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = (WNDPROC) WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = sizeof(DWORD);
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL,MAKEINTRESOURCE(RM_ICORES));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH) GetStockObject(BLACK_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = szClass;
    if (!RegisterClass(&wc)) {
		ErrStr=Err_Reg_Class;
        return FALSE;
	}

    // Get dimensions of display

    int ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
    int ScreenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Create a window and display


    g_ApphWnd = CreateWindow(szClass,							// class
                        szCaption,							// caption
						WS_VISIBLE|WS_POPUP,				// style 
						0,									// left
						0,									// top
						ScreenWidth,						// width
						ScreenHeight,						// height
                        NULL,								// parent window
                        NULL,								// menu 
                        hInstance,							// instance
                        NULL);								// parms
    if (!g_ApphWnd) {
		ErrStr=Err_Create_Win;
        return FALSE;
	}
    ShowWindow(g_ApphWnd, nCmdShow);
    UpdateWindow(g_ApphWnd);

	// initialze DirectDraw
	if (!init_ddraw(g_ApphWnd)) 
	{
		if(!ErrStr)
			ErrStr = "Failed to initialize DDraw";

		return FALSE;
	}

	// initialize Direct3D
	if (!init_d3d())
	{
		if(!ErrStr)
			ErrStr = "Failed to initialize D3D";

		return FALSE;
	}
	
	////////////////////////////////
	// Create the DI Mouse Object
	////////////////////////////////
	// Create a DInput object
	  // Create the DI object
    if (DirectInputCreate(hInstance, DIRECTINPUT_VERSION, &lpDI, NULL) != DI_OK)
	{
		if(!ErrStr)
			ErrStr = "Failed to create DInput";

		return FALSE;
	}
    
    // Obtain an interface to the system mouse device.
	if (lpDI->CreateDevice(GUID_SysMouse, &pMouse, NULL) != DI_OK)
	{
		if(!ErrStr)
			ErrStr = "Failed to create mouse device";

		return FALSE;
	}
    
    if (pMouse->SetDataFormat(&c_dfDIMouse) != DI_OK)
	{
		if(!ErrStr)
			ErrStr = "Failed to set mouse data format";

        SafeRelease(pMouse);
        return FALSE;
    }

	if (pMouse->SetCooperativeLevel(g_ApphWnd, DISCL_FOREGROUND |
        DISCL_EXCLUSIVE) != DI_OK)
    {
		if(!ErrStr)
			ErrStr = "Failed to set mouse cooperative level";

		SafeRelease(pMouse);
        return FALSE;
    }

    // Acquire the newly created device
    pMouse->Acquire();


	// Initialize the GLs
	InitGlobalLights();


	// Set the cursor position to the end of the screen
	SetCursorPos(ScreenWidth,ScreenHeight);


	// create 3D objects
	if(!create_objects()) 
	{
		if(!ErrStr)
			ErrStr = "Failed to create objects";

		return FALSE;
	}

	// return success to caller

	return TRUE;
}

//------ Application Loop ------//

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	LONGLONG cur_time;       // current time
	LONGLONG last_time=0;	 // time of previous frame
	LONGLONG Time_to_get_mse_input=0;


	// initialize the application, exit on failure

    if (!Init(hInstance, nCmdShow))
	{
		if(!ErrStr)
			ErrStr = "Failed to initialize";

		Cleanup();
        return FALSE;
	}

	// Read in using timeGetTime 
	last_time=timeGetTime(); 

    // Now we're ready to recieve and process Windows messages.

    BOOL bGotMsg;
    MSG  msg;
    PeekMessage( &msg, NULL, 0U, 0U, PM_NOREMOVE );
	
    while( WM_QUIT != msg.message  )
    {
        bGotMsg = PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE );
        if( bGotMsg )
        {
			TranslateMessage( &msg );
            DispatchMessage( &msg );
        } 
		else 
		{
			// use the appropriate method to get time 
			// and calculate elapsed time since last frame

			cur_time=timeGetTime(); 

			// calculate elapsed time

			elapsed=(cur_time-last_time)*0.001f;
			
			// save frame time

			last_time=cur_time;
			
			// render the frame
			render_frame();
			

			// Get mouse input
			if(cur_time > Time_to_get_mse_input)
			{	Time_to_get_mse_input = cur_time + 40;

				if(pMouse ) 
				{	
					if( FAILED(pMouse->GetDeviceState( sizeof(DIMOUSESTATE), &dims )))
					{	
						while(pMouse->Acquire() == DIERR_INPUTLOST);	
						pMouse->GetDeviceState( sizeof(DIMOUSESTATE), &dims );
					}
					rotVel = dims.lX * 0.03f;
					lookupVel = -dims.lY * 0.03f;

					if(dims.rgbButtons[1] & 0x80) 	// right click
					{
						if(IsUnderWater)
						{
							Force.y += STANDMOVEVEL * elapsed * 0.5f;
						}
						else if(JumpKeyReleased)
						{	
							JumpKeyReleased = FALSE;
							
							// Do a bunch of stuff here
							if(CanDoJump)
								Force.y += JUMPVEL;
						}
					}
					else
						JumpKeyReleased = TRUE;

				}
			}

		
		
		}
    }

	// return final message

    return msg.wParam;
}
