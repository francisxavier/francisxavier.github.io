


/////////////////////////////////////////////////////////////////////
//					Cleanup.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
// Cleans up the App
/////////////////////////////////////////////////////////////////////


void Cleanup()
{

	// Release the Rooms
	for(WORD i=0;i<NumRooms;i++)
	 if(Rooms[i])
	  CleanupRoom(Rooms[i]);

	// Release the Special Textures
	SafeRelease(lpSkyBoxTopTexture);
	SafeRelease(lpSkyBoxBottomTexture);
	SafeRelease(lpSkyBoxLeftTexture);
	SafeRelease(lpSkyBoxRightTexture);
	SafeRelease(lpSkyBoxBackTexture);
	SafeRelease(lpSkyBoxFrontTexture);

	SafeRelease(lpCrossHairTexture);
	SafeRelease(lpLightMapTexture);


	// Delete the State Blocks
	lpDevice->DeleteStateBlock(GlassSetStatesBlockHandle);
	lpDevice->DeleteStateBlock(GlassResetStatesBlockHandle);
	lpDevice->DeleteStateBlock(LightmapSetStatesBlockHandle);
	lpDevice->DeleteStateBlock(LightmapResetStatesBlockHandle);


	// Release the mouse
    if( pMouse ) 
	    pMouse->Unacquire();
    
    // Release any DirectInput objects.
    SafeRelease( pMouse );
    SafeRelease( lpDI );
	
	// release 3D interfaces

	SafeRelease(lpDevice);
	SafeRelease(lpD3D);
	
	// release DirectDraw interfaces

	SafeRelease(lpDDSPrimary);
	// Set the Cooperative level of DDraw to Normal
	if(g_ApphWnd && lpDD)
		lpDD->SetCooperativeLevel(g_ApphWnd, DDSCL_NORMAL );
	SafeRelease(lpDD);

	// display error if one thrown

	if (ErrStr) {
		MessageBox(NULL, ErrStr, szCaption, MB_OK);
		ErrStr=NULL;
	}

}
