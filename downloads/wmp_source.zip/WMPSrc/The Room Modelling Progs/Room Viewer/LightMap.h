

/////////////////////////////////////////////////////////////////////
//							LightMap.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//	Handles all the Global LightMaps
/////////////////////////////////////////////////////////////////////

//	Note :	While initializing Lights, the 'one_by_2Radius' member
//			of the light must be initialized properly, but the 
//			'Brightness_by_Radius' member need not be initialized
//			 for spot lights, it is only used with point lights.



/////////////////////////////////////////////////////////////////////
//						Function Prototypes
/////////////////////////////////////////////////////////////////////






/////////////////////////////////////////////////////////////////////
//	Initialize the Global Lights
/////////////////////////////////////////////////////////////////////

void InitGlobalLights()
{
	// Set up the used GLs

	UsedGL = GlobalLights;
	UsedGL->next = UsedGL;
	UsedGL->previous = UsedGL;

	// Set up the Unused GLs

	UnusedGL = &GlobalLights[1];
	for(WORD i=2; i<MAX_LIGHTS + 1; i++)
		GlobalLights[i-1].next = &GlobalLights[i];

	GlobalLights[MAX_LIGHTS].next = NULL;
}


/////////////////////////////////////////////////////////////////////
//	Get a new light pointer
/////////////////////////////////////////////////////////////////////

LIGHT *GetNewGLptr()
{
	LIGHT *tmpGL;

	if(UnusedGL == NULL) return(UsedGL);

	tmpGL = UnusedGL;
	UnusedGL = UnusedGL->next;

	tmpGL->next = UsedGL->next;
	UsedGL->next = tmpGL;
	tmpGL->previous = UsedGL;
	tmpGL->next->previous = tmpGL;

	return(tmpGL);
}


/////////////////////////////////////////////////////////////////////
// Put back an old light
/////////////////////////////////////////////////////////////////////

void ReturnUsedGLptr(LIGHT *tmpGL)
{
	if(tmpGL == UsedGL) return;

	tmpGL->previous->next = tmpGL->next;
	tmpGL->next->previous = tmpGL->previous;

	tmpGL->next = UnusedGL;
	UnusedGL = tmpGL;
}



/////////////////////////////////////////////////////////////////////
//	Draw the Global Lights of a given Room
/////////////////////////////////////////////////////////////////////

void DrawGlobalLights(ROOM *pRoom, D3DVECTOR *ViewPos, LPDIRECT3DDEVICE7 lpD)
{
	// Vars used for hit-checking
	POLYGON			*ppoly;
	POLYGON			**pStackP;
	float			*pStackDist,*pStackOB,*pStackNC;
	float			Ix,Iy,Iz,pDist,Dist,OB,NC;
	float			one_by_denom,denom_by_OB;
	int				Intersection;

	// Vars used to draw the Lightmaps
	WORD			*ppoly_index,*ppoly_end_index;
	WORD			*ppoly_Dindex,*ppoly_end_Dindex;

	WORD				*Triind;
	TRANSFORMED_VERTEX	*pTVertices;
			
	
	for(LIGHT *pLight=UsedGL->next;
		pLight != UsedGL;
		pLight = pLight->next
	   )
	{

	if(pLight->x2 || pLight->y2 || pLight->z2)
	{
		// Spot Light


		// Lock the transformed VB
		if( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
		                             NULL ) != D3D_OK )
				return;


		// Some variables
		Triind	= pRoom->RoomVertInds;

		ppoly = pRoom->BSPPolyHead;
		pStackP = pRoom->StackP;
		pStackOB = pRoom->StackOB;
		pStackNC = pRoom->StackNC;

		O.x = pLight->x; N.x = pLight->x2;
		O.y = pLight->y; N.y = pLight->y2;
		O.z = pLight->z; N.z = pLight->z2;


		for(;;)
		{
			while(ppoly)
			{
				OB = PERPDISTV(O,ppoly);
				NC = PERPDISTV(N,ppoly);

				if(OB > 0.0f)
				{
					if(NC < pLight->Radius)
					{ *pStackP++ = ppoly; *pStackOB++ = OB; *pStackNC++ = NC; }
					ppoly = ppoly->front;
				}
				else
				{
					if(NC > -pLight->Radius)
					{ *pStackP++ = ppoly; *pStackOB++ = OB; }
					ppoly = ppoly->back;
				}
			}

			if(pStackP > pRoom->StackP)
			{
				ppoly = *(--pStackP); OB = *(--pStackOB);
	
				if(OB > 0.0f)
				{
					NC = *(--pStackNC);
					
					// Do the hit checking

					if(NC < 0.0f &&
						(PERPDISTP(ViewPos,ppoly) > 0.0f ||
						 ppoly->ParentComponent->IsGlass)
					  )
					{
						one_by_denom = 1.0f/(OB-NC);
						denom_by_OB = (OB-NC)/OB;
						Ix = (N.x*OB - O.x*NC)*one_by_denom;
						Iy = (N.y*OB - O.y*NC)*one_by_denom;
						Iz = (N.z*OB - O.z*NC)*one_by_denom;

						Intersection = 1;
						for(WORD j=0;j<ppoly->NumVertices;j++)
						{
							pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
									+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
									+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
							if(pDist > pLight->Radius)
							{ Intersection = 0; break; }
						}

						if(Intersection)
						{
							// This poly's color is changed
							ppoly->ColorChanged = TRUE;

							ppoly_end_index  = ppoly->Indices  + ppoly->NumVertices;
							ppoly_end_Dindex = ppoly->DIndices + ppoly->NumVertices;
							
							float LBrightness = pLight->Brightness * (1.0f - OB * one_by_denom);
							DWORD LColor = D3DRGB(LBrightness*(pLight->R),LBrightness*(pLight->G),LBrightness*(pLight->B));

							for(ppoly_index = ppoly->Indices,ppoly_Dindex = ppoly->DIndices;
								ppoly_index < ppoly_end_index;
								ppoly_index++,ppoly_Dindex++)
							{
								pTVertices[*ppoly_Dindex].color = LColor;
							
								pTVertices[*ppoly_Dindex].tuL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->LightMapNormal2)
									* pLight->one_by_2Radius * denom_by_OB;
								
								pTVertices[*ppoly_Dindex].tvL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->Normals[0])
									* pLight->one_by_2Radius * denom_by_OB;

								if(ppoly_Dindex < ppoly->DIndices + 3)
									*Triind++ = *ppoly_Dindex;
								else
								{
									*Triind++ = *(ppoly->DIndices);
									*Triind++ = *(Triind - 2);
									*Triind++ = *ppoly_Dindex;
								}
							}	
							
						}
					}	
					ppoly = ppoly->back;
				}
				else
					ppoly = ppoly->front;
			}
			else
				break;
		}

		// Unlock the Transformed VB
		pRoom->TransformedRoomVB->Unlock();


	}	// End of calculating Spot Light
	else	
	{
		// Point Light


		// Lock the transformed VB
		if( pRoom->TransformedRoomVB->Lock( DDLOCK_WAIT, (VOID**)&pTVertices,
		                             NULL ) != D3D_OK )
				return;


		// Some variables
		Triind	= pRoom->RoomVertInds; 

		ppoly = pRoom->BSPPolyHead;
		pStackP = pRoom->StackP;
		pStackDist = pRoom->StackOB;

	
		for(;;)
		{
			while(ppoly)
			{
				Dist = PERPDISTP(pLight,ppoly);
				
				if(Dist > 0.0f)
				{
					if(Dist < pLight->Radius)
					{ *pStackP++ = ppoly; *pStackDist++ = Dist; }
	
					ppoly = ppoly->front;
				}
				else
				{
					if(Dist > -pLight->Radius)
					{ *pStackP++ = ppoly; *pStackDist++ = Dist; }
					
					ppoly = ppoly->back;
				}
			}

			if(pStackP > pRoom->StackP)
			{
				ppoly = *(--pStackP); Dist = *(--pStackDist);
	
				if(Dist > 0.0f)
				{

					if(Dist < pLight->Radius &&
						(PERPDISTP(ViewPos,ppoly) > 0.0f ||
						 ppoly->ParentComponent->IsGlass)
					  )
					{
						Ix = pLight->x - Dist*ppoly->nx;
						Iy = pLight->y - Dist*ppoly->ny;
						Iz = pLight->z - Dist*ppoly->nz;
						
						Intersection = 1;
						for(WORD j=0;j<ppoly->NumVertices;j++)
						{
							pDist =  (Ix - pRoom->RoomVerts[ppoly->Indices[j]].x)*ppoly->Normals[j].nx
									+(Iy - pRoom->RoomVerts[ppoly->Indices[j]].y)*ppoly->Normals[j].ny
									+(Iz - pRoom->RoomVerts[ppoly->Indices[j]].z)*ppoly->Normals[j].nz;
	
							if(pDist > pLight->Radius)
							{ Intersection = 0; break; }
						}

						if(Intersection)
						{
							// This poly's color is changed
							ppoly->ColorChanged = TRUE;

							ppoly_end_index  = ppoly->Indices  + ppoly->NumVertices;
							ppoly_end_Dindex = ppoly->DIndices + ppoly->NumVertices;

							float LBrightness = pLight->Brightness - Dist * pLight->Brightness_by_Radius;
							DWORD LColor = D3DRGB(LBrightness*(pLight->R),LBrightness*(pLight->G),LBrightness*(pLight->B));

							for(ppoly_index = ppoly->Indices,ppoly_Dindex = ppoly->DIndices;
								ppoly_index < ppoly_end_index;
								ppoly_index++,ppoly_Dindex++)
							{
								pTVertices[*ppoly_Dindex].color = LColor;
							
								pTVertices[*ppoly_Dindex].tuL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->LightMapNormal2)
									* pLight->one_by_2Radius;

								pTVertices[*ppoly_Dindex].tvL = 0.5f
									+ TEXCOORDDIST(pRoom->RoomVerts[*ppoly_index],ppoly->Normals[0])
									* pLight->one_by_2Radius;

								if(ppoly_Dindex < ppoly->DIndices + 3)
									*Triind++ = *ppoly_Dindex;
								else
								{
									*Triind++ = *(ppoly->DIndices);
									*Triind++ = *(Triind - 2);
									*Triind++ = *ppoly_Dindex;
								}
							}
						}
					}

					ppoly = ppoly->back;
				}
				else
					ppoly = ppoly->front;
			}
			else
				break;
		}

		// Unlock the Transformed VB
		pRoom->TransformedRoomVB->Unlock();

	}// End of calculating Point Light


	// Draw the Light (Spot or Point)
	if(Triind > pRoom->RoomVertInds)
	{
		lpD->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
									pRoom->TransformedRoomVB,
									0,pRoom->VBCapacity,
									pRoom->RoomVertInds,
									(Triind - pRoom->RoomVertInds),
									0);
	}

	}// End of drawing this light, go to the next light
}
