

/////////////////////////////////////////////////////////////////////
//					Defines and Globals.h
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//	Consists of all the defines and Global variables
/////////////////////////////////////////////////////////////////////



// The Screen Resolution
#define SCREEN_RES_X	800
#define SCREEN_RES_Y	600


// The maximum no. of lights
#define MAX_LIGHTS		1000

// The maximum no. of Rooms
#define MAX_ROOMS		1

// The radius of the skybox
#define SKYBOX_RADIUS		10000.0f
#define MAX_MOVEABLE_DIST	(SKYBOX_RADIUS-1000.0f)

// Some Colours
#define WHITE			0xffffffff
#define LIGHTGRAY		0xC0C0C0



// Perpendicular distance
#define PERPDISTP(V,P) ((V->x - pRoom->RoomVerts[P->Indices[0]].x) * P->nx +	\
				        (V->y - pRoom->RoomVerts[P->Indices[0]].y) * P->ny +	\
					    (V->z - pRoom->RoomVerts[P->Indices[0]].z) * P->nz )

#define PERPDISTV(V,P) ((V.x - pRoom->RoomVerts[P->Indices[0]].x) * P->nx +	\
				        (V.y - pRoom->RoomVerts[P->Indices[0]].y) * P->ny +	\
				        (V.z - pRoom->RoomVerts[P->Indices[0]].z) * P->nz )

#define CURRPERPDISTV(V,P) ((V.x - CurrRoom->RoomVerts[P->Indices[0]].x) * P->nx +	\
							(V.y - CurrRoom->RoomVerts[P->Indices[0]].y) * P->ny +	\
							(V.z - CurrRoom->RoomVerts[P->Indices[0]].z) * P->nz )



// Texture Coordinate Distance
#define TEXCOORDDIST(V,N) (((V).x - Ix) * (N).nx +		\
					       ((V).y - Iy) * (N).ny +		\
						   ((V).z - Iz) * (N).nz )


// Delete & Release
#define SafeRelease(x) if (x) { x->Release(); x=NULL;}
#define SafeDelete(x) if (x) {delete x;x=NULL;}



//------ Error Return String ------//

const char *ErrStr=NULL;	

//------ Error Messages ------//

const char Err_Reg_Class[]			= "Error Registering Window Class";
const char Err_Create_Win[]			= "Error Creating Window";
const char Err_DirectDrawCreate[]	= "DirectDrawCreate FAILED";
const char Err_Query[]				= "QueryInterface FAILED";
const char Err_Coop[]				= "SetCooperativeLevel FAILED";
const char Err_CreateSurf[]			= "CreateSurface FAILED";
const char Err_DispMode[]			= "Error Setting Display Mode";
const char Err_Device[]				= "Device Creation Failed";
const char Err_SetView[]			= "Viewport settings failed";



//////////////////////////////////////
//			Data Structures			//
//////////////////////////////////////


struct VERTEX
{
	float x,y,z;	// Only Position
};

struct NORMAL
{
	float nx,ny,nz;
};

struct UNTRANSFORMED_VERTEX
{ 
	float x,y,z;	// Only Position
};

struct TRANSFORMED_VERTEX
{ float x,y,z;		// Position
  float rhw;		// RHW value
  DWORD color;		// Diffuse Color
  float tuB,tvB;	// Base Texture Coords
  float tuS,tvS;	// Shadow Map Coords
  float tuL,tvL;	// Light Map Coords
};

struct TEXCOORD
{
	float tu,tv;
};

struct WATER
{
	float	y;
	float	R,G,B;
	WORD	NumBoundingPolys;
	WORD	*BoundingPolyInds;
};

struct COMPONENT
{ // The Component's Indices
  WORD	NumPolyIndices;
  WORD	*PolyIndices;

  WORD	*Triind;			// Used while drawing the components, to
  WORD	*TriVertInds;		// find out which triangles are to be drawn.

  char	HasAlpha,IsGlass,HitChecked;

  // The Component's Texture
  LPDIRECTDRAWSURFACE7	lpComponentTexture;
};

struct POLYGON
{ WORD		NumVertices;
  WORD		*DIndices;			// The drawing indices
  WORD		*Indices;			// The hit-checking indices
  NORMAL	*Normals;			// The side normals
  float		nx,ny,nz;			// The poly's face normal
  NORMAL	LightMapNormal2;	// The normal perpendicular to 
								// the normal of the first side
								// of the polygon
  BOOLEAN	ColorChanged;
  COMPONENT	*ParentComponent;
  POLYGON	*front,*back;
};


struct ROOM
{
  // The Room's Components
  WORD		NumComponents;
  COMPONENT	*Components;
  COMPONENT **CompDrawingList;	// Gives the order for drawing the components
  COMPONENT **eCompDrawingList;	// The end ptr of the list

  // The Room's Vertex Index Buffer(used for Drawing Lightmaps
  // since I'm using my own Back-Face Culling
  WORD		 *RoomVertInds;
  
  // The Room's Polys
  WORD		NumBSPPolys;
  POLYGON	*BSPPolyHead;

  // Stacks used for hit checking
  POLYGON	**StackP;
  float		*StackOB,*StackNC;

  // The Room's Vertices
  WORD		NumVerts;
  VERTEX	*RoomVerts;

  // The Room's Extents
  float		x1,y1,z1,x2,y2,z2;

  // The Room's Waters
  WORD		NumWaters;
  WATER		*RoomWaters;

  // The Room's Vertex Buffers
  WORD						VBCapacity;
  LPDIRECT3DVERTEXBUFFER7	UntransformedRoomVB;
  LPDIRECT3DVERTEXBUFFER7	TransformedRoomVB;
};


// The structure of a Light
struct LIGHT
{
	float x,y,z;
	float x2,y2,z2;
	float Radius;
	float Brightness;
	float R,G,B;
	float Brightness_by_Radius;
	float one_by_2Radius;

	LIGHT *next,*previous;
};

// The Global Lights
LIGHT	GlobalLights[MAX_LIGHTS + 1];
LIGHT	*UsedGL,*UnusedGL;


/////////////////////////////////////////
//		DIRECTX	App Specific
/////////////////////////////////////////


//------ Global Interface Pointers ------//
LPDIRECTDRAW7 lpDD=NULL;
LPDIRECTDRAWSURFACE7 lpDDSPrimary=NULL;
LPDIRECTDRAWSURFACE7 lpDDSBack=NULL;
LPDIRECT3D7 lpD3D=NULL;
LPDIRECT3DDEVICE7 lpDevice=NULL;

// Z-Buffer
LPDIRECTDRAWSURFACE7 lpDDSZBuf=NULL;


// Texture map structure

LPDIRECTDRAWSURFACE7 lpSkyBoxTopTexture=NULL;
LPDIRECTDRAWSURFACE7 lpSkyBoxBottomTexture=NULL;
LPDIRECTDRAWSURFACE7 lpSkyBoxLeftTexture=NULL;
LPDIRECTDRAWSURFACE7 lpSkyBoxRightTexture=NULL;
LPDIRECTDRAWSURFACE7 lpSkyBoxBackTexture=NULL;
LPDIRECTDRAWSURFACE7 lpSkyBoxFrontTexture=NULL;

LPDIRECTDRAWSURFACE7 lpCrossHairTexture=NULL;
LPDIRECTDRAWSURFACE7 lpLightMapTexture=NULL;


//-----DI Object(Mouse)-----------------//
LPDIRECTINPUT        lpDI;
LPDIRECTINPUTDEVICE  pMouse;
DIMOUSESTATE dims;

//------ Window Class Information ------//
static char szClass[] = "RoomViewerClass";
static char szCaption[] = "RoomViewer";

// Window Handle
HWND g_ApphWnd;




/////////////////////////////////////////////////////////////////////
////////////////////	P L A Y E R		/////////////////////////////
/////////////////////////////////////////////////////////////////////


// Physics Defines
#define		STANDMOVEVEL					750.0f
#define		CROUCHMOVEVEL					250.0f
#define		MINDIST							 10.0f
#define		LANDGRAVITY					     40.0f
#define		WATERGRAVITY					 10.0f
#define		STANDUPHEIGHT					 25.0f
#define		CROUCHHEIGHT					 16.0f
#define		STANDUPFORCE					 75.0f
#define		JUMPVEL							200.0f



//----- Rotation position and speed -----//

float elapsed;				// time elapsed since last frame
float rotAngle=0.0f;		// current angle of Y rotation
float rotVel=0.0f;			// current velocity of Y rotation
float lookupAngle=0.0f;		// current angle of X rotation
float lookupVel=0.0f;		// current velocity of X rotation
float leanAngle=0.0f;		// current angle of Z rotation(view blob)

float frontPtz,frontPtx;	// temp vars
float MoveVel=0.0f;			// the moving velocity
float StrafeVel=0.0f;		// the strafing velocity
float tGravity = 0.0f;		// the 't' in gravity acceleration
float ManHeight=STANDUPHEIGHT;	// the man's current height
float StandUpForce;			// the force to stand up with


//----- Position, speed, etc. --------//
D3DVECTOR ViewDir=D3DVECTOR(0.0f,0.0f,0.0f);
D3DVECTOR ViewNorm = D3DVECTOR(0.0f,1.0f,0.0f);


// Positions
D3DVECTOR	O,N;
D3DVECTOR	Face,Feet;
D3DVECTOR   Force;


// Jump Vars
BOOL		JumpKeyReleased=TRUE;
BOOL		CrouchKeyPressed=FALSE;
BOOL		CanDoJump;
BOOL		IsOnGround;


// Water Vars
BOOLEAN		FaceIsUnderWater=FALSE;
BOOLEAN		IsUnderWater=FALSE;
D3DCOLOR	UnderWaterColor;
float		UnderWaterDistortion=0.75f;
float		UnderWaterDistortionInc=0.025f;


// Others
BOOLEAN		walkleanDir=0;	// the tilting dir while walking



// State Block Handles

// lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
// lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
// lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_ZERO);
// lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_SRCCOLOR);
DWORD		GlassSetStatesBlockHandle;

// lpDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
// lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);
DWORD		GlassResetStatesBlockHandle;

// lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,			D3DTADDRESS_CLAMP);
// lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,		2);
// lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		FALSE);
// lpDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE,	TRUE);
// lpDevice->SetRenderState( D3DRENDERSTATE_SRCBLEND,			D3DBLEND_SRCCOLOR);
// lpDevice->SetRenderState( D3DRENDERSTATE_DESTBLEND,			D3DBLEND_ONE);
DWORD		LightmapSetStatesBlockHandle;

// lpDevice->SetTextureStageState( 0, D3DTSS_ADDRESS,			D3DTADDRESS_WRAP);
// lpDevice->SetTextureStageState( 0, D3DTSS_TEXCOORDINDEX,		0);
// lpDevice->SetRenderState( D3DRENDERSTATE_ZWRITEENABLE,		TRUE);
// lpDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE,	FALSE);
DWORD		LightmapResetStatesBlockHandle;





// World and Rotation Matrices
D3DMATRIX	WorldMatrix;
D3DMATRIX	RotationMatrix;

/////////////////////////////////////////////////////////////////

